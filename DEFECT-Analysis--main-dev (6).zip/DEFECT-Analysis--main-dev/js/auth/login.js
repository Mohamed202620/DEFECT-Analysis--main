// استيراد قاعدة البيانات ومتغير DEBUG من ملف الإعدادات المركزي
import { db, auth, DEBUG, phoneToAuthEmail } from '../config.js';

import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-auth.js";

import {
  collection,
  query,
  where,
  getDocs,
  doc,
  getDoc,
  setDoc
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js";

import { verifyPassword } from '../services/crypto.js';

/**
 * خدمة تسجيل الدخول عبر Firebase Authentication (Email/Password)
 *
 * رقم الموبايل بيتحوّل لإيميل داخلي (phoneToAuthEmail) عشان نقدر
 * نستخدم Firebase Auth الحقيقي مع الحفاظ على واجهة الدخول برقم
 * الموبايل زي ما هي تماماً.
 *
 * ترحيل تلقائي للحسابات القديمة:
 * أي مستخدم اتسجل قبل التفعيل ده لسه عنده فقط مستند فيه
 * passwordHash/salt (أو password Plaintext في حالات قديمة جداً)
 * من غير أي حساب Firebase Auth حقيقي. أول مرة يدخل بعد هذا
 * التحديث: بنتحقق من كلمة سره بالطريقة القديمة، ولو صحيحة بننشئ
 * له حساب Auth حقيقي بنفس كلمة السر اللي كتبها الآن، وننقل بياناته
 * (بدون أي حقول خاصة بكلمة السر) لمستند جديد بمعرّف = uid بتاع
 * Firebase Auth. من المرة الجاية هيدخل عادي عن طريق Auth مباشرة.
 */
export async function login(phone, pass) {

  const cleanPhone = String(phone || "").trim();
  const cleanPass = String(pass || "").trim();

  if (!cleanPhone || !cleanPass) {
    return {
      status: "error",
      message: "يرجى إدخال رقم الموبايل وكلمة السر بشكل صحيح."
    };
  }

  const email = phoneToAuthEmail(cleanPhone);
  let uid;

  try {

    // ==================================================
    // المحاولة الطبيعية: المستخدم عنده حساب Firebase Auth بالفعل
    // ==================================================

    const cred = await signInWithEmailAndPassword(auth, email, cleanPass);
    uid = cred.user.uid;

  } catch (authError) {

    const isMissingAuthAccount =
      authError.code === "auth/user-not-found" ||
      authError.code === "auth/invalid-credential" ||
      authError.code === "auth/invalid-email";

    if (!isMissingAuthAccount) {

      if (authError.code === "auth/wrong-password") {
        return { status: "error", message: "كلمة السر غير صحيحة." };
      }

      if (authError.code === "auth/too-many-requests") {
        return {
          status: "error",
          message: "محاولات كثيرة جداً، يرجى المحاولة لاحقاً."
        };
      }

      console.error("Auth Login Error:", authError);
      return { status: "error", message: "حدث خطأ أثناء تسجيل الدخول." };
    }

    // ==================================================
    // ترحيل تلقائي من النظام القديم (بدون Firebase Auth)
    // ==================================================

    const usersRef = collection(db, "users");
    const legacyQuery = query(usersRef, where("phone", "==", cleanPhone));
    const legacySnapshot = await getDocs(legacyQuery);

    if (legacySnapshot.empty) {
      return { status: "error", message: "رقم الموبايل غير مسجل بالنظام." };
    }

    if (legacySnapshot.size > 1) {
      return {
        status: "error",
        message: "يوجد أكثر من حساب بنفس رقم الهاتف."
      };
    }

    const legacyDocSnap = legacySnapshot.docs[0];
    const legacyData = legacyDocSnap.data();

    const isLegacyPlaintext = !legacyData.passwordHash && !!legacyData.password;

    let passwordOk = false;

    if (isLegacyPlaintext) {
      passwordOk = legacyData.password === cleanPass;
    } else {
      passwordOk = await verifyPassword(
        cleanPass,
        legacyData.salt,
        legacyData.passwordHash
      );
    }

    if (!passwordOk) {
      return { status: "error", message: "كلمة السر غير صحيحة." };
    }

    // كلمة السر صحيحة -> ننشئ حساب Firebase Auth حقيقي الآن
    let migratedCred;
    try {
      migratedCred = await createUserWithEmailAndPassword(auth, email, cleanPass);
    } catch (migrationAuthError) {
      console.error("Auth migration error:", migrationAuthError);
      return {
        status: "error",
        message: "حدث خطأ أثناء ترقية الحساب، يرجى المحاولة مرة أخرى."
      };
    }

    uid = migratedCred.user.uid;

    // نقل بيانات المستخدم (بدون أي حقول متعلقة بكلمة السر) لمستند
    // جديد بمعرّف = uid، بدل المستند القديم بمعرّفه العشوائي
    const {
      password: _legacyPassword,
      passwordHash: _legacyHash,
      salt: _legacySalt,
      ...safeLegacyData
    } = legacyData;

    try {
      await setDoc(doc(db, "users", uid), safeLegacyData);
    } catch (migrationWriteError) {
      console.error("Legacy profile migration error:", migrationWriteError);
      return {
        status: "error",
        message: "تم ترقية الحساب لكن حدث خطأ أثناء نقل البيانات، يرجى المحاولة مرة أخرى."
      };
    }

    // ملحوظة: المستند القديم (legacyDocSnap.id) بيفضل موجود عمداً
    // كنسخة احتياطية بدل حذفه تلقائياً - يُنصح بمراجعته وحذفه يدوياً
    // بعد التأكد إن الترحيل نجح لكل المستخدمين.
  }

  // ==================================================
  // من هنا: نفس منطق فحص الحساب القديم بالضبط، لكن القراءة
  // من مستند users/{uid} مباشرة بدل الاستعلام برقم الهاتف
  // ==================================================

  const userDocSnap = await getDoc(doc(db, "users", uid));

  if (!userDocSnap.exists()) {
    return {
      status: "error",
      message: "بيانات الحساب غير موجودة."
    };
  }

  const data = userDocSnap.data();

  const userData = {
    id: uid,
    ...data,

    status: (data.status || "").trim().toLowerCase(),
    role: (data.role || "").trim().toLowerCase(),

    permissions: (data.permissions || "")
      .split(",")
      .map(p => p.trim().toLowerCase())
      .filter(Boolean)
      .join(",")
  };

  if (DEBUG) {
    console.log("USER DATA:", userData);
  }

  if (userData.status === "pending") {
    return {
      status: "error",
      message: "تم إرسال طلبك وهو بانتظار موافقة المسؤول."
    };
  }

  if (userData.status === "rejected") {
    return {
      status: "error",
      message: "تم رفض طلب الانضمام، يرجى التواصل مع المسؤول."
    };
  }

  if (userData.status !== "active") {
    return {
      status: "error",
      message: "الحساب غير مفعل."
    };
  }

  return {
    status: "success",
    user: userData
  };
}
