// تحديث رقم الإصدار مهم جداً عندما تقوم بتعديل أي ملف ليقوم المتصفح بتحديث الكاش
const CACHE_NAME = 'maint-system-v1.2'; 

// نكتفي بالملفات الأساسية المضمونة لتجنب فشل التثبيت
const CORE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './1000230635.png'
];

// حدث التثبيت (Install Event)
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("[SW] Caching Core Assets");
      return cache.addAll(CORE_ASSETS);
    })
  );
  self.skipWaiting(); // تفعيل النسخة الجديدة فوراً
});

// حدث التفعيل (Activate Event) لتنظيف الكاش القديم
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log("[SW] Deleting old cache:", key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim(); // السيطرة على كل الصفحات المفتوحة فوراً
});

// حدث جلب البيانات (Fetch Event)
self.addEventListener('fetch', (e) => {
  const req = e.request;

  // تجاوز طلبات الـ API إذا كانت موجودة (حتى لا يتم تخزين البيانات المتغيرة باستمرار)
  // if (req.url.includes('/api/')) { return; }

  e.respondWith(
    caches.match(req).then((cachedRes) => {
      // استراتيجية (Stale-While-Revalidate)
      // جلب النسخة الأحدث من الشبكة لتحديث الكاش في الخلفية
      const fetchPromise = fetch(req).then((networkRes) => {
        // التأكد من أن الاستجابة صالحة قبل تخزينها
        // type 'basic' للملفات المحلية، و 'opaque' للملفات الخارجية (CDN)
        if (networkRes && (networkRes.status === 200 || networkRes.type === 'opaque')) {
          const clone = networkRes.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
        }
        return networkRes;
      }).catch(() => {
        // ماذا يحدث لو انقطع الإنترنت والملف غير موجود في الكاش؟
        console.warn("[SW] Offline, and resource not in cache:", req.url);
      });

      // إذا كان الملف في الكاش، اعرضه للمستخدم فوراً (سرعة عالية).
      // وإذا لم يكن، انتظر جلب الشبكة.
      return cachedRes || fetchPromise;
    })
  );
});
