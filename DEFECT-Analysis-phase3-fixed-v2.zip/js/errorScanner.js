// ============================================================
// errorScanner.js
// منطق ميزة "Machine Error Scanner" الجديدة
// - التقاط صورة لشاشة العطل
// - قراءة النص بالكاميرا (OCR) عبر Tesseract.js (تحميل كسول عند الحاجة فقط)
// - البحث عن الكود في قاعدة المعرفة الحالية (Firestore)
// - عرض/إضافة/اعتماد العطل ضمن نظام الصلاحيات الموجود
//
// يتبع نفس نمط workflow.js: حالة على مستوى الموديول + تفويض
// أحداث change على document (لأن innerHTML يُعاد رسمه بالكامل عند التنقل)
// ============================================================

import { compressImage } from './components/attachmentPicker.js';

import {
  findMachineErrorByCode,
  saveMachineErrorApi,
  verifyMachineErrorApi,
  logMachineErrorOccurrenceApi,
  fetchMachineErrorHistoryApi,
  fetchAllMachineErrorsApi
} from './services/api.js';
import { translations } from './config.js';

// إصلاح (ترجمة شاملة): كل نصوص هذه الميزة (رسائل الحالة، تنبيهات،
// عناوين النتائج، النموذج الجديد) كانت ثابتة بالعربي - دلوقتي
// بتتقرأ من translations.errorScanner حسب window.currentLang
function t() {
  const currentLang = window.currentLang || "ar";
  return (translations[currentLang] || translations.ar).errorScanner;
}

// ============================================================
// حالة الموديول
// ============================================================

let scannedImage = null;      // الصورة بعد الضغط (Base64) لعرضها وحفظها
let lastFoundError = null;    // آخر نتيجة عطل تم العثور عليها (لإجراءات الاعتماد/التسجيل)
let isScanning = false;       // true أثناء تشغيل OCR (لمنع تشغيل مزدوج + التحكم بالـ Spinner)

// ============================================================
// تحميل مكتبة Tesseract.js بشكل كسول (مرة واحدة فقط عند الحاجة)
// حتى لا يتم تحميلها على كل صفحات التطبيق دون داعٍ
// ============================================================

let tesseractLoadPromise = null;

function loadTesseract() {
  if (window.Tesseract) {
    return Promise.resolve(window.Tesseract);
  }

  if (tesseractLoadPromise) {
    return tesseractLoadPromise;
  }

  tesseractLoadPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
    script.onload = () => resolve(window.Tesseract);
    script.onerror = () => reject(new Error(t().tesseractLoadError));
    document.head.appendChild(script);
  });

  return tesseractLoadPromise;
}

// ============================================================
// استخراج كود العطل الأكثر ترجيحاً من النص المستخرج
// أنماط شائعة: E-12، ERR204، F-05، ALM 21، Fault 108 ...الخ
// ============================================================

function extractErrorCode(rawText) {
  const text = String(rawText || '');

  const patterns = [
    /\b(ERR|ERROR|ALM|ALARM|FAULT|FLT)[-_\s]?\d{1,5}\b/i,
    /\b[A-Z]{1,4}[-_]\d{1,5}\b/,
    /\b[A-Z]{1,3}\d{2,5}\b/
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      return match[0].toUpperCase().replace(/\s+/g, ' ').trim();
    }
  }

  return '';
}

// ============================================================
// قوائم الخطوط والماكينات - مطابقة لنفس القوائم المستخدمة في
// باقي التطبيق (IssueView / SuggestionView) للحفاظ على الاتساق
// ============================================================
//
// إصلاح (بند 1 - توحيد شامل): كانت هذه القائمة نسخة مكررة يدوياً من
// machines.js (وكانت فعلياً ناقصة نوع "STRAP" منها - دليل عملي على
// خطر تكرار نفس البيانات في أكتر من مكان). دلوقتي بقت مُشتقّة مباشرة
// من نفس المصدر الموحّد (machines.js -> Firestore)، فأي تعديل يعمله
// الأدمن من صفحة "إدارة الماكينات" بينعكس هنا تلقائياً كمان.
//
// getErrorScannerMachineOptions() دالة (مش قيمة ثابتة) عشان تفضل
// دايماً بتاخد أحدث نسخة من الكاش وقت الاستدعاء الفعلي (راجع
// ErrorScannerView.js) حتى لو الكاش اتحدّث بعد أول تحميل للصفحة

import { getMachineTypeEntries } from './machines.js';

export const LINE_OPTIONS = ['Line 1', 'Line 2'];

export function getErrorScannerMachineOptions() {
  return getMachineTypeEntries({ includeInactive: false }).map(m => m.key);
}

function buildOptions(list, selected) {
  return `<option value="" disabled ${selected ? '' : 'selected'}>${t().selectPlaceholder}</option>` +
    list.map(v => `<option value="${v}" ${v === selected ? 'selected' : ''}>${v}</option>`).join('');
}

// ============================================================
// عناصر واجهة مشتركة (اختصارات)
// ============================================================

function el(id) {
  return document.getElementById(id);
}

// إصلاح (isScanning + Spinner): showSpinner اختياري - بيضيف نفس شكل
// الـ Spinner المستخدم بالفعل في splash screen بالتطبيق (index.html)
// دون أي تعديل على أي Styling/Layout حالي في باقي الصفحة
function setStatus(message, isError = false, showSpinner = false) {
  const box = el('errScanStatus');
  if (!box) return;

  if (showSpinner) {
    box.innerHTML = `
      <span class="inline-flex items-center justify-center gap-2">
        <span class="w-3.5 h-3.5 border-2 border-blue-400 border-t-transparent rounded-full animate-spin"></span>
        <span>${message}</span>
      </span>`;
  } else {
    box.textContent = message;
  }

  box.classList.toggle('text-red-400', isError);
  box.classList.toggle('text-blue-400', !isError);
}

// ============================================================
// دوال مساعدة لبحث العطل اليدوي وتصفية نوع الماكينة
// ============================================================

function normalizeSearchTerm(term) {
  return String(term || '').trim().toLowerCase();
}

async function fetchAllMachineErrors() {
  const result = await fetchAllMachineErrorsApi();
  return Array.isArray(result.data) ? result.data : [];
}

function matchesMachineError(error, searchTerm) {
  const normalized = normalizeSearchTerm(searchTerm);
  return (
    String(error.errorCode || '').toLowerCase().includes(normalized) ||
    String(error.errorMessage || '').toLowerCase().includes(normalized) ||
    String(error.machine || '').toLowerCase().includes(normalized) ||
    String(error.line || '').toLowerCase().includes(normalized) ||
    String(error.cause || '').toLowerCase().includes(normalized) ||
    String(error.solution || '').toLowerCase().includes(normalized)
  );
}

function chooseErrorByMachineType(candidates, selectedMachineType) {
  if (!selectedMachineType || candidates.length <= 1) {
    return candidates[0] || null;
  }
  return candidates.find(error => error.machine === selectedMachineType) || null;
}

async function searchMachineErrorsByText(searchTerm) {
  const allErrors = await fetchAllMachineErrors();
  return allErrors.filter(error => matchesMachineError(error, searchTerm));
}

async function fetchMachineErrorsByCode(code) {
  const normalizedCode = normalizeSearchTerm(code);
  const allErrors = await fetchAllMachineErrors();
  return allErrors.filter(error => normalizeSearchTerm(error.errorCode) === normalizedCode);
}

// ============================================================
// معالجة اختيار/التقاط صورة شاشة العطل + تشغيل OCR
// ============================================================

document.addEventListener('change', async (e) => {
  if (!e.target || (e.target.id !== 'errScanCamera' && e.target.id !== 'errScanGallery')) {
    return;
  }

  const file = e.target.files[0];
  if (!file) return;

  if (!file.type.startsWith('image/')) {
    alert(t().notImage);
    return;
  }

  if (file.size > 10 * 1024 * 1024) {
    alert(t().fileTooLarge);
    return;
  }

  // إصلاح (isScanning): منع تشغيل مسح جديد أثناء مسح قائم بالفعل
  if (isScanning) return;
  isScanning = true;

  try {
    setStatus(t().preparingImage);

    scannedImage = await compressImage(file, 900, 0.75);

    const preview = el('errScanPreview');
    if (preview) {
      preview.src = scannedImage;
      preview.classList.remove('hidden');
    }

    // إصلاح (Spinner أثناء القراءة): "جاري قراءة الشاشة..." + Spinner
    setStatus(t().readingOcr, false, true);

    const Tesseract = await loadTesseract();
    // إصلاح (دعم عربي + إنجليزي): شاشات الماكينات ممكن تحتوي نص عربي
    // كمان (رسائل/تعليمات) - ara+eng بيحسّن التعرف عليها مع الإنجليزي
    const result = await Tesseract.recognize(scannedImage, 'ara+eng');
    const rawText = result?.data?.text || '';

    const codeInput = el('errScanCode');
    const messageInput = el('errScanMessage');

    const suggestedCode = extractErrorCode(rawText);

    // إصلاح (استخراج Message بنمط صريح): لو النص فيه "Message: ..."
    // بشكل صريح بناخده كما هو، وإلا نرجع لنفس السلوك القديم (كل
    // النص المستخرج) عشان مانفقدش أي معلومة لو الشاشة مالهاش تنسيق
    // "Message:" واضح
    const messageMatch = rawText.match(/Message[:：]\s*(.+)/i);
    const extractedMessage = messageMatch ? messageMatch[1].trim() : rawText.trim();

    if (codeInput) codeInput.value = suggestedCode;
    if (messageInput) messageInput.value = extractedMessage;

    setStatus(
      suggestedCode
        ? t().codeExtracted.replace('{code}', suggestedCode)
        : t().codeNotFound
    );

    // إصلاح (بحث تلقائي بعد نجاح OCR): لو فيه كود اتستخرج فعلاً،
    // نشغّل البحث فوراً بنفس القيمة المستخرجة مباشرة (مش من قراءة
    // state/DOM قديمة) - لو مفيش كود واضح، سايبين الأمر للمستخدم
    // يراجع النص ويبحث يدوياً زي ما كان بالظبط
    if (suggestedCode) {
      await window.searchMachineError(suggestedCode);
    }

  } catch (err) {
    console.error('OCR Error:', err);
    setStatus(t().ocrError, true);
  } finally {
    isScanning = false;
  }
});

// ============================================================
// البحث عن العطل في قاعدة المعرفة
// ============================================================

// إصلاح (بحث تلقائي بعد OCR): overrideCode/overrideManual اختياريين -
// لو اتبعتوا (من مسار OCR) بنستخدمهم مباشرة كما هم، بدل قراءة قيمة
// الحقول من الـ DOM. الاستدعاء العادي من الزر (بدون parameters) يفضل
// شغال بالظبط زي ما كان.
window.searchMachineError = async function (overrideCode, overrideManual) {

  const codeInput = el('errScanCode');
  const code = (overrideCode !== undefined && overrideCode !== null && overrideCode !== '')
    ? String(overrideCode).trim()
    : (codeInput?.value?.trim() || '');
  const manualInput = el('errScanManual');
  const manualSearch = (overrideManual !== undefined && overrideManual !== null && overrideManual !== '')
    ? String(overrideManual).trim()
    : (manualInput?.value?.trim() || '');
  const selectedMachineType = String(window.selectedMachineType || '').trim();

  if (!code && !manualSearch) {
    alert(t().enterCodeFirst);
    return;
  }

  const resultsBox = el('errorScanResults');
  if (resultsBox) {
    resultsBox.innerHTML = `<div class="text-center text-gray-400 text-xs py-6">${t().searchingKb}</div>`;
  }

  // أولاً: البحث برقم العطل إن وجد
  if (code) {
    const result = await findMachineErrorByCode(code);

    if (result.status !== 'success') {
      if (resultsBox) {
        resultsBox.innerHTML = `<div class="text-center text-red-400 text-xs py-6">❌ ${result.message || t().genericSearchError}</div>`;
      }
      return;
    }

    if (result.found) {
      let foundError = result.data;

      if (selectedMachineType) {
        const sameCodeErrors = await fetchMachineErrorsByCode(code);
        const matchedByMachine = chooseErrorByMachineType(sameCodeErrors, selectedMachineType);

        if (sameCodeErrors.length > 1 && !matchedByMachine) {
          lastFoundError = null;
          renderNotFound(code);
          return;
        }

        if (matchedByMachine) {
          foundError = matchedByMachine;
        }
      }

      lastFoundError = foundError;
      renderFoundError(foundError);
      loadErrorHistory(foundError.errorCode);
      return;
    }
  }

  // ثانياً: البحث اليدوي إن كان هناك نص
  if (manualSearch) {
    const candidates = await searchMachineErrorsByText(manualSearch);

    if (candidates.length) {
      const matchedByMachine = chooseErrorByMachineType(candidates, selectedMachineType);

      if (candidates.length > 1 && selectedMachineType && !matchedByMachine) {
        lastFoundError = null;
        renderNotFound(manualSearch);
        return;
      }

      const foundError = matchedByMachine || candidates[0];
      lastFoundError = foundError;
      renderFoundError(foundError);
      loadErrorHistory(foundError.errorCode);
      return;
    }
  }

  lastFoundError = null;
  renderNotFound(code || manualSearch || '');

};

// ============================================================
// عرض نتيجة: عطل موجود
// ============================================================

function renderFoundError(data) {
  const resultsBox = el('errorScanResults');
  if (!resultsBox) return;

  const tr = t();
  const isPending = data.status === 'pending_review';
  const canVerify =
    isPending &&
    typeof window.hasPermission === 'function' &&
    window.hasPermission('machines');

  resultsBox.innerHTML = `
    <div class="bg-[#1E293B] rounded-2xl p-4 border border-emerald-500/30 shadow-lg space-y-3">

      <div class="flex items-center justify-between">
        <h3 class="text-base font-bold text-emerald-400">${tr.foundTitle}</h3>
        <span class="text-[10px] px-2 py-1 rounded-full font-bold ${isPending ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'}">
          ${isPending ? tr.pendingReviewStatus : tr.verifiedStatus}
        </span>
      </div>

      <div class="text-sm">
        <div class="text-gray-400 text-[11px]">${tr.errorCodeLabel}</div>
        <div class="font-bold text-blue-400">${data.errorCode || '-'}</div>
      </div>

      ${data.machine || data.line ? `
      <div class="text-sm">
        <div class="text-gray-400 text-[11px]">${tr.machineLineLabel}</div>
        <div class="text-gray-100">${data.machine || '-'} ${data.line ? '· ' + data.line : ''}</div>
      </div>` : ''}

      <div class="text-sm">
        <div class="text-gray-400 text-[11px]">${tr.causeLabel}</div>
        <div class="text-gray-100">${data.cause || tr.notSpecified}</div>
      </div>

      <div class="text-sm">
        <div class="text-gray-400 text-[11px]">${tr.solutionLabel}</div>
        <div class="text-gray-100">${data.solution || tr.notSpecified}</div>
      </div>

      <div class="text-sm">
        <div class="text-gray-400 text-[11px]">${tr.stepsLabel}</div>
        <div class="text-gray-100 whitespace-pre-line">${data.steps || tr.notSpecified}</div>
      </div>

      <div class="grid grid-cols-1 gap-2 pt-2">
        <button onclick="window.logErrorOccurrence()" class="w-full py-2.5 bg-blue-600 hover:bg-blue-500 rounded-xl font-bold text-xs text-white transition active:scale-95">
          ${tr.logOccurrenceBtn}
        </button>
        ${canVerify ? `
        <button onclick="window.verifyMachineError('${data.id}')" class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-xs text-white transition active:scale-95">
          ${tr.verifyBtn}
        </button>` : ''}
        <button onclick="window.resetErrorScanner()" class="w-full py-2.5 bg-gray-700 hover:bg-gray-600 rounded-xl font-bold text-xs text-white transition active:scale-95">
          ${tr.scanAnotherBtn}
        </button>
      </div>

      <div id="errorHistoryBox" class="pt-2"></div>

    </div>
  `;
}

// ============================================================
// عرض سجل الأعطال السابق (Error History) لهذا الكود
// ============================================================

async function loadErrorHistory(code) {
  const box = el('errorHistoryBox');
  if (!box) return;

  const tr = t();
  const currentLang = window.currentLang || "ar";

  box.innerHTML = `<div class="text-center text-gray-500 text-[11px] py-2">${tr.loadingHistory}</div>`;

  const result = await fetchMachineErrorHistoryApi(code);

  if (result.status !== 'success' || !result.data || !result.data.length) {
    box.innerHTML = `<div class="text-center text-gray-500 text-[11px] py-2">${tr.noHistory}</div>`;
    return;
  }

  box.innerHTML = `
    <div class="text-[11px] font-bold text-gray-400 mb-1">${tr.historyTitle}</div>
    <div class="space-y-1.5">
      ${result.data.map(log => `
        <div class="bg-[#0F172A] border border-gray-800 rounded-lg p-2 text-[11px] text-gray-300 flex items-center justify-between">
          <span>${log.machine || '-'} ${log.line ? '· ' + log.line : ''}</span>
          <span class="text-gray-500">${log.scannedAt ? new Date(log.scannedAt).toLocaleDateString(currentLang === 'ar' ? 'ar-EG' : 'en-US') : ''}</span>
        </div>
      `).join('')}
    </div>
  `;
}

// ============================================================
// عرض نتيجة: عطل غير موجود -> نموذج إضافة عطل جديد
// ============================================================

function renderNotFound(code) {
  const resultsBox = el('errorScanResults');
  if (!resultsBox) return;

  const tr = t();

  resultsBox.innerHTML = `
    <div class="bg-[#1E293B] rounded-2xl p-4 border border-red-500/30 shadow-lg space-y-3">
      <h3 class="text-sm font-bold text-red-400">${tr.notFoundTitle}</h3>
      <p class="text-[11px] text-gray-400">${tr.notFoundDesc}</p>

      <div>
        <label class="block mb-1 text-[11px] font-bold text-gray-300">${tr.lineLabel}</label>
        <select id="errNewLine" class="w-full p-2.5 rounded-lg bg-[#0F172A] border border-gray-700 text-white text-xs appearance-none">
          ${buildOptions(LINE_OPTIONS)}
        </select>
      </div>

      <div>
        <label class="block mb-1 text-[11px] font-bold text-gray-300">${tr.machineLabelOnly}</label>
        <select id="errNewMachine" class="w-full p-2.5 rounded-lg bg-[#0F172A] border border-gray-700 text-white text-xs appearance-none">
          ${buildOptions(getErrorScannerMachineOptions())}
        </select>
      </div>

      <div>
        <label class="block mb-1 text-[11px] font-bold text-gray-300">${tr.causeLabel}</label>
        <textarea id="errNewCause" rows="2" class="w-full p-2.5 rounded-lg bg-[#0F172A] border border-gray-700 text-white text-xs resize-none"></textarea>
      </div>

      <div>
        <label class="block mb-1 text-[11px] font-bold text-gray-300">${tr.solutionLabel}</label>
        <textarea id="errNewSolution" rows="2" class="w-full p-2.5 rounded-lg bg-[#0F172A] border border-gray-700 text-white text-xs resize-none"></textarea>
      </div>

      <div>
        <label class="block mb-1 text-[11px] font-bold text-gray-300">${tr.stepsLabel}</label>
        <textarea id="errNewSteps" rows="3" class="w-full p-2.5 rounded-lg bg-[#0F172A] border border-gray-700 text-white text-xs resize-none"></textarea>
      </div>

      <button onclick="window.saveNewMachineError('${code.replace(/'/g, "\\'")}')" class="w-full py-2.5 bg-red-600 hover:bg-red-500 rounded-xl font-bold text-xs text-white transition active:scale-95">
        ${tr.addNewBtn}
      </button>
    </div>
  `;
}

// ============================================================
// حفظ عطل جديد
// ============================================================

window.saveNewMachineError = async function (code) {

  const machine = el('errNewMachine')?.value?.trim() || '';
  const line = el('errNewLine')?.value?.trim() || '';
  const cause = el('errNewCause')?.value?.trim() || '';
  const solution = el('errNewSolution')?.value?.trim() || '';
  const steps = el('errNewSteps')?.value?.trim() || '';
  const errorMessage = el('errScanMessage')?.value?.trim() || '';

  if (!cause && !solution) {
    alert(t().causeOrSolutionRequired);
    return;
  }

  const payload = {
    errorCode: code,
    errorMessage,
    machine,
    line,
    cause,
    solution,
    steps,
    image: scannedImage,
    createdBy: {
      name: localStorage.getItem('name') || '',
      phone: localStorage.getItem('phone') || '',
      job: localStorage.getItem('job') || ''
    }
  };

  const result = await saveMachineErrorApi(payload);

  if (result.status !== 'success') {
    alert('❌ ' + (result.message || t().genericSaveError));
    if (result.duplicate && result.data) {
      lastFoundError = result.data;
      renderFoundError(result.data);
      loadErrorHistory(result.data.errorCode);
    }
    return;
  }

  alert('✅ ' + result.message);
  window.searchMachineError();
};

// ============================================================
// تسجيل ظهور جديد لعطل معروف حالياً
// ============================================================

window.logErrorOccurrence = async function () {

  if (!lastFoundError) return;

  const payload = {
    errorCode: lastFoundError.errorCode,
    machine: lastFoundError.machine || '',
    line: lastFoundError.line || '',
    image: scannedImage,
    scannedBy: {
      name: localStorage.getItem('name') || '',
      job: localStorage.getItem('job') || ''
    }
  };

  const result = await logMachineErrorOccurrenceApi(payload);

  if (result.status === 'success') {
    alert(t().occurrenceLogged);
    loadErrorHistory(lastFoundError.errorCode);
  } else {
    alert('❌ ' + (result.message || t().occurrenceLogFailed));
  }

};

// ============================================================
// اعتماد عطل قيد المراجعة
// ============================================================

window.verifyMachineError = async function (errorId) {

  const result = await verifyMachineErrorApi(errorId);

  alert(result.message || (result.status === 'success' ? t().verifiedSuccess : t().genericError));

  if (result.status === 'success') {
    window.searchMachineError();
  }

};

// ============================================================
// إعادة ضبط الماسح للبحث عن عطل آخر
// ============================================================

window.resetErrorScanner = function () {

  scannedImage = null;
  lastFoundError = null;

  const preview = el('errScanPreview');
  if (preview) {
    preview.src = '';
    preview.classList.add('hidden');
  }

  const codeInput = el('errScanCode');
  if (codeInput) codeInput.value = '';

  const messageInput = el('errScanMessage');
  if (messageInput) messageInput.value = '';

  const resultsBox = el('errorScanResults');
  if (resultsBox) resultsBox.innerHTML = '';

  setStatus(t().readyStatus);
};