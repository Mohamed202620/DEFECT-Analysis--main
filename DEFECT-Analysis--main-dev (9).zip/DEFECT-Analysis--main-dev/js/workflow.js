import { fetchTicketsApi, fetchTicketCountsApi } from './services/api.js';
// إصلاح M1: جلب الدور والمستخدم الحالي عشان نمرّرهم لـ fetchTicketsApi
// في loadDashboardStats() بدل ما تجيب كل التذاكر دايماً بدون فلترة
import { getCurrentRole } from './permissions.js';
// إضافة: نفس دوال الحساب المستخدمة في صفحة الإحصائيات (statistics.js)
// اتعملها export من هناك بدون تغيير منطقها، عشان نعرض نفس الأرقام
// (MTTR / أكثر ماكينة / أفضل فني) في كارتات الرئيسية الجديدة من
// غير ما نكرر الكود ومن غير أي استعلام إضافي على قاعدة البيانات
import { computeMTTR, computeTopMachines, computeTechnicianPerformance } from './statistics.js';
// إضافة: مفاتيح الترجمة عشان الرسم البياني في الرئيسية (أيام
// الأسبوع + أسماء الأعمدة) ماتفضلش ثابتة بالعربي لما اللغة تتغيّر -
// نفس translations المستخدمة في كل الملفات التانية، بدون تكرار
import { translations } from './config.js';
// إصلاح (تنظيف/Refactor): isClosedStatus بقت مستوردة من ملف ثوابت
// مشترك (ticketStatusConstants.js) بدل تعريفها محلياً هنا مكررة مع
// نفس التعريف في statistics.js بالظبط
import { isClosedStatus, isOverdueTicket, parseTicketDate } from './ticketStatusConstants.js';
// مكوّن اختيار المرفقات المتعددة الموحّد (اختيار أكثر من صورة دفعة
// واحدة + إضافة صور لاحقًا بدون فقدان القديمة + حذف مستقل لكل صورة) -
// مُستخدم هنا لفورم "تسجيل عطل" (راجع initIssueAttachments تحت)
import { initAttachmentPicker, getAttachmentFiles, resetAttachmentFiles, compressImage } from './components/attachmentPicker.js';
export { compressImage };

// ==========================================
// منطق معالجة وحفظ بلاغات الأعطال (Issue Logic)
// ==========================================
// ملاحظة (تنظيف/Refactor): تمت إزالة نظام "دفعات العيوب" القديم
// (defectImages / resetDefectForm / compressImage / handleDefectFile /
// saveDefectData) من هنا - كان يعتمد على عناصر DOM (defectName,
// imgPreview0-2, imgCounter, submitBtn, lineSelect, stageSelect,
// defectLocation, defectDesc) غير موجودة في أي View حالي بالمشروع.
// النظام الحالي الفعلي لتسجيل الأعطال هو "issue" (راجع IssueView.js
// و window.confirmIssue تحت) وهو المُستخدم من MaintenanceView.js.

// تفعيل مكوّن اختيار الصور المتعددة (اختيار أكثر من صورة دفعة واحدة
// + إضافة صور لاحقًا + حذف مستقل لكل صورة) لفورم تسجيل عطل - يُستدعى
// من renderCore.js AUTO LOAD بعد إدراج HTML الفورم فعلياً في الصفحة
export function initIssueAttachments() {
  initAttachmentPicker("issueImages", {
    maxFileSizeMB: 10,
    emptyText: "لا توجد صور مرفقة"
  });
}
window.initIssueAttachments = initIssueAttachments;

// دالة حفظ وإرسال البلاغ المربوطة بزر الحفظ
window.confirmIssue = async function() {
  const line = document.getElementById('issueLine')?.value;
  const machine = document.getElementById('issueMachine')?.value;
  const priority = document.getElementById('issuePriority')?.value;
  const type = document.querySelector('input[name="issueType"]:checked')?.value || "Breakdown";
  const category = document.getElementById('issueCategory')?.value;
  const description = document.getElementById('issueDescription')?.value?.trim();
  const location = document.getElementById('issueLocation')?.value?.trim();
  const suggestion = document.getElementById('issueSuggestion')?.value?.trim();
  // ✅ توليد معرف فريد للبلاغ بنفس أسلوب defectId
  // (العنصر generatedIssueId# غير موجود فعلياً في IssueView، لذا كان
  // issueId يصل دائماً كـ undefined قبل هذا التعديل)
  const issueId = "IS-" + Date.now();

  if (!line || !machine || !category || !description) {
    alert("⚠️ يرجى استكمال البيانات الأساسية: (الخط، الماكينة، نوع العطل، والوصف)");
    return;
  }

  const btn = document.querySelector('button[onclick="window.confirmIssue()"]');
  const originalText = btn ? btn.innerHTML : "💾 حفظ وإرسال البلاغ";
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = "⏳ جاري الإرسال...";
  }

  const payload = {
    // ✅ 4. تم إزالة action: "saveIssue"
    issueId,
    line,
    machine,
    priority,
    type,
    category,
    description,
    location,
    suggestion,
    // الصور المرفقة (صفر أو أكثر) - مُجمَّعة من مكوّن الاختيار
    // المتعدد (attachmentPicker.js)، بدل صورة واحدة فقط كالسابق
    images: getAttachmentFiles("issueImages"),

    // اسم/معرّف المُبلّغ بشكل مسطّح (يُستخدم في دورة حياة التذكرة:
    // قواعد الأمان وواجهة "Review & Closure" - راجع ticketsBoard.js)
    reportedBy: localStorage.getItem("name") || "",
    reportedByUid: localStorage.getItem("userId") || "",

    reporter: {
      name: localStorage.getItem("name") || "",
      job: localStorage.getItem("job") || "",
      department: localStorage.getItem("department") || "",
      shift: localStorage.getItem("shift") || ""
    },

    // دورة حياة التذكرة تبدأ دائماً بـ pending (كانت "open" سابقاً -
    // تم تصحيحها لتطابق حالات: pending -> assigned -> resolved ->
    // closed | reopened)
    status: "pending",
    createdAt: new Date().toISOString()
  };

  try {
    const { saveIssueApi } = await import('./services/api.js');
    const res = await saveIssueApi(payload);
    if (res && (res.status === 'success' || res.status === 'queued')) {
      alert(
        res.status === 'queued'
          ? "📴 لا يوجد اتصال حالياً - تم حفظ البلاغ محلياً وسيتم إرساله تلقائياً عند عودة الإنترنت"
          : "✅ تم حفظ وإرسال البلاغ بنجاح"
      );
      
      // ✅ 3. إعادة ضبط حقول البلاغ بعد الحفظ قبل العودة للرئيسية
      resetAttachmentFiles("issueImages");
      if (document.getElementById("issueDescription")) document.getElementById("issueDescription").value = "";
      if (document.getElementById("issueSuggestion")) document.getElementById("issueSuggestion").value = "";
      if (document.getElementById("issueLocation")) document.getElementById("issueLocation").value = "";

      if (typeof window.navigateTo === 'function') {
        window.navigateTo('home');
      }
    } else {
      alert("❌ حدث خطأ أثناء الإرسال: " + (res?.message || "خطأ غير معروف"));
    }
  } catch (err) {
    alert("❌ خطأ بالاتصال: " + err.message);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = originalText;
    }
  }
};

// ==========================================
// رسم بياني للأعطال والأداء (Home Chart)
// ديناميكي بالكامل مع فلاتر زمنية [يومي / أسبوعي / شهري] - بيتجمّع
// من نفس تذاكر Firestore (حقل createdAt) اللي بيجيبها loadDashboardStats()
// من غير أي طلب إضافي لقاعدة البيانات، وبيتحدّث بـ chart.update()
// من غير ما يعيد تحميل الصفحة أو يهدم الرسم البياني
// ==========================================

let chartInstance = null;

// الفلتر الزمني الحالي - بيفضل محفوظ حتى لو المستخدم بدّل صفحة ورجع
export let currentChartRange = 'weekly';

// شكل عرض الرسم البياني الحالي - بيفضل محفوظ برضه زي الفلتر الزمني
// 'area' (خط + تعبئة، الشكل الافتراضي القديم) / 'line' (خط بدون تعبئة) / 'bar' (أعمدة)
export let currentChartType = 'area';

// نفس تصنيف "مغلق" المستخدم في loadDashboardStats بالظبط - مستوردة من
// ملف الثوابت المشترك (ticketStatusConstants.js) عشان الرسم البياني
// وكارتات الـ KPI يتفقوا في نفس المنطق مع باقي الملفات (statistics.js...)

// آخر نسخة من مصفوفة التذاكر (تم جلبها فعلياً من Firestore عبر
// fetchTicketsApi داخل loadDashboardStats) - بتتخزن هنا عشان تبديل
// الفلتر يعيد الحساب فوراً محلياً من غير أي Round-trip جديد للسيرفر
let lastTicketsSnapshot = [];

// ------------------------------------------------------------
// تجميع بيانات الرسم البياني حسب الفلتر المطلوب من مصفوفة التذاكر
// مع حماية شاملة ضد أي قيم undefined واستخراج دقيق للتواريخ
// ------------------------------------------------------------
function buildChartDataset(tickets, range, lang) {
  const currentLang = lang || window.currentLang || 'ar';
  const t = (translations[currentLang] || translations.ar || translations.en)?.home || {};
  const now = new Date();

  // آلية أمان لتنظيف مصفوفة العناوين ومنع مرور أي undefined نهائياً
  const sanitizeLabels = (rawList, fallbackPrefix = '') => {
    return (rawList || []).map((item, idx) => {
      if (item !== null && item !== undefined && String(item).trim() !== '' && String(item) !== 'undefined') {
        return String(item);
      }
      return `${fallbackPrefix} ${idx + 1}`.trim();
    });
  };

  if (range === 'daily') {
    // توزيع أعطال اليوم الحالي على مدار 24 ساعة (00:00 → 23:00)
    const labels = Array.from({ length: 24 }, (_, h) => String(h).padStart(2, '0') + ':00');
    const open = new Array(24).fill(0);
    const closed = new Array(24).fill(0);
    const todayStr = now.toDateString();

    (tickets || []).forEach(ticket => {
      const created = parseTicketDate(ticket);
      if (!created || created.toDateString() !== todayStr) return;

      const hour = created.getHours();
      if (hour >= 0 && hour < 24) {
        if (isClosedStatus(ticket.status)) closed[hour]++;
        else open[hour]++;
      }
    });

    return { labels: sanitizeLabels(labels, currentLang === 'en' ? 'Hour' : 'ساعة'), open, closed };
  }

  if (range === 'monthly') {
    // توزيع أعطال الشهر الحالي على أسابيعه (حتى 5 أسابيع حسب طول الشهر)
    const year = now.getFullYear();
    const month = now.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const weeksCount = Math.ceil(daysInMonth / 7);

    // استخراج بادئة الأسبوع مع بديل آمن يمنع ظهور 'undefined'
    const weekPrefix = (t.chartWeekShort && typeof t.chartWeekShort === 'string' && t.chartWeekShort !== 'undefined')
      ? t.chartWeekShort
      : (currentLang === 'en' ? 'Week' : 'الأسبوع');

    const labels = Array.from({ length: weeksCount }, (_, i) => `${weekPrefix} ${i + 1}`);
    const open = new Array(weeksCount).fill(0);
    const closed = new Array(weeksCount).fill(0);

    (tickets || []).forEach(ticket => {
      const created = parseTicketDate(ticket);
      if (!created) return;
      if (created.getFullYear() !== year || created.getMonth() !== month) return;

      const weekIndex = Math.min(weeksCount - 1, Math.floor((created.getDate() - 1) / 7));
      if (weekIndex >= 0 && weekIndex < weeksCount) {
        if (isClosedStatus(ticket.status)) closed[weekIndex]++;
        else open[weekIndex]++;
      }
    });

    return { labels: sanitizeLabels(labels, weekPrefix), open, closed };
  }

  // الافتراضي: أسبوعي - من السبت إلى الجمعة (أسبوع العمل الحالي)
  const fallbackWeekdays = currentLang === 'en'
    ? ["Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri"]
    : ["السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"];

  const rawLabels = (Array.isArray(t.weekdays) && t.weekdays.length === 7)
    ? t.weekdays
    : fallbackWeekdays;

  const labels = rawLabels.map((lbl, idx) => {
    if (lbl && typeof lbl === 'string' && lbl.trim() !== '' && lbl !== 'undefined') {
      return lbl;
    }
    return fallbackWeekdays[idx] || (currentLang === 'en' ? `Day ${idx + 1}` : `يوم ${idx + 1}`);
  });

  const open = new Array(7).fill(0);
  const closed = new Array(7).fill(0);

  const startOfWeek = new Date(now);
  startOfWeek.setHours(0, 0, 0, 0);
  // عدد الأيام منذ آخر سبت (JS: الأحد=0 ... السبت=6)
  const daysSinceSaturday = (now.getDay() + 1) % 7;
  startOfWeek.setDate(startOfWeek.getDate() - daysSinceSaturday);

  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(endOfWeek.getDate() + 7);

  (tickets || []).forEach(ticket => {
    const created = parseTicketDate(ticket);
    if (!created) return;
    if (created < startOfWeek || created >= endOfWeek) return;

    const dayIndex = (created.getDay() + 1) % 7; // 0=السبت ... 6=الجمعة
    if (dayIndex >= 0 && dayIndex < 7) {
      if (isClosedStatus(ticket.status)) closed[dayIndex]++;
      else open[dayIndex]++;
    }
  });

  return { labels: sanitizeLabels(labels, currentLang === 'en' ? 'Day' : 'يوم'), open, closed };
}

// إنشاء تدرّج لوني عمودي لطبقة التعبئة تحت كل خط (بديل أنيق للون
// الفلات الثابت السابق - بيبهت تدريجياً لحد الشفافية عند قاعدة الرسم)
function buildGradient(ctx, area, hexColor, alpha) {
  if (!area) return `${hexColor}${alpha}`;
  const gradient = ctx.createLinearGradient(0, area.top, 0, area.bottom);
  gradient.addColorStop(0, hexColor + '55');
  gradient.addColorStop(1, hexColor + '02');
  return gradient;
}

// ------------------------------------------------------------
// بناء الـ datasets حسب "شكل" الرسم البياني المختار (خط / مساحة / أعمدة)
// - line: خط بدون تعبئة تحته
// - area: نفس الشكل الافتراضي القديم (خط + تدرّج تعبئة)
// - bar: أعمدة بدل الخط
// ------------------------------------------------------------
function buildChartDatasets(data, type, t) {
  if (type === 'bar') {
    return [
      {
        label: t.kpiOpen,
        data: data.open,
        backgroundColor: 'rgba(245, 158, 11, 0.7)',
        borderColor: '#F59E0B',
        borderWidth: 1,
        borderRadius: 6
      },
      {
        label: t.kpiClosed,
        data: data.closed,
        backgroundColor: 'rgba(16, 185, 129, 0.7)',
        borderColor: '#10B981',
        borderWidth: 1,
        borderRadius: 6
      }
    ];
  }

  const fill = type === 'area';
  return [
    {
      label: t.kpiOpen,
      data: data.open,
      borderColor: '#F59E0B',
      backgroundColor: fill
        ? (context) => buildGradient(context.chart.ctx, context.chart.chartArea, '#F59E0B', '')
        : 'transparent',
      borderWidth: 2,
      pointRadius: 3,
      pointHoverRadius: 5,
      pointBackgroundColor: '#F59E0B',
      tension: 0.4,
      cubicInterpolationMode: 'monotone',
      fill
    },
    {
      label: t.kpiClosed,
      data: data.closed,
      borderColor: '#10B981',
      backgroundColor: fill
        ? (context) => buildGradient(context.chart.ctx, context.chart.chartArea, '#10B981', '')
        : 'transparent',
      borderWidth: 2,
      pointRadius: 3,
      pointHoverRadius: 5,
      pointBackgroundColor: '#10B981',
      tension: 0.4,
      cubicInterpolationMode: 'monotone',
      fill
    }
  ];
}

// ------------------------------------------------------------
// إنشاء/تحديث الرسم البياني
// - أول مرة (chartInstance غير موجود): بيتعمل new Chart()
// - أي تحديث بعد كده (تبديل فلتر/لغة/داتا جديدة): بنعدّل labels
//   والـ datasets في نفس الـ instance وننادي chart.update() بس،
//   من غير ما نهدم/نعيد إنشاء الكانفاس بالكامل
// ------------------------------------------------------------
export function renderMainChart(range = currentChartRange, tickets = lastTicketsSnapshot, type = currentChartType) {
  const canvas = document.getElementById('mainChart');
  if (!canvas) return;

  // ***** إصلاح مشكلة اختفاء الرسم البياني عند الرجوع للرئيسية *****
  // لما ننتقل لصفحة تانية، الكانفاس القديم (اللي chartInstance متعلّق
  // بيه) بيتشال من الـ DOM بالكامل. لو رجعنا للرئيسية تاني، renderCore.js
  // بيبني كانفاس جديد بنفس الـ id، لكن chartInstance فضل شايل مرجع
  // للكانفاس *القديم* الميت، فـ chart.update() كان بيتنفذ على حاجة
  // مش موجودة في الصفحة أصلاً وملهاش أي تأثير مرئي. الحل: لو الكانفاس
  // اللي في الـ DOM دلوقتي مختلف عن اللي الانستانس القديم متعلّق بيه،
  // نهدم الانستانس القديم ونسيبه يتعمل من جديد على الكانفاس الصحيح.
  if (chartInstance && chartInstance.canvas !== canvas) {
    chartInstance.destroy();
    chartInstance = null;
  }

  currentChartRange = range;
  window.mainChartRange = currentChartRange;
  currentChartType = ['line', 'area', 'bar'].includes(type) ? type : currentChartType;
  window.mainChartType = currentChartType;
  lastTicketsSnapshot = Array.isArray(tickets) ? tickets : lastTicketsSnapshot;

  const lang = window.currentLang || 'ar';
  const t = (translations[lang] || translations.ar || translations.en)?.home || {};
  const isRtl = lang === 'ar';

  const data = buildChartDataset(lastTicketsSnapshot, currentChartRange, lang);
  
  // طبقة أمان إضافية لضمان عدم تمرير undefined لـ Chart.js أبداً
  if (!Array.isArray(data.labels) || data.labels.length === 0) {
    data.labels = ['1', '2', '3', '4', '5', '6', '7'];
  } else {
    data.labels = data.labels.map((lbl, i) => {
      if (lbl === undefined || lbl === null || String(lbl).trim() === '' || String(lbl) === 'undefined') {
        return lang === 'en' ? `Point ${i + 1}` : `نقطة ${i + 1}`;
      }
      return String(lbl);
    });
  }

  const datasets = buildChartDatasets(data, currentChartType, t);
  const chartJsType = currentChartType === 'bar' ? 'bar' : 'line';

  // تغيير "شكل" الرسم (مثلاً من أعمدة لخط) بيحتاج هدم وإعادة إنشاء
  // الانستانس، لأن Chart.js مش بيدعم تبديل النوع الأساسي بسلاسة عن
  // طريق update() بس
  if (chartInstance && chartInstance.config.type !== chartJsType) {
    chartInstance.destroy();
    chartInstance = null;
  }

  if (chartInstance) {
    chartInstance.data.labels = data.labels;
    chartInstance.data.datasets[0].label = datasets[0].label;
    chartInstance.data.datasets[0].data = datasets[0].data;
    chartInstance.data.datasets[0].backgroundColor = datasets[0].backgroundColor;
    chartInstance.data.datasets[0].fill = datasets[0].fill;
    chartInstance.data.datasets[1].label = datasets[1].label;
    chartInstance.data.datasets[1].data = datasets[1].data;
    chartInstance.data.datasets[1].backgroundColor = datasets[1].backgroundColor;
    chartInstance.data.datasets[1].fill = datasets[1].fill;
    chartInstance.options.rtl = isRtl;
    chartInstance.update();
    updateChartRangeButtons(currentChartRange);
    updateChartTypeButtons(currentChartType);
    return;
  }

  chartInstance = new Chart(canvas, {
    type: chartJsType,
    data: {
      labels: data.labels,
      datasets
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      rtl: isRtl,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { labels: { color: '#9CA3AF', font: { size: 10 } }, rtl: isRtl },
        tooltip: { rtl: isRtl, textDirection: isRtl ? 'rtl' : 'ltr' }
      },
      scales: {
        x: { ticks: { color: '#9CA3AF' }, grid: { color: 'rgba(51, 65, 85, 0.2)' } },
        y: { ticks: { color: '#9CA3AF', precision: 0 }, grid: { color: 'rgba(51, 65, 85, 0.2)' }, beginAtZero: true }
      }
    }
  });

  updateChartRangeButtons(currentChartRange);
  updateChartTypeButtons(currentChartType);
}

// إبقاء initMainChart بنفس الاسم/التوقيع القديم (بينادي عليه
// renderCore.js AUTO LOAD بتاع صفحة الرئيسية) - بيرسم بأحدث فلتر
// محفوظ وبآخر تذاكر متوفرة (لسه هتتحدّث فعلياً لما loadDashboardStats
// يجيب البيانات الحقيقية بعد كده بلحظات)
export function initMainChart(customData = null) {
  // customData: مسار توافق قديم فقط (لا يوجد أي استدعاء حالي في
  // المشروع بيبعت بيانات جاهزة) - المسار الطبيعي الحالي هو رسم
  // آخر فلتر محفوظ من آخر تذاكر متوفرة، وبعدها loadDashboardStats()
  // بيجيب البيانات الحقيقية من Firestore ويحدّث الرسم فوراً
  if (customData && Array.isArray(customData.labels)) {
    lastTicketsSnapshot = [];
    renderMainChart(currentChartRange, []);
    chartInstance.data.labels = customData.labels;
    chartInstance.data.datasets[0].data = customData.open;
    chartInstance.data.datasets[1].data = customData.closed;
    chartInstance.update();
    return;
  }

  renderMainChart(currentChartRange, lastTicketsSnapshot);
}

window.initMainChart = initMainChart;

// ------------------------------------------------------------
// تبديل فلتر الرسم البياني (يُستدعى من أزرار Segmented Control في
// homeView.js) - إعادة حساب فوري من التذاكر المخزّنة محلياً + تحديث
// الرسم البياني (chart.update()) من غير أي إعادة تحميل للصفحة
// ------------------------------------------------------------
window.setMainChartRange = function (range) {
  if (!['daily', 'weekly', 'monthly'].includes(range)) return;
  renderMainChart(range, lastTicketsSnapshot);
};

// ------------------------------------------------------------
// تبديل "شكل" الرسم البياني (خط / مساحة / أعمدة) - بتُستدعى من
// أزرار الفلتر الجديدة في homeView.js، بنفس أسلوب setMainChartRange
// ------------------------------------------------------------
window.setMainChartType = function (type) {
  if (!['line', 'area', 'bar'].includes(type)) return;
  renderMainChart(currentChartRange, lastTicketsSnapshot, type);
};

// تحديث الشكل المرئي لأزرار الفلتر (النشط/غير النشط) بدون أي إعادة
// رسم لباقي الصفحة
function updateChartRangeButtons(activeRange) {
  const container = document.getElementById('chartRangeControl');
  if (!container) return;

  container.querySelectorAll('[data-range]').forEach(btn => {
    const isActive = btn.getAttribute('data-range') === activeRange;
    btn.classList.toggle('bg-blue-600', isActive);
    btn.classList.toggle('text-white', isActive);
    btn.classList.toggle('shadow-sm', isActive);
    btn.classList.toggle('dyn-text-muted', !isActive);
    btn.classList.toggle('opacity-60', !isActive);
  });
}

// تحديث الشكل المرئي لأزرار نوع الرسم البياني (النشط/غير النشط)،
// نفس منطق updateChartRangeButtons بالظبط
function updateChartTypeButtons(activeType) {
  const container = document.getElementById('chartTypeControl');
  if (!container) return;

  container.querySelectorAll('[data-chart-type]').forEach(btn => {
    const isActive = btn.getAttribute('data-chart-type') === activeType;
    btn.classList.toggle('bg-blue-600', isActive);
    btn.classList.toggle('text-white', isActive);
    btn.classList.toggle('shadow-sm', isActive);
    btn.classList.toggle('dyn-text-muted', !isActive);
    btn.classList.toggle('opacity-60', !isActive);
  });
}

window.updateChartRangeButtons = updateChartRangeButtons;

// ==========================================
// بيانات لوحة المتابعة الحقيقية (Dashboard Stats)
// كانت أرقام لوحة المتابعة (open/closed/today/total) ثابتة
// دائماً على صفر لأن window.dashboardData لم يكن يُملأ من أي
// مكان رغم وجود fetchTicketsApi جاهزة. تم ربطها الآن دون أي
// تغيير في بنية قاعدة البيانات - فقط قراءة من "tickets" الحالية
// ==========================================

export async function loadDashboardStats() {

  // إصلاح M1: جلب دور المستخدم وبياناته الحالية، وتمريرها لـ
  // fetchTicketsApi عشان كارتات لوحة المتابعة في الرئيسية تتفلتر
  // حسب الصلاحيات (Admin/Manager = الكل، وباقي الأدوار = بلاغاتي +
  // المُسندة إليّ فقط) بدل ما تجيب كل التذاكر لأي مستخدم
  const role = getCurrentRole();
  const myUid = localStorage.getItem("userId") || "";
  const myName = localStorage.getItem("name") || "";

  const sampleResult = await fetchTicketsApi({ role, myUid, myName, maxCount: 500 });

  if (!sampleResult || sampleResult.status !== 'success') {
    console.warn("[loadDashboardStats] Failed to fetch tickets:", sampleResult?.message || "Unknown error");
    return;
  }

  const tickets = Array.isArray(sampleResult.data) ? sampleResult.data : [];

  const todayStr = new Date().toDateString();

  let open = 0;
  let closed = 0;
  let today = 0;
  let overdue = 0;

  tickets.forEach(ticket => {
    if (isClosedStatus(ticket.status)) {
      closed++;
    } else {
      open++;
    }

    const created = parseTicketDate(ticket);
    if (created && created.toDateString() === todayStr) {
      today++;
    }

    if (isOverdueTicket(ticket)) {
      overdue++;
    }
  });

  const stats = {
    open,
    closed,
    today,
    overdue,
    total: tickets.length
  };

  window.dashboardData = stats;

  const setText = (id, value) => {
    const node = document.getElementById(id);
    if (node) node.textContent = value;
  };

  setText('statOpenCount', stats.open);
  setText('statClosedCount', stats.closed);
  setText('statTodayCount', stats.today);
  setText('statTotalCount', stats.total);
  setText('statOverdueCount', stats.overdue);

  // ============================================================
  // إضافة: تنبيه "بلاغ حرج"
  // ============================================================

  // تنبيه حي: فيه بلاغ مفتوح بأولوية "High"؟ (نستخدم tickets المفلترة هنا لأنها تخص المستخدم)
  const hasCritical = tickets.some(t => {
    const isOpen = !isClosedStatus(t.status);
    return isOpen && String(t.priority || '').trim() === 'High';
  });

  const criticalBadge = document.getElementById('criticalBadge');
  if (criticalBadge) {
    criticalBadge.classList.toggle('hidden', !hasCritical);
    criticalBadge.classList.toggle('flex', hasCritical);
  }
}

window.loadDashboardStats = loadDashboardStats;
