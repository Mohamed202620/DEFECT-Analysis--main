// ============================================================
// suggestionsApi.js
// مقترحات الكايزن (Kaizen Suggestions) - جزء مستخرج من
// services/api.js بدون أي تغيير في المنطق أو الأسماء المُصدَّرة.
//
// ============================================================
// المرحلة النهائية - دورة حياة مقترح الكايزن (Workflow)
// ============================================================
// new (جديد)
//   -> under_review (قيد المراجعة)   [أدمن]
//   -> rejected     (مرفوض)          [أدمن، سبب إجباري]
//
// under_review (قيد المراجعة)
//   -> in_progress  (قيد التنفيذ)    [أدمن، بعد الموافقة والإسناد لفني]
//   -> rejected     (مرفوض)          [أدمن، مسموح حتى لو بالفعل قيد المراجعة، سبب إجباري]
//   -> revision_requested (طلب تعديل) [أدمن، ملاحظات إجبارية]
//
// revision_requested (طلب تعديل)
//   -> under_review (رجوع للمراجعة بعد التعديل) [أدمن]
//
// in_progress (قيد التنفيذ)
//   -> implemented  (تم التنفيذ)     [الفني المسؤول المُسند إليه، أو أدمن]
//
// rejected / implemented = حالات نهائية (لا يوجد أي انتقال بعدها)
//
// الدور الإداري الوحيد المعتمد لهذا الـWorkflow هو "admin" فقط
// (لا يوجد PM/manager هنا) - التحقق من الصلاحية بيتم في الطبقتين:
//  ١) هنا (منطق العميل) - رفض سريع برسالة واضحة قبل أي طلب لـ Firestore
//  ٢) firestore.rules (الطبقة الحقيقية غير القابلة للالتفاف حولها من
//     الواجهة - راجع match /suggestions/{suggestionId} هناك)
// ============================================================

import { uploadBase64Images } from "./imageUpload.js";
import { getCurrentRole } from "../permissions.js";
import { fetchManagersAndAdminsApi } from "./usersApi.js";

import {
  db,
  collection,
  addDoc,
  getDocs,
  getDoc,
  doc,
  updateDoc,
  query,
  where,
  orderBy,
  onSnapshot
} from "../providers/backend/index.js";


// ============================================================
// KAIZEN SUGGESTIONS - مقترحات التحسين المستمر
// ============================================================


/**
 * حفظ مقترح كايزن في مجموعة "suggestions"
 */
export async function saveSuggestionApi(payload, { skipOfflineQueue = false } = {}) {
  if (!skipOfflineQueue && typeof navigator !== "undefined" && !navigator.onLine) {
    try {
      const { queueOfflineAction } = await import("./offlineQueue.js");
      const localId = await queueOfflineAction({ type: "new_suggestion", payload });
      return {
        status: "queued",
        localId,
        message: "لا يوجد اتصال بالإنترنت - تم حفظ المقترح محلياً وسيتم إرساله تلقائياً عند عودة الاتصال"
      };
    } catch (error) {
      console.error("Error queuing offline suggestion:", error);
      return { status: "error", message: "تعذر حفظ المقترح محلياً" };
    }
  }

  try {

    // دعم صورة واحدة (الاسم القديم "image" - للتوافق) أو أكثر من
    // صورة دفعة واحدة عبر "images" (الاسم الجديد)، ورفعها كلها على
    // ImgBB وتخزين الروابط فقط (imageUrls) بدل الـ Base64 الكامل
    const { image, images, ...restPayload } = payload;
    const imageList = Array.isArray(images) ? images : (image ? [image] : []);
    const imageUrls = await uploadBase64Images(imageList, "suggestion_" + Date.now());

    const docRef = await addDoc(
      collection(db, "suggestions"),
      {
        ...restPayload,
        ...(imageUrls.length && { imageUrls }),

        // معرّف صاحب المقترح الحقيقي (UID) - مطلوب لتوجيه إشعارات
        // تغيّر الحالة إليه لاحقاً (لا علاقة له بخاصية "مقترح مجهول"
        // اللي بتتحكم بس في العرض/الاسم الظاهر للآخرين، مش في توجيه
        // إشعارات صاحب المقترح نفسه)
        submittedByUid: localStorage.getItem("userId") || "",

        // مقترح جديد دايماً يبدأ "new" - أي قيمة status جاية من
        // الواجهة بتتجاهل عمداً هنا (نفس ما تفرضه قاعدة create في
        // firestore.rules) عشان محدش يقدر يبعت مقترح بحالة جاهزة
        // مسبقاً (زي "implemented" مباشرة)
        status: "new",
        createdAt: new Date().toISOString()
      }
    );

    // إصلاح (إشعارات): المقترح الجديد ما كانش بيبلّغ أي أدمن/مدير (بعكس
    // البلاغات الجديدة وإعادة الإرسال بعد التعديل) - الأدمن كان لازم يفتح
    // لوحة الكايزن بشكل دوري عشان يكتشفه. أي فشل هنا مايأثرش على نجاح الحفظ.
    notifyAdminsOfNewSuggestion(docRef.id, restPayload).catch(err => {
      console.error("Error notifying admins of new suggestion:", err);
    });

    return {
      status: "success",
      id: docRef.id,
      message: "تم إرسال مقترح الكايزن بنجاح"
    };

  } catch (error) {

    console.error("Error saving suggestion:", error);

    return {
      status: "error",
      message: error.message
    };

  }

}

// ============================================================
// لوحة متابعة الكايزن (Kaizen Board) - مراجعة واعتماد المقترحات
// نفس فكرة subscribeToTicketsBoardApi (Realtime + فلترة صلاحيات
// أولاً ثم فلترة الحالة محلياً بدون orderBy مع where عشان نتجنب
// أي Composite Index)، لكن مُنفَّذة بشكل مستقل هنا لمقترحات الكايزن
// ============================================================

export const KAIZEN_STATUSES = [
  "new", "under_review", "in_progress", "revision_requested", "rejected", "implemented"
];

// حالات نهائية - لا يوجد أي انتقال مسموح بعدها إطلاقاً
export const KAIZEN_FINAL_STATUSES = ["rejected", "implemented"];

/**
 * اشتراك لحظي (Realtime) في مقترحات الكايزن حسب الصلاحية والحالة
 * role: admin/manager (PM) → كل المقترحات
 * غير ذلك (فني/مهندس/عامل) → مقترحاته هو فقط (بالاسم، زي reportedBy
 * في نظام التذاكر)
 */
export function subscribeToSuggestionsBoardApi({ role, myName, myUid, status }, callback) {
  try {
    const suggestionsRef = collection(db, "suggestions");

    const emit = (itemsById) => {
      let items = Array.from(itemsById.values());

      // السجلات القديمة اللي اتسجلت قبل إضافة نظام الحالات
      // تُعتبر "جديد" افتراضياً
      if (status && status !== "all") {
        items = items.filter(s => (s.status || "new") === status);
      }

      items.sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
      callback({ status: "success", data: items });
    };

    const onErr = (error) => {
      console.error("Error subscribing to suggestions board:", error);
      callback({ status: "error", message: error.message });
    };

    if (role === "admin" || role === "manager") {
      return onSnapshot(
        query(suggestionsRef),
        (querySnapshot) => {
          const byId = new Map();
          querySnapshot.forEach(docSnap => byId.set(docSnap.id, { id: docSnap.id, ...docSnap.data() }));
          emit(byId);
        },
        onErr
      );
    }

    // إصلاح (تذكرة عالقة - Kaizen): غير الأدمن/المدير كانوا بيشوفوا
    // مقترحاتهم هم بس (name == myName). الفني المسؤول اللي الأدمن أسند له
    // تنفيذ مقترح "in_progress" مش صاحبه، فالمقترح ده عمره ما كان بيظهر في
    // لوحته ولا يقدر يسجّل التنفيذ (زر implement) - والمقترح كان بيفضل
    // قيد التنفيذ لحد ما الأدمن بنفسه يقفله. دلوقتي بنشترك كمان في
    // المقترحات المُسندة إليه (assignedToUid) ونجمع النتيجتين
    // (نفس أسلوب fetchSuggestionsForSearchApi و tickets board).
    const ownItems = new Map();
    const assignedItems = new Map();
    const emitMerged = () => {
      const merged = new Map(ownItems);
      assignedItems.forEach((v, k) => merged.set(k, v));
      emit(merged);
    };

    const unsubOwn = onSnapshot(
      query(suggestionsRef, where("name", "==", myName || "")),
      (querySnapshot) => {
        ownItems.clear();
        querySnapshot.forEach(docSnap => ownItems.set(docSnap.id, { id: docSnap.id, ...docSnap.data() }));
        emitMerged();
      },
      onErr
    );

    let unsubAssigned = null;
    if (myUid) {
      unsubAssigned = onSnapshot(
        query(suggestionsRef, where("assignedToUid", "==", myUid)),
        (querySnapshot) => {
          assignedItems.clear();
          querySnapshot.forEach(docSnap => assignedItems.set(docSnap.id, { id: docSnap.id, ...docSnap.data() }));
          emitMerged();
        },
        onErr
      );
    }

    return () => {
      if (typeof unsubOwn === "function") unsubOwn();
      if (typeof unsubAssigned === "function") unsubAssigned();
    };
  } catch (error) {
    console.error("Error subscribing to suggestions board:", error);
    callback({ status: "error", message: error.message });
    return () => {};
  }
}

// ============================================================
// Workflow - دوال داخلية مساعدة (Helpers)
// ============================================================

// نفس فكرة stampUpdate في ticketsApi.js - تسجيل بيانات آخر تحديث
// (updatedAt/updatedBy) مع كل انتقال حالة
function stampSuggestionUpdate(extra = {}) {
  return {
    ...extra,
    updatedAt: new Date().toISOString(),
    updatedBy: localStorage.getItem("name") || ""
  };
}

// سجل تغييرات مقترح الكايزن (Append-only) - نفس فكرة addTicketLog
// بالضبط، لكن تحت suggestions/{id}/logs بدل tickets/{id}/logs
async function addSuggestionLog(suggestionId, { action, fromStatus, toStatus, note = "" }) {
  try {
    await addDoc(collection(db, "suggestions", suggestionId, "logs"), {
      action,
      fromStatus,
      toStatus,
      note,
      by: localStorage.getItem("name") || "",
      byUid: localStorage.getItem("userId") || "",
      byRole: getCurrentRole() || "",
      at: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error adding suggestion log:", error);
  }
}

// إنشاء إشعار داخل نظام الإشعارات الحالي (مجموعة "notifications" -
// نفس الشكل بالظبط اللي بيستخدمه createNotification في ticketsApi.js:
// forUid/type/message/read/createdAt)، فقط بحقل suggestionId بدل
// ticketId عشان نفرّق مصدر الإشعار - بدون أي نظام إشعارات موازٍ
async function createSuggestionNotification(forUid, { type, message, suggestionId }) {
  if (!forUid) return;
  try {
    await addDoc(collection(db, "notifications"), {
      forUid,
      type,
      message: String(message || "").slice(0, 500),
      ...(suggestionId && { suggestionId }),
      read: false,
      createdByUid: localStorage.getItem("userId") || "",
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error creating suggestion notification:", error);
  }
}

// إصلاح (بند مؤكد بالاختبار العملي - Test 9): كل انتقال حالة تاني في
// هذا الملف (review/reject/request_revision/return_to_review/
// assign_approve/implement) بيبعت إشعاراً للطرف المعني - إلا إعادة
// الإرسال بعد التعديل (resubmit) اللي محدش كان بيتبلّغ بيها إطلاقاً،
// فكان الأدمن محتاج يفتح لوحة الكايزن يدوياً بشكل دوري عشان يكتشف
// إن مقترح "طلب تعديل" رجع فعلاً جاهز لمراجعة تانية - بدون أي تنبيه
// له. نفس فكرة notifyManagersOfNewTicket في ticketsApi.js بالظبط
// (تُرسل لكل أدمن/مدير نشط، ونفس منطق "يتجاهل بأمان لو فشل" عشان أي
// مشكلة هنا ما تأثرش على نجاح إعادة الإرسال نفسها اللي أصلاً خلصت
// قبل ما هذه الدالة تتنادى)
async function notifyAdminsOfSuggestionResubmission(suggestionId, suggestion) {
  try {
    const result = await fetchManagersAndAdminsApi();
    if (result.status !== "success" || !result.data.length) return;

    await Promise.all(
      result.data.map(admin =>
        createSuggestionNotification(admin.id, {
          type: "resubmitted",
          message: `تم تعديل وإعادة إرسال مقترح الكايزن "${suggestion?.title || ""}" للمراجعة`,
          suggestionId
        })
      )
    );
  } catch (error) {
    console.error("Error notifying admins of suggestion resubmission:", error);
  }
}

async function notifyAdminsOfNewSuggestion(suggestionId, suggestion) {
  const result = await fetchManagersAndAdminsApi();
  if (result.status !== "success" || !result.data.length) return;

  const myUid = localStorage.getItem("userId") || "";
  const label = suggestion?.anonymous ? "" : (suggestion?.name ? ` من ${suggestion.name}` : "");
  await Promise.all(
    result.data
      .filter(admin => admin.id && admin.id !== myUid)
      .map(admin =>
        createSuggestionNotification(admin.id, {
          type: "new_suggestion",
          message: `مقترح كايزن جديد "${suggestion?.title || ""}"${label}`,
          suggestionId
        })
      )
  );
}

async function getSuggestionSnapshot(suggestionId) {
  const snap = await getDoc(doc(db, "suggestions", suggestionId));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() };
}

// ============================================================
// Workflow - دوال الانتقال بين الحالات (الإجراءات المسموحة فقط)
// كل دالة هنا مسؤولة عن انتقال واحد محدد فقط - أي انتقال مش موجود
// كدالة هنا يبقى ببساطة "غير مسموح" (نفس فلسفة assignTicketApi/
// startTicketApi/resolveTicketApi/... في ticketsApi.js بدل دالة
// عامة توصل لأي حالة). التحقق من الدور بيتم هنا (رفض سريع) وبيتم
// أيضاً - وبشكل غير قابل للالتفاف - داخل firestore.rules.
// ============================================================

/**
 * new -> under_review: بدء مراجعة مقترح جديد - أدمن فقط
 */
export async function reviewSuggestionApi(suggestionId) {
  if (getCurrentRole() !== "admin") {
    return { status: "error", message: "بدء المراجعة متاح فقط للأدمن" };
  }
  try {
    await updateDoc(
      doc(db, "suggestions", suggestionId),
      stampSuggestionUpdate({ status: "under_review" })
    );
    addSuggestionLog(suggestionId, { action: "review", fromStatus: "new", toStatus: "under_review" });

    const suggestion = await getSuggestionSnapshot(suggestionId);
    if (suggestion?.submittedByUid) {
      createSuggestionNotification(suggestion.submittedByUid, {
        type: "under_review",
        message: `مقترح الكايزن "${suggestion.title || ""}" الآن قيد المراجعة`,
        suggestionId
      });
    }

    return { status: "success" };
  } catch (error) {
    console.error("Error reviewing suggestion:", error);
    return { status: "error", message: error.message };
  }
}

/**
 * new أو under_review -> rejected: رفض مقترح (سبب الرفض إجباري) -
 * أدمن فقط. مسموح صراحةً حتى لو كان المقترح بالفعل "قيد المراجعة"
 * (مش مقصور على "جديد" فقط).
 */
export async function rejectSuggestionApi(suggestionId, reason) {
  if (getCurrentRole() !== "admin") {
    return { status: "error", message: "رفض المقترح متاح فقط للأدمن" };
  }
  if (!reason || !reason.trim()) {
    return { status: "error", message: "سبب الرفض مطلوب" };
  }
  try {
    const suggestion = await getSuggestionSnapshot(suggestionId);
    if (!suggestion) {
      return { status: "error", message: "المقترح غير موجود" };
    }
    if (!["new", "under_review"].includes(suggestion.status || "new")) {
      return { status: "error", message: "لا يمكن رفض مقترح في هذه الحالة" };
    }

    const fromStatus = suggestion.status || "new";

    await updateDoc(
      doc(db, "suggestions", suggestionId),
      stampSuggestionUpdate({ status: "rejected", rejectionReason: reason.trim() })
    );
    addSuggestionLog(suggestionId, {
      action: "reject", fromStatus, toStatus: "rejected", note: reason.trim()
    });

    if (suggestion.submittedByUid) {
      createSuggestionNotification(suggestion.submittedByUid, {
        type: "rejected",
        message: `تم رفض مقترح الكايزن "${suggestion.title || ""}" - السبب: ${reason.trim()}`,
        suggestionId
      });
    }

    return { status: "success" };
  } catch (error) {
    console.error("Error rejecting suggestion:", error);
    return { status: "error", message: error.message };
  }
}

/**
 * under_review -> revision_requested: طلب تعديل على المقترح مع
 * ملاحظات إجبارية توضح المطلوب تعديله - أدمن فقط
 */
export async function requestSuggestionRevisionApi(suggestionId, notes) {
  if (getCurrentRole() !== "admin") {
    return { status: "error", message: "طلب التعديل متاح فقط للأدمن" };
  }
  if (!notes || !notes.trim()) {
    return { status: "error", message: "ملاحظات طلب التعديل مطلوبة" };
  }
  try {
    const suggestion = await getSuggestionSnapshot(suggestionId);
    if (!suggestion || suggestion.status !== "under_review") {
      return { status: "error", message: "طلب التعديل متاح فقط للمقترحات قيد المراجعة" };
    }

    await updateDoc(
      doc(db, "suggestions", suggestionId),
      stampSuggestionUpdate({ status: "revision_requested", revisionNotes: notes.trim() })
    );
    addSuggestionLog(suggestionId, {
      action: "request_revision", fromStatus: "under_review", toStatus: "revision_requested", note: notes.trim()
    });

    if (suggestion.submittedByUid) {
      createSuggestionNotification(suggestion.submittedByUid, {
        type: "revision_requested",
        message: `مطلوب تعديل على مقترح الكايزن "${suggestion.title || ""}" - ملاحظات: ${notes.trim()}`,
        suggestionId
      });
    }

    return { status: "success" };
  } catch (error) {
    console.error("Error requesting suggestion revision:", error);
    return { status: "error", message: error.message };
  }
}

/**
 * revision_requested -> under_review: إعادة المقترح للمراجعة بعد
 * إجراء التعديل المطلوب - أدمن فقط
 */
export async function returnSuggestionToReviewApi(suggestionId) {
  if (getCurrentRole() !== "admin") {
    return { status: "error", message: "هذا الإجراء متاح فقط للأدمن" };
  }
  try {
    const suggestion = await getSuggestionSnapshot(suggestionId);
    if (!suggestion || suggestion.status !== "revision_requested") {
      return { status: "error", message: "الإجراء متاح فقط للمقترحات في حالة طلب تعديل" };
    }

    await updateDoc(
      doc(db, "suggestions", suggestionId),
      stampSuggestionUpdate({ status: "under_review" })
    );
    addSuggestionLog(suggestionId, {
      action: "return_to_review", fromStatus: "revision_requested", toStatus: "under_review"
    });

    if (suggestion.submittedByUid) {
      createSuggestionNotification(suggestion.submittedByUid, {
        type: "under_review",
        message: `مقترح الكايزن "${suggestion.title || ""}" رجع قيد المراجعة بعد التعديل`,
        suggestionId
      });
    }

    return { status: "success" };
  } catch (error) {
    console.error("Error returning suggestion to review:", error);
    return { status: "error", message: error.message };
  }
}

/**
 * revision_requested -> under_review: صاحب المقترح نفسه (submittedByUid)
 * يعدّل المقترح (عنوان/مشكلة/حل) بعد ملاحظات الأدمن، ثم "يعيد
 * إرساله للمراجعة" - ملاحظات الأدمن (revisionNotes) بتفضل محفوظة
 * كسجل تاريخي، وبيتسجل من عدّل ومتى في الـlogs
 */
export async function resubmitSuggestionApi(suggestionId, { title, line, machine, category, problem, solution, impact, images } = {}) {
  const myUid = localStorage.getItem("userId") || "";
  const myName = localStorage.getItem("name") || "";
  try {
    const suggestion = await getSuggestionSnapshot(suggestionId);
    if (!suggestion || suggestion.status !== "revision_requested") {
      return { status: "error", message: "إعادة الإرسال متاحة فقط للمقترحات في حالة يحتاج تعديل" };
    }

    // نفس احتياطي الملكية المُضاف في getSuggestionActions (permissions.js):
    // submittedByUid هو المرجع الأساسي، وبيتم الرجوع للاسم فقط لو
    // الحقل ده فاضي/غير موجود على السجل (مقترحات قديمة سابقة لإضافته)
    const isOwner =
      (!!suggestion.submittedByUid && suggestion.submittedByUid === myUid) ||
      (!suggestion.submittedByUid && !!myName && suggestion.name === myName);

    if (!isOwner) {
      return { status: "error", message: "إعادة الإرسال متاحة فقط لصاحب المقترح نفسه" };
    }
    if (!title?.trim() || !problem?.trim() || !solution?.trim() || !line?.trim() || !machine?.trim() || !category?.trim()) {
      return { status: "error", message: "لازم تعبئة جميع الحقول الأساسية قبل إعادة الإرسال" };
    }

    // Upload new images if provided. If not, we keep the existing imageUrls.
    let finalImageUrls = suggestion.imageUrls || [];
    if (images && images.length > 0) {
      finalImageUrls = await uploadBase64Images(images, "suggestion_resubmit_" + Date.now());
    }

    await updateDoc(
      doc(db, "suggestions", suggestionId),
      stampSuggestionUpdate({
        status: "under_review",
        title: title.trim(),
        line: line.trim(),
        machine: machine.trim(),
        category: category.trim(),
        problem: problem.trim(),
        solution: solution.trim(),
        ...(impact && impact.trim() && { impact: impact.trim() }),
        ...(finalImageUrls.length > 0 && { imageUrls: finalImageUrls }),

        // تصحيح ذاتي لسجل قديم مفيهوش submittedByUid: بنثبّته دلوقتي
        // على معرّف المستخدم الحالي (صاحب المقترح الفعلي حسب الاسم)
        // عشان الإشعارات وأزرار التحكم القادمة (طلب تعديل تاني، رفض،
        // تنفيذ...) تشتغل صح من هنا وطالع، من غير ما تتكرر المشكلة
        ...(!suggestion.submittedByUid && myUid && { submittedByUid: myUid })
      })
    );
    addSuggestionLog(suggestionId, {
      action: "resubmit", fromStatus: "revision_requested", toStatus: "under_review",
      note: "تم التعديل وإعادة الإرسال للمراجعة من صاحب المقترح"
    });

    notifyAdminsOfSuggestionResubmission(suggestionId, { title: title.trim() });

    return { status: "success" };
  } catch (error) {
    console.error("Error resubmitting suggestion:", error);
    return { status: "error", message: error.message };
  }
}

/**
 * under_review -> in_progress: موافقة على المقترح مع إسناده لفني
 * مسؤول (assignedTo/assignedToUid إجباريين) - أدمن فقط
 */
export async function assignAndApproveSuggestionApi(suggestionId, { assignedTo, assignedToUid }) {
  if (getCurrentRole() !== "admin") {
    return { status: "error", message: "الموافقة والإسناد متاحان فقط للأدمن" };
  }
  if (!assignedTo || !assignedToUid) {
    return { status: "error", message: "لازم اختيار الفني المسؤول قبل الموافقة" };
  }
  try {
    const suggestion = await getSuggestionSnapshot(suggestionId);
    if (!suggestion || suggestion.status !== "under_review") {
      return { status: "error", message: "الموافقة والإسناد متاحان فقط للمقترحات قيد المراجعة" };
    }

    await updateDoc(
      doc(db, "suggestions", suggestionId),
      stampSuggestionUpdate({ status: "in_progress", assignedTo, assignedToUid })
    );
    addSuggestionLog(suggestionId, {
      action: "approve_assign",
      fromStatus: "under_review",
      toStatus: "in_progress",
      note: `تم الإسناد إلى ${assignedTo}`
    });

    if (suggestion.submittedByUid) {
      createSuggestionNotification(suggestion.submittedByUid, {
        type: "in_progress",
        message: `تمت الموافقة على مقترح الكايزن "${suggestion.title || ""}" وجارٍ تنفيذه`,
        suggestionId
      });
    }
    createSuggestionNotification(assignedToUid, {
      type: "assigned",
      message: `تم إسناد تنفيذ مقترح كايزن إليك: "${suggestion.title || ""}"`,
      suggestionId
    });

    return { status: "success" };
  } catch (error) {
    console.error("Error assigning/approving suggestion:", error);
    return { status: "error", message: error.message };
  }
}

/**
 * in_progress -> implemented: تسجيل اكتمال تنفيذ المقترح - الفني
 * المسؤول المُسند إليه فقط، أو أدمن (حالة نهائية بعدها). ملاحظة
 * التنفيذ وصورة/صور "بعد التنفيذ" اختياريتان (عند الحاجة فقط)
 */
export async function implementSuggestionApi(suggestionId, notes = "", afterImages = []) {
  const role = getCurrentRole();
  const myUid = localStorage.getItem("userId") || "";

  try {
    const suggestion = await getSuggestionSnapshot(suggestionId);
    if (!suggestion || suggestion.status !== "in_progress") {
      return { status: "error", message: "لا يمكن تسجيل التنفيذ إلا لمقترح قيد التنفيذ" };
    }
    if (role !== "admin" && suggestion.assignedToUid !== myUid) {
      return { status: "error", message: "تسجيل التنفيذ متاح فقط للفني المسؤول عن المقترح أو الأدمن" };
    }

    // الصور اختيارية تماماً ("عند الحاجة") - لو مفيش صور متبعتش، والرفع
    // بيحصل فقط لو فعلاً فيه صور مختارة (بحد أقصى 3، نفس حد resolveTicketApi)
    const images = (afterImages || []).filter(Boolean).slice(0, 3);
    // إصلاح (بند مؤكد بالاختبار العملي - Test 9؛ نفس جذر مشكلة
    // Test 7/8 في imageUpload.js لكن في نقطة استدعاء مختلفة هنا):
    // كانت الدالة بتستخدم Promise.all خام على uploadBase64Image لكل
    // صورة، فبمجرد فشل رفع صورة واحدة (شبكة متقطعة/تعطل ImgBB
    // مؤقت) يرفض الكل - وبما إن صور "ما بعد التنفيذ" هنا اختيارية
    // تماماً أصلاً (زي ما موضّح فوق)، كان فشل صورة اختيارية بيمنع
    // تسجيل اكتمال التنفيذ نفسه وملاحظاته بالكامل، رغم إنها مش
    // مطلوبة أصلاً لإتمام العملية! uploadBase64Images المشتركة
    // (المُصلَحة بالفعل) بترفع كل صورة بمحاولتها المستقلة وتتجاهل
    // أي فشل تلقائياً - فمفيش داعي هنا حتى لفحص "نجحت صورة واحدة
    // على الأقل" زي resolveTicketApi (الصور مش إجبارية من الأصل).
    const implementationImages = images.length
      ? await uploadBase64Images(images, `${suggestionId}_impl`)
      : [];

    await updateDoc(
      doc(db, "suggestions", suggestionId),
      stampSuggestionUpdate({
        status: "implemented",
        ...(notes && notes.trim() && { implementationNotes: notes.trim() }),
        ...(implementationImages.length && { implementationImages })
      })
    );
    addSuggestionLog(suggestionId, {
      action: "implement", fromStatus: "in_progress", toStatus: "implemented", note: notes?.trim() || ""
    });

    if (suggestion.submittedByUid) {
      createSuggestionNotification(suggestion.submittedByUid, {
        type: "implemented",
        message: `🎉 تم تنفيذ مقترح الكايزن "${suggestion.title || ""}" بنجاح`,
        suggestionId
      });
    }

    return { status: "success" };
  } catch (error) {
    console.error("Error implementing suggestion:", error);
    return { status: "error", message: error.message };
  }
}

/**
 * سجل زمني كامل لمقترح كايزن (من نفّذ كل انتقال ومتى) - للعرض في
 * نافذة تفاصيل المقترح فقط (قراءة، بدون أي تعديل)
 */
export async function fetchSuggestionLogsApi(suggestionId) {
  try {
    const logsRef = collection(db, "suggestions", suggestionId, "logs");
    const snap = await getDocs(query(logsRef, orderBy("at", "asc")));
    const items = [];
    snap.forEach(docSnap => items.push({ id: docSnap.id, ...docSnap.data() }));
    return { status: "success", data: items };
  } catch (error) {
    console.error("Error fetching suggestion logs:", error);
    return { status: "error", message: error.message, data: [] };
  }
}

// ============================================================
// ============================================================
// جلب مقترحات آخر N يوم لتقرير قابل للتصدير - مرة واحدة (getDocs)
// بنفس منطق فلترة الصلاحيات أعلاه.
// ============================================================
// تحسين (أداء): فلترة sinceISO بقت where("createdAt", ">=", sinceISO)
// على مستوى الاستعلام نفسه بدل الجلب الكامل ثم الفلترة محلياً.
// ⚠️ ده محتاج Composite Index جديد في Firestore لحالة الوصول المحدود
// (name+createdAt) - راجع firestore.indexes.json المُرفق. لحد ما
// الـ Index يتنشر، أي محاولة هترجع نتيجة فاضية بأمان (بدل ما توقع
// الصفحة) مع تحذير في console يوضح الحاجة للـ Index.
export async function fetchSuggestionsForReportApi({ role, myName, sinceISO }) {
  try {
    const suggestionsRef = collection(db, "suggestions");
    const items = [];
    const dateClause = sinceISO ? [where("createdAt", ">=", sinceISO)] : [];

    if (role === "admin" || role === "manager") {
      const snap = await getDocs(query(suggestionsRef, ...dateClause));
      snap.forEach(docSnap => items.push({ id: docSnap.id, ...docSnap.data() }));
    } else {
      const snap = await getDocs(query(suggestionsRef, where("name", "==", myName || ""), ...dateClause));
      snap.forEach(docSnap => items.push({ id: docSnap.id, ...docSnap.data() }));
    }

    items.sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));

    return { status: "success", data: items };
  } catch (error) {
    if (error?.code === "failed-precondition") {
      console.warn(
        `[fetchSuggestionsForReportApi] محتاج Index في Firestore - ` +
        `تم إخفاء الخطأ مؤقتاً. التفاصيل: ${error.message}`
      );
      return { status: "success", data: [] };
    }
    console.error("Error fetching suggestions for report:", error);
    return { status: "error", message: error.message };
  }
}

// ============================================================
// جلب مقترحات الكايزن لصفحة "البحث والفلترة المتقدمة" (maintenanceSearch)
// - نفس فكرة fetchTicketsForSearchApi (ticketsApi.js): فلترة
//   الصلاحيات على مستوى الاستعلام نفسه بدل جلب كل المقترحات ثم
//   فلترتها محلياً. isFullAccess بيتحدد من الصفحة نفسها
//   (admin/manager/engineer - راجع hasFullDataAccess في permissions.js)
// - وصول محدود: مقترحاته هو (بالاسم - نفس subscribeToSuggestionsBoardApi)
//   + أي مقترح مُسند إليه للتنفيذ (assignedToUid) حتى لو مش هو صاحبه،
//   لأنه برضه "مسموح له بيها" فعلياً (زي ما بيوضح getSuggestionActions)
// ============================================================
export async function fetchSuggestionsForSearchApi({ isFullAccess, myUid, myName }) {
  try {
    const suggestionsRef = collection(db, "suggestions");

    if (isFullAccess) {
      const snap = await getDocs(query(suggestionsRef));
      const items = [];
      snap.forEach(docSnap => items.push({ id: docSnap.id, ...docSnap.data() }));
      return { status: "success", data: items };
    }

    const queries = [
      getDocs(query(suggestionsRef, where("name", "==", myName || "")))
    ];
    if (myUid) {
      queries.push(getDocs(query(suggestionsRef, where("assignedToUid", "==", myUid))));
    }

    const snaps = await Promise.all(queries);
    const merged = new Map();
    snaps.forEach(snap => {
      snap.forEach(docSnap => merged.set(docSnap.id, { id: docSnap.id, ...docSnap.data() }));
    });

    return { status: "success", data: Array.from(merged.values()) };
  } catch (error) {
    console.error("Error fetching suggestions for search:", error);
    return { status: "error", message: error.message };
  }
}


