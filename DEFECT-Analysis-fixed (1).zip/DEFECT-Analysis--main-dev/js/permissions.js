// ============================================================
// permissions.js
// نظام الصلاحيات الموحد
// ============================================================

import { translations, ALL_PERMISSIONS } from './config.js';

// إصلاح (ترجمة شاملة): تسميات أزرار دورة حياة البلاغ/المقترح كانت
// ثابتة بالعربي - دلوقتي بتقرأ من translations.ticketActions /
// translations.suggestionActions حسب window.currentLang وقت كل
// استدعاء (البلاغات/المقترحات بتتعاد رسمها باستمرار Real-time)
function ta() {
  const currentLang = window.currentLang || "ar";
  return (translations[currentLang] || translations.ar).ticketActions;
}

function sa() {
  const currentLang = window.currentLang || "ar";
  return (translations[currentLang] || translations.ar).suggestionActions;
}

let currentRole =
  (localStorage.getItem("role") || "")
    .trim()
    .toLowerCase();

let currentPermissions =
  (localStorage.getItem("permissions") || "")
    .split(",")
    .map(p => p.trim().toLowerCase())
    .filter(Boolean);

// دالة مساعدة لمعرفة هل الدور هو أدمن/مدير نظام
export function isAdminRole(role) {
  const r = String(role || "").trim().toLowerCase();
  return (
    r === "admin" ||
    r === "superadmin" ||
    r === "administrator" ||
    r === "مدير النظام" ||
    r === "مدير نظام" ||
    r === "مدير" ||
    r === "ادمن" ||
    r === "مسؤول"
  );
}

window.isAdminRole = isAdminRole;

// إصلاح (بند A2 في تقرير المراجعة - دور "Supervisor" كان بلا أي
// تأثير فعلي): صفحة "طلبات الانضمام" (RequestsView.js) بتدي الأدمن
// خيار تعيين role="supervisor" يدوياً لأي مستخدم، لكن كل فحوصات
// "هل هو مدير؟" في التطبيق (هنا وفي firestore.rules) كانت بتتحقق من
// "manager" فقط - يعني تعيين "Supervisor" كان عملياً بيدي المستخدم
// صلاحيات فني عادي بدون أي قدرات إدارية، رغم إن الأدمن قاصد يمنحه
// صلاحيات مدير. isManagerRole() هي نقطة التحقق الموحدة الجديدة
// لأي مكان محتاج "مدير أو ما يعادله" - بتشمل "manager" و"supervisor"
// معاً. لازم أي تعديل هنا ينعكس بنفس المعنى في firestore.rules
// (دالة isManagerRole() هناك) عشان الحماية الفعلية تتطابق مع منطق
// الواجهة.
export function isManagerRole(role) {
  const r = String(role || "").trim().toLowerCase();
  return r === "manager" || r === "supervisor";
}

window.isManagerRole = isManagerRole;

// ============================================================
// قراءة/تحديث الحالة
// ============================================================

export function getCurrentRole() {
  let role = (localStorage.getItem("role") || currentRole || "").trim().toLowerCase();
  if (!role) {
    try {
      const cu = JSON.parse(localStorage.getItem("currentUser") || "{}");
      role = (cu.role || "").trim().toLowerCase();
    } catch {
      // ignore
    }
  }
  return role || "user";
}

export function getCurrentPermissions() {
  const role = getCurrentRole();
  if (isAdminRole(role)) {
    return ALL_PERMISSIONS;
  }
  const perms = (localStorage.getItem("permissions") || "")
    .split(",")
    .map(p => p.trim().toLowerCase())
    .filter(Boolean);
  return perms.length > 0 ? perms : currentPermissions;
}

export function setCurrentRole(role) {
  currentRole = String(role || "").trim().toLowerCase();
  localStorage.setItem("role", currentRole);
}

export function setCurrentPermissions(permissions) {
  if (Array.isArray(permissions)) {
    currentPermissions = permissions.map(p => String(p).trim().toLowerCase()).filter(Boolean);
    localStorage.setItem("permissions", currentPermissions.join(","));
  } else if (typeof permissions === "string") {
    currentPermissions = permissions.split(",").map(p => p.trim().toLowerCase()).filter(Boolean);
    localStorage.setItem("permissions", permissions);
  }
}

// ============================================================
// التحقق من الصلاحية
// ============================================================

export function hasPermission(permission) {
  const perm = String(permission || "")
    .trim()
    .toLowerCase();

  if (!perm) return false;

  // استخراج الدور الحالي ديناميكياً للتأكد من أحدث حالة
  const role = getCurrentRole();

  // Admin لديه جميع الصلاحيات دائماً وأبداً وبلا أي قيود
  if (isAdminRole(role)) {
    return true;
  }

  // قراءة الصلاحيات الحالية المحدثة
  const storedPerms = (localStorage.getItem("permissions") || "")
    .split(",")
    .map(p => p.trim().toLowerCase())
    .filter(Boolean);

  // all أو admin = جميع الصلاحيات
  if (
    storedPerms.includes("all") ||
    storedPerms.includes("admin") ||
    currentPermissions.includes("all") ||
    currentPermissions.includes("admin")
  ) {
    return true;
  }

  return storedPerms.includes(perm) || currentPermissions.includes(perm);
}

window.hasPermission = hasPermission;
window.can = hasPermission;

// ============================================================
// نطاق الوصول الكامل للبيانات (Full Data Access)
// تستخدمها أي شاشة محتاجة تفرّق بين "يشوف كل البيانات" و"يشوف
// بياناته المسموح له بيها بس" (زي صفحة البحث والفلترة المتقدمة)
// ============================================================
export function hasFullDataAccess(role = getCurrentRole()) {
  const r = String(role || getCurrentRole()).trim().toLowerCase();
  return (
    hasPermission("all") ||
    isAdminRole(r) ||
    isManagerRole(r) ||
    r === "engineer"
  );
}

window.hasFullDataAccess = hasFullDataAccess;

// ============================================================
// أزرار دورة حياة التذكرة (Ticket Lifecycle Actions)
// ============================================================

export function getTicketActions(ticket) {

  const role = getCurrentRole();
  const isAdmin = isAdminRole(role);
  const myName = localStorage.getItem("name") || "";
  const myUid = localStorage.getItem("userId") || "";
  const status = String(ticket?.status || "").trim().toLowerCase();

  const actions = [];

  // التحقق من قرابة المستخدم بالبلاغ (فني مُسند إليه أم مُبلغ)
  // الهوية بالـ UID (بند M1): المطابقة بالاسم بقت احتياطي فقط للبلاغات
  // القديمة اللي مفيهاش UID - اسمين متطابقين كانوا بيتداخلوا وبتظهر أزرار
  // القاعدة بترفضها (لأنها بتعتمد UID).
  const isAssignee =
    isAdmin ||
    (ticket.assignedToUid
      ? ticket.assignedToUid === myUid
      : (!!myName && ticket.assignedTo === myName));

  // أمان (H5): الأدمن مش "مُبلّغ" تلقائياً - كان بيشوف "إصلاح ذاتي" على أي
  // بلاغ. المُبلّغ = صاحب البلاغ الفعلي فقط (أدمن/مدير بيراجعوا ويأكدوا
  // عبر canReviewAsManager تحت، مش عبر صفة المُبلّغ).
  const isReporter =
    ticket.reportedByUid
      ? ticket.reportedByUid === myUid
      : (!!myName && ticket.reportedBy === myName);

  switch (status) {

    case "pending":
      // تصنيف وإسناد البلاغ للمدير أو الأدمن
      if (isManagerRole(role) || isAdmin) {
        actions.push({ key: "assign", label: ta().assign });
      }
      // إمكانية إصلاح العطل ذاتياً بواسطة صاحب البلاغ
      if (isReporter) {
        actions.push({ key: "self_resolve", label: ta().selfResolve || "🛠️ إصلاح ذاتي" });
      }
      break;

    case "assigned":
      // الفني المُسند إليه يظهر له زر بدء التنفيذ، تم الإصلاح، والاعتذار/إعادة للانتظار
      if (isAssignee) {
        actions.push({ key: "start", label: ta().start });
        actions.push({ key: "resolve", label: ta().resolve });
        actions.push({ key: "decline", label: ta().decline || "↩️ اعتذار / إعادة للانتظار" });
      }
      if (isReporter && !isAssignee) {
        actions.push({ key: "self_resolve", label: ta().selfResolve || "🛠️ إصلاح ذاتي" });
      }
      // إصلاح (Workflow - إعادة إسناد): المعالج handleTicketAction("reassign") موجود
      // في ticketsBoard.js والترجمة ta().reassign موجودة، لكن الزر ماكانش بيتولّد
      // أبداً من هنا، فمفيش طريقة في الموبايل لنقل تذكرة من فني غايب لفني تاني
      if (isManagerRole(role) || isAdmin) {
        actions.push({ key: "reassign", label: ta().reassign || "🔄 إعادة إسناد" });
      }
      break;

    case "in_progress":
    case "reopened":
      // الفني المُسند إليه يقدر ينهي المعالجة أو يعتذر ويعيد البلاغ للانتظار
      if (isAssignee) {
        actions.push({ key: "resolve", label: ta().resolve });
        actions.push({ key: "decline", label: ta().decline || "↩️ اعتذار / إعادة للانتظار" });
      }
      if (isReporter && !isAssignee) {
        actions.push({ key: "self_resolve", label: ta().selfResolve || "🛠️ إصلاح ذاتي" });
      }
      if (isManagerRole(role) || isAdmin) {
        actions.push({ key: "reassign", label: ta().reassign || "🔄 إعادة إسناد" });
      }
      break;

    case "resolved": {
      // المُبلّغ (أو الأدمن) يراجع العمل ويأكد الإغلاق أو يرفض مع السبب.
      // إصلاح (Workflow): (1) المدير/المشرف بقوا يقدروا يراجعوا نيابةً عن المُبلّغ
      // (لو غادر أو انتهى شيفته كانت التذكرة بتعلق للأبد على "بانتظار التأكيد").
      // (2) لو المُبلّغ هو اللي أصلح العطل (isSelfResolved) التأكيد بيبقى من طرف
      // آخر (مدير/مشرف/أدمن) - المُبلّغ يقدر يرفض بس. مطابق لـ firestore.rules STEP 5.
      const canReviewAsManager = isAdmin || isManagerRole(role);
      const selfResolved = ticket.isSelfResolved === true;
      // منع إغلاق بلاغ أصلحه الشخص نفسه (تجاوز التحقق): لو الإصلاح ذاتي
      // (المُبلّغ = المُصلِح) ومن بيراجع هو نفس المُصلِح، التأكيد لازم
      // يكون من طرف تاني (مطابق لـ firestore.rules STEP 5)
      const iResolvedIt = !!ticket.resolvedByUid && ticket.resolvedByUid === myUid;
      if (canReviewAsManager || isReporter) {
        if ((canReviewAsManager || !selfResolved) && !(selfResolved && iResolvedIt)) {
          actions.push({ key: "confirm", label: ta().confirm });
        }
        actions.push({ key: "reject", label: ta().reject });
      }
      break;
    }

    // "closed" حالة نهائية - لا تحتوي على أزرار تغيير حالة
  }

  // زر التفاصيل متاح دائماً لمعاينة السجل والصور
  actions.push({ key: "details", label: ta().details });

  return actions;

}

window.getTicketActions = getTicketActions;

// ============================================================
// أزرار دورة حياة مقترح الكايزن (Kaizen Suggestion Lifecycle Actions)
// ============================================================

export function getSuggestionActions(suggestion) {

  const role = getCurrentRole();
  const myUid = localStorage.getItem("userId") || "";
  const myName = localStorage.getItem("name") || "";
  const status = String(suggestion?.status || "new").trim().toLowerCase();

  const isAdmin = isAdminRole(role);
  const isAssignedTechnician = !!myUid && suggestion?.assignedToUid === myUid;

  const isOwner =
    (!!suggestion?.submittedByUid && suggestion.submittedByUid === myUid) ||
    (!suggestion?.submittedByUid && !!myName && suggestion?.name === myName);

  const actions = [];

  switch (status) {

    case "new":
      // بدء المراجعة أو الرفض المباشر - أدمن فقط
      if (isAdmin) {
        actions.push({ key: "review", label: sa().review });
        actions.push({ key: "reject", label: sa().reject });
      }
      break;

    case "under_review":
      // موافقة وإسناد لفني، أو طلب تعديل، أو رفض - أدمن فقط
      if (isAdmin) {
        actions.push({ key: "approve_assign", label: sa().approveAssign });
        actions.push({ key: "request_revision", label: sa().requestRevision });
        actions.push({ key: "reject", label: sa().reject });
      }
      break;

    case "revision_requested":
      // إعادة المقترح لقيد المراجعة بعد التعديل - أدمن فقط (بدون
      // تعديل محتوى)، أو صاحب المقترح نفسه (بعد تعديل المحتوى فعلياً
      // وإعادة الإرسال - "resubmit")
      if (isAdmin) {
        actions.push({ key: "return_to_review", label: sa().returnToReview });
      }
      if (isOwner) {
        actions.push({ key: "resubmit", label: sa().resubmit });
      }
      break;

    case "in_progress":
      // تسجيل اكتمال التنفيذ - الفني المسؤول المُسند إليه، أو الأدمن
      if (isAdmin || isAssignedTechnician) {
        actions.push({ key: "implement", label: sa().implement });
      }
      break;

    // "rejected" / "implemented" حالتان نهائيتان - لا أزرار تغيير حالة
  }

  // زر التفاصيل متاح دائماً
  actions.push({ key: "details", label: sa().details });

  return actions;

}

window.getSuggestionActions = getSuggestionActions;
