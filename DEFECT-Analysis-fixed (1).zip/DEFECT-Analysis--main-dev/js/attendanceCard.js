// ============================================================
// attendanceCard.js - حاسبة الحضور والمرتبات لمصنع MSCANCO EGYPT
// نظام CMMS - إدارة الصيانة وتحليل العيوب
// ============================================================
// نسخة مطوَّرة (تحل محل كارت "حضور الوردية الذكي" القديم بنفس
// الاسم/التصدير حفاظاً على التوافق مع باقي الملفات):
//
// 1. Pattern حقيقي من ملف Excel (يرفعه الأدمن) بدل الحساب اليدوي
//    لدورة 6+3، مع رجوع تلقائي (Fallback) لنفس حساب الدورة القديم
//    لو مفيش Pattern مرفوع أو الفريق/التاريخ مش موجود فيه.
// 2. صلاحيات الأدمن لإدارة الـ Pattern (رفع/استبدال) ومعاملات
//    الإضافي - محفوظة Global في Firestore (راجع attendanceSettingsApi.js)
// 3. بيانات المرتب (أساسي/تأمينات/سعر ساعة الإضافي) + PIN المرتب:
//    محلية 100% على الجهاز فقط (راجع payrollLocalStore.js) - ولا
//    تُرسل أو تُخزَّن في Firebase/Firestore إطلاقاً.
// 4. إخفاء كل المبالغ المالية افتراضياً خلف قفل PIN (4 أرقام).
// 5. حضور يومي: فريق/وردية/معاد/يوم الدورة/حالة اليوم + دخول/خروج،
//    مع دعم الوردية الليلية العابرة لمنتصف الليل.
// 6. فصل 4 حسابات مستقلة (Regular / Normal OT ×1.5 / OFF Work ×2 /
//    Official Holiday Work × معامل قابل للتعديل من الأدمن) بدون أي
//    تطبيق مزدوج للمعامل على نفس الساعات.
// 7. ملخص مالي كامل بعد فتح PIN.
// 8. تصدير PDF يغطي كل أيام دورة الحضور والمرتبات الحالية (21 → 20،
//    Pattern + حضور فعلي) - نفس الدورة المعروضة في الكارت الحي بالظبط.
// ============================================================

import { db, doc, getDoc } from "./providers/backend/index.js";
import { fetchOfficialHolidaysApi } from "./services/api.js";
import { exportToPdf } from "./services/exportUtility.js";
import { buildPdfStatsCardsHtml } from "./branding.js";
import {
  fetchAttendancePatternApi,
  fetchPayrollRulesApi,
  getCachedAttendancePattern,
  getCachedPayrollRules,
  DEFAULT_PAYROLL_RULES
} from "./services/attendanceSettingsApi.js";
import {
  getPayrollLocalConfig,
  savePayrollLocalConfig,
  setPayrollPin,
  verifyPayrollPin,
  hasPayrollPin,
  removePayrollPin,
  isPayrollUnlocked,
  setPayrollUnlocked
} from "./payrollLocalStore.js";
import {
  getLocalEgyptianHolidays,
  getEgyptianHolidaysUpdatedAt,
  syncEgyptianHolidaysFromGoogle
} from "./services/googleHolidaysSync.js";
import { escapeHtml } from "./utils/escapeHtml.js";

// ============================================================
// 0. الإجازات الرسمية - كاش محلي (Cache) + جلب من Firestore
// (بدون أي تعديل عن النسخة السابقة - نفس السلوك بالظبط)
// ============================================================

const HOLIDAYS_CACHE_KEY = "official_holidays_cache_v1";

let holidaysMemoryCache = null;

export async function getOfficialHolidays() {
  if (Array.isArray(holidaysMemoryCache)) {
    return holidaysMemoryCache;
  }
  try {
    const result = await fetchOfficialHolidaysApi();
    if (result.status === "success") {
      holidaysMemoryCache = result.data;
      try {
        localStorage.setItem(HOLIDAYS_CACHE_KEY, JSON.stringify(result.data));
      } catch (e) { /* تجاهل */ }
      return holidaysMemoryCache;
    }
  } catch (e) {
    console.warn("[Attendance] فشل جلب الإجازات الرسمية من Firestore، سيتم استخدام الكاش المحلي:", e);
  }
  try {
    const raw = localStorage.getItem(HOLIDAYS_CACHE_KEY);
    holidaysMemoryCache = raw ? JSON.parse(raw) : [];
  } catch (e) {
    holidaysMemoryCache = [];
  }
  return holidaysMemoryCache;
}

export function invalidateHolidaysCache() {
  holidaysMemoryCache = null;
}

export function isOfficialHolidayDate(dateStr, holidaysList) {
  const list = Array.isArray(holidaysList) ? holidaysList : (holidaysMemoryCache || []);
  return list.some(h => h.date === dateStr);
}

export function getCachedOfficialHolidays() {
  return holidaysMemoryCache || [];
}

// إضافة: حالة طي/فرد الكارت (نفس السلوك القديم بالظبط)
let attendanceCardExpanded = false;

// ============================================================
// 1. جلب بيانات الفني من البروفايل (Firestore + Cache محلي)
// ملحوظة مهمة: hourlyRate/monthTargetHours اتشالوا من هنا نهائياً
// - دلوقتي بيانات المرتب بتتقرأ حصرياً من payrollLocalStore.js
// (محلي 100%) والساعات المستهدفة من إعدادات الأدمن Global
// (attendanceSettingsApi.js) - مفيش أي بيانات مالية بتتخزن ولا
// تتقرأ من Firestore
// ============================================================

export async function getTechnicianProfile(customUserId = null) {
  const userId = customUserId || localStorage.getItem("userId") || "local_user";

  let profile = {
    userId,
    name: localStorage.getItem("name") || "فني صيانة",
    job: localStorage.getItem("job") || "فني صيانة ميكانيكية/كهربائية",
    shiftColor: localStorage.getItem("shift") || "جرين",
    shiftStartDate: "2026-01-01",
    shiftStart: "08:00",
    shiftEnd: "20:00"
  };

  try {
    const cachedUserStr = localStorage.getItem("currentUser");
    if (cachedUserStr) {
      const cached = JSON.parse(cachedUserStr);
      if (cached) {
        profile = {
          ...profile,
          name: cached.name || profile.name,
          job: cached.job || profile.job,
          shiftColor: cached.shiftColor || cached.shift || profile.shiftColor,
          shiftStartDate: cached.shiftStartDate || profile.shiftStartDate,
          shiftStart: cached.shiftStart || profile.shiftStart,
          shiftEnd: cached.shiftEnd || profile.shiftEnd
        };
      }
    }
  } catch (e) {
    console.warn("[Attendance] Error parsing currentUser cache:", e);
  }

  if (userId && userId !== "local_user" && db) {
    try {
      const userDocRef = doc(db, "users", userId);
      const snap = await getDoc(userDocRef);
      if (snap && snap.exists()) {
        const data = snap.data();
        profile = {
          ...profile,
          name: data.name || profile.name,
          job: data.job || profile.job,
          shiftColor: data.shiftColor || data.shift || profile.shiftColor,
          shiftStartDate: data.shiftStartDate || profile.shiftStartDate,
          shiftStart: data.shiftStart || profile.shiftStart,
          shiftEnd: data.shiftEnd || profile.shiftEnd
        };
      }
    } catch (err) {
      console.warn("[Attendance] Fetching Firestore profile skipped (offline/cached):", err.message);
    }
  }

  return profile;
}

/**
 * تطبيع لون/فريق الوردية لأحد المفاتيح الثلاثة المستخدمة في الـ
 * Pattern: green / blue / red - عشان نقدر نطابق مباشرة مع أعمدة
 * الـ Excel المرفوع بغض النظر عن شكل النص المخزَّن في بروفايل
 * المستخدم (عربي/إنجليزي)
 */
export function normalizeTeamKey(shiftColor) {
  const clean = String(shiftColor || "").trim().toLowerCase();
  if (clean.includes("blue") || clean.includes("بلو") || clean.includes("أزرق") || clean.includes("ازرق")) return "blue";
  if (clean.includes("red") || clean.includes("ريد") || clean.includes("أحمر") || clean.includes("احمر")) return "red";
  return "green";
}

// ============================================================
// 2. دالة حساب الدورة والوردية (Fallback) عند عدم وجود Pattern:
// دورة 6 عمل + 3 إجازة + 6 عمل + 3 إجازة (بدون أي تغيير عن
// السلوك القديم - تُستخدم فقط لو الأدمن لسه ما رفعش Excel، أو
// التاريخ المطلوب مش موجود في الملف المرفوع)
// ============================================================

export function getMyShiftInfo(startDate = "2026-01-01", shiftColor = "جرين", targetDate = new Date(), shiftStart = "08:00", shiftEnd = "20:00") {
  const sDate = new Date(startDate);
  const tDate = typeof targetDate === "string" ? new Date(targetDate) : new Date(targetDate);

  const sUtc = Date.UTC(sDate.getFullYear(), sDate.getMonth(), sDate.getDate());
  const tUtc = Date.UTC(tDate.getFullYear(), tDate.getMonth(), tDate.getDate());

  const diffDays = Math.floor((tUtc - sUtc) / (1000 * 60 * 60 * 24));

  let colorOffset = 0;
  const teamKey = normalizeTeamKey(shiftColor);
  if (teamKey === "blue") colorOffset = 6;
  else if (teamKey === "red") colorOffset = 12;

  const cycleLength = 18;
  const cycleIndex = (((diffDays - colorOffset) % cycleLength) + cycleLength) % cycleLength;

  const dayShiftTime = `${shiftStart} - ${shiftEnd}`;
  const nightShiftTime = `${shiftEnd} - ${shiftStart}`;

  let isWorkDay = true;
  let isNight = false;
  let shiftType = "نهاري";
  let shiftTime = dayShiftTime;
  let dayInCycleText = "";
  let dayPos = 1, dayTotal = 6;

  if (cycleIndex >= 0 && cycleIndex <= 5) {
    dayPos = cycleIndex + 1; dayTotal = 6;
    isWorkDay = true; isNight = false; shiftType = "نهاري"; shiftTime = dayShiftTime;
    dayInCycleText = `يوم ${dayPos} من ${dayTotal}`;
  } else if (cycleIndex >= 6 && cycleIndex <= 8) {
    dayPos = cycleIndex - 5; dayTotal = 3;
    isWorkDay = false; isNight = false; shiftType = "راحة دورية"; shiftTime = "إجازة رسمية";
    dayInCycleText = `راحة (يوم ${dayPos} من ${dayTotal})`;
  } else if (cycleIndex >= 9 && cycleIndex <= 14) {
    dayPos = cycleIndex - 8; dayTotal = 6;
    isWorkDay = true; isNight = true; shiftType = "ليلي"; shiftTime = nightShiftTime;
    dayInCycleText = `يوم ${dayPos} من ${dayTotal}`;
  } else {
    dayPos = cycleIndex - 14; dayTotal = 3;
    isWorkDay = false; isNight = false; shiftType = "راحة دورية"; shiftTime = "إجازة رسمية";
    dayInCycleText = `راحة (يوم ${dayPos} من ${dayTotal})`;
  }

  return { isWorkDay, isNight, shiftType, shiftTime, dayInCycleText, code: isWorkDay ? (isNight ? "N" : "M") : "OFF", source: "cycle" };
}

function getColorBadge(shiftColor) {
  const teamKey = normalizeTeamKey(shiftColor);
  if (teamKey === "blue") {
    return { label: "بلو شفت", bg: "bg-cyan-500/20", border: "border-cyan-500/40", text: "text-cyan-300", dot: "bg-cyan-400" };
  }
  if (teamKey === "red") {
    return { label: "ريد شفت", bg: "bg-rose-500/20", border: "border-rose-500/40", text: "text-rose-300", dot: "bg-rose-400" };
  }
  return { label: "جرين شفت", bg: "bg-emerald-500/20", border: "border-emerald-500/40", text: "text-emerald-300", dot: "bg-emerald-400" };
}

function shiftTypeBadgeClass(isWorkDay, isNight) {
  if (!isWorkDay) return "bg-emerald-500/20 text-emerald-300 border-emerald-500/40";
  return isNight
    ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/40"
    : "bg-amber-500/20 text-amber-300 border-amber-500/40";
}

/**
 * حساب "يوم X من Y" داخل الدورة الحالية بالاعتماد على الـ Pattern
 * الفعلي المرفوع (سكان للخلف وللقدام على أيام من نفس النوع
 * المتتالية) - بدون أي افتراض لطول دورة ثابت (6/3) لأن الملف
 * الحقيقي هو المصدر
 */
function computePatternCyclePosition(patternForTeam, dateStr, isWorkDayToday) {
  const MAX_SCAN = 31;
  const d0 = new Date(`${dateStr}T00:00:00`);

  let pos = 1;
  for (let i = 1; i <= MAX_SCAN; i++) {
    const d = new Date(d0); d.setDate(d.getDate() - i);
    const ds = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const code = patternForTeam ? patternForTeam[ds] : undefined;
    if (code === undefined) break;
    const wasWorkDay = code !== "OFF";
    if (wasWorkDay !== isWorkDayToday) break;
    pos++;
  }

  let total = pos;
  for (let i = 1; i <= MAX_SCAN; i++) {
    const d = new Date(d0); d.setDate(d.getDate() + i);
    const ds = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const code = patternForTeam ? patternForTeam[ds] : undefined;
    if (code === undefined) break;
    const willBeWorkDay = code !== "OFF";
    if (willBeWorkDay !== isWorkDayToday) break;
    total++;
  }

  return { pos, total };
}

/**
 * الدالة الموحَّدة لتحديد معلومات وردية أي تاريخ: بتحاول أولاً من
 * الـ Pattern الفعلي المرفوع من الأدمن (raw Excel data)، ولو مفيش
 * بيانات لهذا الفريق/التاريخ بترجع تلقائياً لحساب الدورة القديم
 * (Fallback) - وده اللي بيضمن إن الكارت يفضل شغال حتى لو الأدمن
 * لسه ما رفعش Pattern لشهر معيّن
 */
export function getShiftInfoForDate(profile, dateStr, patternTeams = null) {
  const teams = patternTeams || getCachedAttendancePattern().teams || {};
  const teamKey = normalizeTeamKey(profile.shiftColor);
  const patternForTeam = teams[teamKey] || null;
  const code = patternForTeam ? patternForTeam[dateStr] : undefined;

  const colorBadge = getColorBadge(profile.shiftColor);

  if (code === "M" || code === "N" || code === "OFF") {
    const isWorkDay = code !== "OFF";
    const isNight = code === "N";
    const shiftTime = !isWorkDay
      ? "راحة (Pattern)"
      : (isNight ? `${profile.shiftEnd} - ${profile.shiftStart}` : `${profile.shiftStart} - ${profile.shiftEnd}`);
    const { pos, total } = computePatternCyclePosition(patternForTeam, dateStr, isWorkDay);
    const dayInCycleText = isWorkDay ? `يوم ${pos} من ${total}` : `راحة (يوم ${pos} من ${total})`;

    return {
      isWorkDay, isNight,
      shiftType: !isWorkDay ? "راحة دورية" : (isNight ? "ليلي" : "نهاري"),
      shiftTime, dayInCycleText, code, source: "pattern",
      colorBadge, badgeColorClass: shiftTypeBadgeClass(isWorkDay, isNight)
    };
  }

  // Fallback: مفيش Pattern لهذا الفريق/التاريخ - استخدم حساب الدورة
  const cycleInfo = getMyShiftInfo(profile.shiftStartDate, profile.shiftColor, dateStr, profile.shiftStart, profile.shiftEnd);
  return {
    ...cycleInfo,
    colorBadge,
    badgeColorClass: shiftTypeBadgeClass(cycleInfo.isWorkDay, cycleInfo.isNight)
  };
}

// ============================================================
// 3. دوال التخزين المحلي لسجلات الحضور اليومية (localStorage)
// (بدون أي تغيير في آلية التخزين نفسها - نفس المفاتيح القديمة
// بالظبط عشان أي سجلات سابقة تفضل شغالة)
// ============================================================

export function getTodayDateString(date = new Date()) {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getStorageKey(userId, dateStr) {
  return `attendance_${userId}_${dateStr}`;
}

export function getDailyAttendanceRecord(userId, dateStr) {
  const key = getStorageKey(userId, dateStr);
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    console.error("[Attendance] Error reading local record:", e);
    return null;
  }
}

export function saveDailyAttendanceRecord(userId, dateStr, data) {
  const key = getStorageKey(userId, dateStr);
  try {
    localStorage.setItem(key, JSON.stringify({
      userId,
      date: dateStr,
      updatedAt: new Date().toISOString(),
      ...data
    }));
  } catch (e) {
    console.error("[Attendance] Error saving local record:", e);
  }
}

/**
 * تحديد "تاريخ السياق" الحالي للكارت: عادةً النهارده، إلا لو فيه
 * وردية ليلية بدأت إمبارح ولسه مفتوحة (فيها دخول بدون خروج) والوقت
 * الحالي قبل الظهر - عشان دعم الوردية الليلية العابرة لمنتصف الليل
 * (تسجيل الخروج والساعات المحسوبة تفضل مرتبطة بيوم الوردية الصح،
 * مش باليوم التقويمي اللي بيحصل فيه الخروج فعلياً)
 */
export function getCardContextDate(userId, now = new Date()) {
  const todayStr = getTodayDateString(now);
  if (now.getHours() < 12) {
    const y = new Date(now);
    y.setDate(y.getDate() - 1);
    const yStr = getTodayDateString(y);
    const yRecord = getDailyAttendanceRecord(userId, yStr);
    if (yRecord && yRecord.checkIn && !yRecord.checkOut) {
      return yStr;
    }
  }
  return todayStr;
}

// ============================================================
// 4. العمليات التفاعلية: checkIn, checkOut, addExtraDay, takeLeave
// ============================================================

// معيار طول الوردية القياسي (12 ساعة) الرسمية
const STANDARD_SHIFT_LENGTH_HOURS = 12;

/**
 * تسجيل اليوم كامل أوتوماتيكياً بالساعات الرسمية بمجرد الضغط،
 * بدون الحاجة لإدخال ساعات يومية يدوياً
 */
export async function registerFullAttendanceDay(targetDate = null) {
  const profile = await getTechnicianProfile();
  const contextDate = targetDate || getCardContextDate(profile.userId);
  const dayInfo = getShiftInfoForDate(profile, contextDate);
  const isHoliday = isOfficialHolidayDate(contextDate, getCachedOfficialHolidays());
  const type = !dayInfo.isWorkDay ? "off" : (isHoliday ? "holiday" : "normal");

  const shiftStart = dayInfo.shiftStart || "08:00";
  const shiftEnd = dayInfo.shiftEnd || "20:00";
  const now = new Date();
  const currentRecord = getDailyAttendanceRecord(profile.userId, contextDate) || {};

  saveDailyAttendanceRecord(profile.userId, contextDate, {
    ...currentRecord,
    checkIn: shiftStart,
    checkOut: shiftEnd,
    checkInTimestamp: now.getTime() - STANDARD_SHIFT_LENGTH_HOURS * 60 * 60 * 1000,
    checkOutTimestamp: now.getTime(),
    normalHours: STANDARD_SHIFT_LENGTH_HOURS,
    overtimeHours: 0,
    earlyDepartureHours: 0,
    hoursWorked: STANDARD_SHIFT_LENGTH_HOURS,
    type,
    status: "attended",
    isExtraDay: type === "off",
    isLeave: false
  });

  refreshAttendanceCard();
}

export async function checkIn() {
  await registerFullAttendanceDay();
}

/**
 * تسجيل الخروج - متوافق مع التدفق السابق
 */
export async function checkOut(manualOvertimeHours = null) {
  const profile = await getTechnicianProfile();
  const contextDate = getCardContextDate(profile.userId);
  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;

  const currentRecord = getDailyAttendanceRecord(profile.userId, contextDate) || {};
  const checkInTimestamp = currentRecord.checkInTimestamp || (now.getTime() - 12 * 60 * 60 * 1000);

  let diffHours = (now.getTime() - checkInTimestamp) / (1000 * 60 * 60);
  if (diffHours < 0.1) diffHours = 12;
  diffHours = Number(diffHours.toFixed(2));

  let normalHours = Math.min(diffHours, STANDARD_SHIFT_LENGTH_HOURS);
  let overtimeHours = 0;

  if (diffHours > STANDARD_SHIFT_LENGTH_HOURS) {
    if (manualOvertimeHours === null || manualOvertimeHours === undefined) {
      return {
        needsManualOvertime: true,
        elapsedHours: diffHours,
        shiftLengthHours: STANDARD_SHIFT_LENGTH_HOURS,
        contextDate
      };
    }
    overtimeHours = Math.max(0, Number(manualOvertimeHours) || 0);
  }

  const dayInfo = getShiftInfoForDate(profile, contextDate);
  const isHoliday = isOfficialHolidayDate(contextDate, getCachedOfficialHolidays());
  const type = !dayInfo.isWorkDay ? "off" : (isHoliday ? "holiday" : "normal");

  normalHours = Number(normalHours.toFixed(2));
  overtimeHours = Number(overtimeHours.toFixed(2));

  saveDailyAttendanceRecord(profile.userId, contextDate, {
    ...currentRecord,
    checkIn: currentRecord.checkIn || "08:00",
    checkInTimestamp,
    checkOut: timeStr,
    checkOutTimestamp: now.getTime(),
    normalHours,
    overtimeHours,
    hoursWorked: Number((normalHours + overtimeHours).toFixed(2)),
    type,
    status: "attended",
    isExtraDay: type === "off",
    isLeave: false
  });

  refreshAttendanceCard();
  return { needsManualOvertime: false };
}

/**
 * مودال تسجيل خروج مبكر (خصم ساعات من الوردية الرسمية)
 */
export async function openEarlyDepartureModal(targetDate = null) {
  closeAnyPayrollModal();
  const profile = await getTechnicianProfile();
  const contextDate = targetDate || getCardContextDate(profile.userId);
  const currentRecord = getDailyAttendanceRecord(profile.userId, contextDate) || {};
  const currentEarly = Number(currentRecord.earlyDepartureHours) || 0;

  return new Promise(resolve => {
    const overlay = document.createElement("div");
    overlay.id = "payrollModalOverlay";
    overlay.dir = "rtl";
    overlay.className = "fixed inset-0 z-[9999] bg-black/70 flex items-center justify-center p-4";
    overlay.innerHTML = `
      <div class="w-full max-w-xs bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-amber-400/40 rounded-2xl p-5 shadow-2xl">
        <div class="text-center mb-3">
          <div class="text-2xl mb-1">🚪</div>
          <div class="text-white font-black text-sm">تسجيل خروج مبكر</div>
          <div class="text-[10px] text-slate-400 mt-1">أدخل عدد ساعات الخروج المبكر لتخصم من ساعات الوردية الرسمية (12س):</div>
        </div>
        <label class="block text-[11px] text-slate-300 mb-1">ساعات الخروج المبكر (خصم بالساعات)</label>
        <input id="earlyHoursInput" type="number" min="0.25" max="12" step="0.25" value="${currentEarly || 1}"
          class="w-full text-center text-xl p-3 rounded-xl bg-slate-950 border border-slate-700 text-white mb-3 focus:border-amber-400 outline-none" />
        <div class="text-center text-[11px] text-slate-300 bg-slate-950/60 p-2 rounded-lg border border-slate-800 mb-3">
          صافي الساعات العادية اليوم: <strong id="earlyNetHours" class="text-amber-300 font-black">11</strong> س
        </div>
        <div class="grid grid-cols-2 gap-2">
          <button id="earlyCancel" class="py-2.5 rounded-xl bg-slate-700/60 text-slate-200 text-xs font-bold">إلغاء</button>
          <button id="earlySave" class="py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-900 text-xs font-black">💾 حفظ الخروج المبكر</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    const input = overlay.querySelector("#earlyHoursInput");
    const netEl = overlay.querySelector("#earlyNetHours");
    const updatePreview = () => {
      const val = Math.min(12, Math.max(0, Number(input.value) || 0));
      netEl.textContent = (12 - val).toFixed(2);
    };
    input.addEventListener("input", updatePreview);
    updatePreview();
    input.focus();

    overlay.querySelector("#earlyCancel").onclick = () => { overlay.remove(); resolve(false); };
    overlay.querySelector("#earlySave").onclick = () => {
      const earlyVal = Math.min(12, Math.max(0, Number(input.value) || 0));
      const normalHours = Math.max(0, Number((12 - earlyVal).toFixed(2)));
      const overtimeHours = Number(currentRecord.overtimeHours) || 0;
      const dayInfo = getShiftInfoForDate(profile, contextDate);
      const isHoliday = isOfficialHolidayDate(contextDate, getCachedOfficialHolidays());
      const type = currentRecord.type || (!dayInfo.isWorkDay ? "off" : (isHoliday ? "holiday" : "normal"));

      saveDailyAttendanceRecord(profile.userId, contextDate, {
        ...currentRecord,
        checkIn: currentRecord.checkIn || dayInfo.shiftStart || "08:00",
        checkOut: currentRecord.checkOut || dayInfo.shiftEnd || "20:00",
        normalHours,
        earlyDepartureHours: earlyVal,
        overtimeHours,
        hoursWorked: Number((normalHours + overtimeHours).toFixed(2)),
        type,
        status: "attended",
        isExtraDay: type === "off",
        isLeave: false
      });

      overlay.remove();
      refreshAttendanceCard();
      resolve(true);
    };
  });
}

/**
 * مودال إدخال ساعات إضافية (Overtime بعد ساعات الوردية الرسمية)
 */
export async function openDailyOvertimeModal(targetDate = null) {
  closeAnyPayrollModal();
  const profile = await getTechnicianProfile();
  const contextDate = targetDate || getCardContextDate(profile.userId);
  const currentRecord = getDailyAttendanceRecord(profile.userId, contextDate) || {};
  const currentOt = Number(currentRecord.overtimeHours) || 0;

  return new Promise(resolve => {
    const overlay = document.createElement("div");
    overlay.id = "payrollModalOverlay";
    overlay.dir = "rtl";
    overlay.className = "fixed inset-0 z-[9999] bg-black/70 flex items-center justify-center p-4";
    overlay.innerHTML = `
      <div class="w-full max-w-xs bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-cyan-400/40 rounded-2xl p-5 shadow-2xl">
        <div class="text-center mb-3">
          <div class="text-2xl mb-1">⏱️</div>
          <div class="text-white font-black text-sm">إضافة ساعات إضافية (Overtime)</div>
          <div class="text-[10px] text-slate-400 mt-1">ساعات عمل بعد نهاية الوردية الرسمية (12س):</div>
        </div>
        <label class="block text-[11px] text-slate-300 mb-1">عدد الساعات الإضافية (س)</label>
        <input id="overtimeHoursInput" type="number" min="0.25" max="24" step="0.25" value="${currentOt || 2}"
          class="w-full text-center text-xl p-3 rounded-xl bg-slate-950 border border-slate-700 text-white mb-3 focus:border-cyan-400 outline-none" />
        <div class="grid grid-cols-2 gap-2">
          <button id="otCancel" class="py-2.5 rounded-xl bg-slate-700/60 text-slate-200 text-xs font-bold">إلغاء</button>
          <button id="otSave" class="py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-600 text-slate-900 text-xs font-black">💾 حفظ الإضافي</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    const input = overlay.querySelector("#overtimeHoursInput");
    input.focus();

    overlay.querySelector("#otCancel").onclick = () => { overlay.remove(); resolve(false); };
    overlay.querySelector("#otSave").onclick = () => {
      const otVal = Math.max(0, Number(input.value) || 0);
      const earlyVal = Number(currentRecord.earlyDepartureHours) || 0;
      const normalHours = currentRecord.normalHours !== undefined ? Number(currentRecord.normalHours) : Math.max(0, 12 - earlyVal);
      const dayInfo = getShiftInfoForDate(profile, contextDate);
      const isHoliday = isOfficialHolidayDate(contextDate, getCachedOfficialHolidays());
      const type = currentRecord.type || (!dayInfo.isWorkDay ? "off" : (isHoliday ? "holiday" : "normal"));

      saveDailyAttendanceRecord(profile.userId, contextDate, {
        ...currentRecord,
        checkIn: currentRecord.checkIn || dayInfo.shiftStart || "08:00",
        checkOut: currentRecord.checkOut || dayInfo.shiftEnd || "20:00",
        normalHours,
        earlyDepartureHours: earlyVal,
        overtimeHours: otVal,
        hoursWorked: Number((normalHours + otVal).toFixed(2)),
        type,
        status: "attended",
        isExtraDay: type === "off",
        isLeave: false
      });

      overlay.remove();
      refreshAttendanceCard();
      resolve(true);
    };
  });
}

/**
 * خيارات حضور اليوم (خروج مبكر / ساعات إضافية / إلغاء)
 */
export async function openAttendanceOptionsModal(targetDate = null) {
  closeAnyPayrollModal();
  const profile = await getTechnicianProfile();
  const contextDate = targetDate || getCardContextDate(profile.userId);
  const currentRecord = getDailyAttendanceRecord(profile.userId, contextDate) || {};

  const overlay = document.createElement("div");
  overlay.id = "payrollModalOverlay";
  overlay.dir = "rtl";
  overlay.className = "fixed inset-0 z-[9999] bg-black/70 flex items-center justify-center p-4";
  overlay.innerHTML = `
    <div class="w-full max-w-xs bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-blue-400/40 rounded-2xl p-5 shadow-2xl space-y-3">
      <div class="text-center">
        <div class="text-2xl mb-1">📋</div>
        <div class="text-white font-black text-sm">خيارات حضور اليوم</div>
        <div class="text-[10px] text-slate-400 mt-0.5">مسجل حالياً: ${currentRecord.hoursWorked || 12} ساعة</div>
      </div>
      <div class="space-y-2">
        <button id="optEarly" class="w-full py-2.5 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-300 text-xs font-bold text-right flex items-center justify-between cursor-pointer">
          <span>🚪 تسجيل خروج مبكر (خصم ساعات)</span>
          <span>←</span>
        </button>
        <button id="optOvertime" class="w-full py-2.5 px-3 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-300 text-xs font-bold text-right flex items-center justify-between cursor-pointer">
          <span>⏱️ إضافة ساعات إضافية (Overtime)</span>
          <span>←</span>
        </button>
        <button id="optReset" class="w-full py-2.5 px-3 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/40 text-rose-300 text-xs font-bold text-right flex items-center justify-between cursor-pointer">
          <span>🗑️ إلغاء تسجيل حضور اليوم</span>
          <span>✕</span>
        </button>
      </div>
      <button id="optClose" class="w-full py-2 rounded-xl bg-slate-700/60 text-slate-300 text-xs font-bold cursor-pointer">إغلاق</button>
    </div>
  `;
  document.body.appendChild(overlay);

  overlay.querySelector("#optClose").onclick = () => overlay.remove();
  overlay.querySelector("#optEarly").onclick = () => {
    overlay.remove();
    openEarlyDepartureModal(contextDate);
  };
  overlay.querySelector("#optOvertime").onclick = () => {
    overlay.remove();
    openDailyOvertimeModal(contextDate);
  };
  overlay.querySelector("#optReset").onclick = () => {
    if (!confirm("هل تريد بالتأكيد إلغاء تسجيل حضور اليوم؟")) return;
    saveDailyAttendanceRecord(profile.userId, contextDate, {
      checkIn: null,
      checkOut: null,
      normalHours: 0,
      overtimeHours: 0,
      earlyDepartureHours: 0,
      hoursWorked: 0,
      status: "idle",
      isExtraDay: false,
      isLeave: false
    });
    overlay.remove();
    refreshAttendanceCard();
  };
}

/**
 * إضافة يوم إضافي (عمل كامل في يوم راحة/OFF مُجدوَل)
 */
export async function addExtraDay(targetDate = null) {
  closeAnyPayrollModal();
  const profile = await getTechnicianProfile();
  const contextDate = targetDate || getCardContextDate(profile.userId);
  const currentRecord = getDailyAttendanceRecord(profile.userId, contextDate) || {};

  return new Promise(resolve => {
    const overlay = document.createElement("div");
    overlay.id = "payrollModalOverlay";
    overlay.dir = "rtl";
    overlay.className = "fixed inset-0 z-[9999] bg-black/70 flex items-center justify-center p-4";
    overlay.innerHTML = `
      <div class="w-full max-w-xs bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-amber-400/40 rounded-2xl p-5 shadow-2xl text-center space-y-3">
        <div class="text-3xl mb-1">⭐</div>
        <div class="text-white font-black text-sm">إضافة يوم إضافي كامل</div>
        <p class="text-xs text-slate-300 leading-relaxed">
          هل تريد تسجيل يوم عمل إضافي كامل (<span class="text-amber-400 font-bold">12 ساعة</span>) لتاريخ <span class="text-cyan-300 font-bold dir-ltr">${contextDate}</span>؟
          <br>
          <span class="text-[10px] text-slate-400 mt-1 block">سيُحتسب ضمن فئة "العمل في يوم OFF" بمعامل ×2.</span>
        </p>
        <div class="grid grid-cols-2 gap-2 pt-2">
          <button id="extraCancel" class="py-2.5 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-slate-200 text-xs font-bold transition cursor-pointer">إلغاء</button>
          <button id="extraConfirm" class="py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black transition shadow-lg cursor-pointer">تأكيد الإضافة</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    overlay.querySelector("#extraCancel").onclick = () => { overlay.remove(); resolve(false); };
    overlay.querySelector("#extraConfirm").onclick = () => {
      saveDailyAttendanceRecord(profile.userId, contextDate, {
        ...currentRecord,
        checkIn: currentRecord.checkIn || "08:00",
        checkOut: currentRecord.checkOut || "20:00",
        normalHours: 12,
        overtimeHours: 0,
        earlyDepartureHours: 0,
        hoursWorked: 12,
        type: "off",
        isExtraDay: true,
        isLeave: false,
        status: "attended"
      });
      overlay.remove();
      refreshAttendanceCard();
      resolve(true);
    };
  });
}

/**
 * تسجيل إجازة من الرصيد (8 ساعات مدفوعة عادي)
 */
export async function takeLeave(targetDate = null) {
  closeAnyPayrollModal();
  const profile = await getTechnicianProfile();
  const contextDate = targetDate || getCardContextDate(profile.userId);
  const currentRecord = getDailyAttendanceRecord(profile.userId, contextDate) || {};

  return new Promise(resolve => {
    const overlay = document.createElement("div");
    overlay.id = "payrollModalOverlay";
    overlay.dir = "rtl";
    overlay.className = "fixed inset-0 z-[9999] bg-black/70 flex items-center justify-center p-4";
    overlay.innerHTML = `
      <div class="w-full max-w-xs bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-emerald-400/40 rounded-2xl p-5 shadow-2xl text-center space-y-3">
        <div class="text-3xl mb-1">🏖️</div>
        <div class="text-white font-black text-sm">تسجيل إجازة من الرصيد</div>
        <p class="text-xs text-slate-300 leading-relaxed">
          هل تريد تسجيل إجازة من الرصيد لتاريخ <span class="text-cyan-300 font-bold dir-ltr">${contextDate}</span>؟
          <br>
          <span class="text-[10px] text-slate-400 mt-1 block">تُحتسب <span class="text-emerald-400 font-bold">8 ساعات</span> مدفوعة الأجر ضمن الساعات العادية.</span>
        </p>
        <div class="grid grid-cols-2 gap-2 pt-2">
          <button id="leaveCancel" class="py-2.5 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-slate-200 text-xs font-bold transition cursor-pointer">إلغاء</button>
          <button id="leaveConfirm" class="py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 text-xs font-black transition shadow-lg cursor-pointer">تأكيد الإجازة</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    overlay.querySelector("#leaveCancel").onclick = () => { overlay.remove(); resolve(false); };
    overlay.querySelector("#leaveConfirm").onclick = () => {
      saveDailyAttendanceRecord(profile.userId, contextDate, {
        ...currentRecord,
        checkIn: "—",
        checkOut: "—",
        normalHours: 8,
        overtimeHours: 0,
        earlyDepartureHours: 0,
        hoursWorked: 8,
        isExtraDay: false,
        isLeave: true,
        status: "leave"
      });
      overlay.remove();
      refreshAttendanceCard();
      resolve(true);
    };
  });
}

/**
 * زر تسجيل الحضور:
 * - تسجيل اليوم كامل أوتوماتيكياً بالساعات الرسمية بمجرد الضغط، بدون الحاجة لإدخال ساعات يومية يدوياً
 * - لو اليوم مسجل بالفعل، الضغط يفتح خيارات الحضور (خروج مبكر / ساعات إضافية)
 */
window.handleAttendanceButton = async function () {
  const profile = await getTechnicianProfile();
  const contextDate = getCardContextDate(profile.userId);
  const record = getDailyAttendanceRecord(profile.userId, contextDate);

  const isAttended = record && (record.status === "attended" || (record.checkIn && record.checkOut) || (Number(record.hoursWorked) > 0));

  if (!isAttended) {
    await registerFullAttendanceDay(contextDate);
    return;
  }

  await openAttendanceOptionsModal(contextDate);
};

window.checkInShift = checkIn;
window.checkOutShift = checkOut;
window.registerFullAttendanceDay = registerFullAttendanceDay;
window.openEarlyDepartureModal = openEarlyDepartureModal;
window.openDailyOvertimeModal = openDailyOvertimeModal;
window.openAttendanceOptionsModal = openAttendanceOptionsModal;

/**
 * مودال "إضافة حضور سابق": تاريخ (بدون السماح بتواريخ مستقبلية) +
 * ساعات عادية + ساعات إضافية + نوع اليوم (عادي/OFF/إجازة رسمية) -
 * بيحفظ بنفس شكل البيانات الجديد ({normalHours, overtimeHours, type})
 * مع البقاء متوافق تمامًا مع السجلات القديمة (مفيش أي حذف/تعديل لها)
 */
window.openPastAttendanceModal = async function () {
  closeAnyPayrollModal();
  const profile = await getTechnicianProfile();
  const todayStr = getTodayDateString();

  const overlay = document.createElement("div");
  overlay.id = "payrollModalOverlay";
  overlay.dir = "rtl";
  overlay.className = "fixed inset-0 z-[9999] bg-black/70 flex items-center justify-center p-4";
  overlay.innerHTML = `
    <div class="w-full max-w-sm bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-cyan-400/40 rounded-2xl p-5 shadow-2xl max-h-[90vh] overflow-y-auto">
      <div class="text-white font-black text-sm mb-3 flex items-center gap-2"><span>🗓️</span><span>إضافة حضور سابق</span></div>

      <label class="block text-[11px] text-slate-300 mb-1">التاريخ</label>
      <input id="pastAttDate" type="date" max="${todayStr}" value="${todayStr}"
        class="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-white text-sm mb-3" />

      <label class="block text-[11px] text-slate-300 mb-1">الساعات العادية</label>
      <input id="pastAttNormal" type="number" min="0" step="0.25" value="12"
        class="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-white text-sm mb-3" />

      <label class="block text-[11px] text-slate-300 mb-1">الساعات الإضافية</label>
      <input id="pastAttOvertime" type="number" min="0" step="0.25" value="0"
        class="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-white text-sm mb-3" />

      <label class="block text-[11px] text-slate-300 mb-1">نوع اليوم</label>
      <select id="pastAttType" class="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-white text-sm mb-4">
        <option value="normal">عادي</option>
        <option value="off">OFF (يوم راحة)</option>
        <option value="holiday">إجازة رسمية</option>
      </select>

      <div id="pastAttError" class="text-[11px] text-rose-400 text-center mb-2 hidden"></div>

      <div class="grid grid-cols-2 gap-2">
        <button id="pastAttCancel" class="py-2.5 rounded-xl bg-slate-700/60 text-slate-200 text-xs font-bold">إلغاء</button>
        <button id="pastAttSave" class="py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-600 text-slate-900 text-xs font-black">💾 حفظ</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  overlay.querySelector("#pastAttCancel").onclick = () => overlay.remove();

  overlay.querySelector("#pastAttSave").onclick = () => {
    const errBox = overlay.querySelector("#pastAttError");
    const dateVal = overlay.querySelector("#pastAttDate").value;
    const normalHours = Math.max(0, Number(overlay.querySelector("#pastAttNormal").value) || 0);
    const overtimeHours = Math.max(0, Number(overlay.querySelector("#pastAttOvertime").value) || 0);
    const type = overlay.querySelector("#pastAttType").value;

    if (!dateVal) {
      errBox.textContent = "⚠️ يرجى اختيار التاريخ";
      errBox.classList.remove("hidden");
      return;
    }
    if (dateVal > todayStr) {
      errBox.textContent = "⚠️ غير مسموح باختيار تاريخ مستقبلي";
      errBox.classList.remove("hidden");
      return;
    }

    const existing = getDailyAttendanceRecord(profile.userId, dateVal) || {};
    saveDailyAttendanceRecord(profile.userId, dateVal, {
      ...existing,
      checkIn: existing.checkIn || "—",
      checkOut: existing.checkOut || "—",
      normalHours,
      overtimeHours,
      hoursWorked: Number((normalHours + overtimeHours).toFixed(2)),
      type,
      isExtraDay: type === "off",
      isLeave: false,
      status: "manual_past_entry"
    });

    overlay.remove();
    refreshAttendanceCard();
  };
};

// ============================================================
// 5. تصنيف يوم واحد (Shared Helper) + حساب إجماليات دورة 21 → 20
// (calculateCycle - يُستخدم في عرض الكارت الحي وفي تصدير تقرير الـ
// PDF، بالصيغة المطلوبة: requiredHours = 192 - (officialHolidayCount
// * 8)) + حساب إجماليات الشهر التقويمي (calculateMonth) كدالة قديمة
// (Legacy) لم تعد مستخدمة في أي تقرير حاليًا - أُبقي عليها فقط
// لتوافقية أي كود خارجي قديم قد ينادي window.calculateAttendanceMonth
// ============================================================

/**
 * تصنيف يوم واحد لأي مستخدم: بيرجع الوردية (Pattern/Fallback)،
 * هل هو إجازة رسمية، سجل الحضور (لو موجود)، عدد الساعات، والفئة
 * (bucket) اللي بيقع فيها اليوم. بيدعم شكلي البيانات: القديم
 * (record.hoursWorked) والجديد (record.normalHours/overtimeHours)
 * بالإضافة لحقل record.type الصريح (من التسجيل التلقائي أو من
 * مودال "إضافة حضور سابق") لو موجود، وإلا بيرجع للاشتقاق التلقائي
 * من الـ Pattern + الإجازات الرسمية (بالظبط زي السلوك القديم)
 */
function classifyDay(userId, dateStr, profile, patternTeams, holidays) {
  const dayInfo = getShiftInfoForDate(profile, dateStr, patternTeams);
  const isHoliday = isOfficialHolidayDate(dateStr, holidays);
  const record = getDailyAttendanceRecord(userId, dateStr);

  const hasNewFields = !!(record && (record.normalHours != null || record.overtimeHours != null));
  const normalHours = record
    ? (hasNewFields ? Number(record.normalHours || 0) : Math.min(Number(record.hoursWorked || 0), 12))
    : 0;
  const overtimeHours = record
    ? (hasNewFields ? Number(record.overtimeHours || 0) : Math.max(0, Number(record.hoursWorked || 0) - 12))
    : 0;
  const hoursWorked = Number((normalHours + overtimeHours).toFixed(2));

  const isLeave = !!(record && record.isLeave);
  const isExtraDay = !!(record && record.isExtraDay);
  const explicitType = record && record.type; // 'normal' | 'off' | 'holiday'

  let bucket = "none";
  if (isLeave) {
    bucket = "leave";
  } else if (isExtraDay) {
    bucket = "off";
  } else if (explicitType === "holiday") {
    bucket = hoursWorked > 0 ? "holiday" : "none";
  } else if (explicitType === "off") {
    bucket = hoursWorked > 0 ? "off" : "none";
  } else if (explicitType === "normal") {
    bucket = hoursWorked > 0 ? "work" : "none";
  } else if (dayInfo.isWorkDay && isHoliday) {
    bucket = hoursWorked > 0 ? "holiday" : "none";
  } else if (!dayInfo.isWorkDay && hoursWorked > 0) {
    bucket = "off";
  } else if (dayInfo.isWorkDay && hoursWorked > 0) {
    bucket = "work";
  }

  return { date: dateStr, dayInfo, isHoliday, record, hoursWorked, normalHours, overtimeHours, bucket };
}

/**
 * حساب مدى دورة الحضور والمرتبات: من يوم 21 في الشهر لحد يوم 20 في
 * الشهر التالي (بالظبط كما هو مطلوب) - باستخدام dayjs (محمّلة عبر
 * CDN في index.html) لضمان دقة حساب نهايات الشهور المختلفة الطول
 * وتغيّر السنة عند دورة ديسمبر/يناير. لو dayjs مش متاحة لأي سبب
 * (فشل تحميل الـ CDN) فيه احتياطي بديل بنفس المنطق بالظبط بـ
 * Date الأصلية في JS، فالنظام يفضل شغال في الحالتين
 */
export function getCycleRange(referenceDate = new Date()) {
  const hasDayjs = typeof window !== "undefined" && typeof window.dayjs === "function";

  if (hasDayjs) {
    const ref = window.dayjs(referenceDate);
    const start = ref.date() >= 21 ? ref.date(21) : ref.subtract(1, "month").date(21);
    const end = start.add(1, "month").date(20);
    return {
      startStr: start.format("YYYY-MM-DD"),
      endStr: end.format("YYYY-MM-DD"),
      label: `${start.format("D MMM")} – ${end.format("D MMM YYYY")}`
    };
  }

  // احتياطي بدون dayjs (نفس منطق الحساب بالظبط)
  const ref = new Date(referenceDate);
  let startY = ref.getFullYear(), startM = ref.getMonth();
  if (ref.getDate() < 21) {
    startM -= 1;
    if (startM < 0) { startM = 11; startY -= 1; }
  }
  const start = new Date(startY, startM, 21);
  let endM = startM + 1, endY = startY;
  if (endM > 11) { endM = 0; endY += 1; }
  const end = new Date(endY, endM, 20);
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  return { startStr: fmt(start), endStr: fmt(end), label: `${fmt(start)} – ${fmt(end)}` };
}

/**
 * حساب إجماليات دورة 21 → 20 الحالية (أو أي دورة تحتوي على
 * referenceDate) - هذا هو المصدر الحي لعرض الكارت (المطلوب/المُنجز
 * وProgress Bar). الصيغة بالظبط كما هو مطلوب:
 * requiredHours = 192 - (officialHolidayCount * 8)
 * حيث officialHolidayCount = أي إجازة رسمية تقع داخل الدورة، بغض
 * النظر عن كونها يوم عمل مُجدوَل للفني أو لأ (خصم غير مشروط)
 */
export function calculateCycle(userId, options = {}) {
  const profile = options.profile || {
    userId, shiftColor: localStorage.getItem("shift") || "جرين",
    shiftStartDate: "2026-01-01", shiftStart: "08:00", shiftEnd: "20:00"
  };
  const patternTeams = options.patternTeams || getCachedAttendancePattern().teams;
  const holidays = options.holidays || getCachedOfficialHolidays();
  const referenceDate = options.referenceDate || new Date();

  const range = getCycleRange(referenceDate);

  let poolHours = 0, dailyNormalOtHours = 0, offWorkHours = 0, holidayWorkHours = 0, holidayCountInCycle = 0;
  let totalWorkDays = 0, totalLeaves = 0, totalExtraDays = 0, totalHolidayWorkDays = 0, totalOffWorkDays = 0;
  const daysList = [];

  let cursor = new Date(`${range.startStr}T00:00:00`);
  const endDate = new Date(`${range.endStr}T00:00:00`);

  while (cursor.getTime() <= endDate.getTime()) {
    const dateStr = getTodayDateString(cursor);
    const info = classifyDay(userId, dateStr, profile, patternTeams, holidays);

    if (info.isHoliday) holidayCountInCycle++;

    if (info.bucket === "leave") {
      poolHours += info.hoursWorked;
      totalLeaves++;
    } else if (info.bucket === "off") {
      offWorkHours += info.hoursWorked;
      totalOffWorkDays++;
      if (info.record?.isExtraDay) totalExtraDays++;
    } else if (info.bucket === "holiday") {
      holidayWorkHours += info.hoursWorked;
      totalHolidayWorkDays++;
    } else if (info.bucket === "work") {
      poolHours += info.normalHours;
      dailyNormalOtHours += info.overtimeHours;
      totalWorkDays++;
    }

    daysList.push(info);
    cursor.setDate(cursor.getDate() + 1);
  }

  const rules = options.rules || getCachedPayrollRules();
  const targetHours = Number(rules?.monthlyTargetHours) || 192;
  const holidayDeduction = Number(rules?.holidayHoursDeduction) || 8;
  const requiredHours = Math.max(0, targetHours - holidayCountInCycle * holidayDeduction);

  const regularHours = Number(Math.min(poolHours, requiredHours).toFixed(2));
  const poolExcessOt = Math.max(0, poolHours - requiredHours);
  const rawNormalOvertimeHours = Number((dailyNormalOtHours + poolExcessOt).toFixed(2));
  const rawOffWorkHours = Number(offWorkHours.toFixed(2));
  const rawHolidayWorkHours = Number(holidayWorkHours.toFixed(2));

  // أرقام/قيم دورة الحضور بعد تطبيق الـmultiplier والمعادلة الخاصة بها
  const normalOvertimeMultiplier = 1.5;
  const offWorkMultiplier = Number(rules?.offWorkMultiplier) || 2.0;
  const holidayWorkMultiplier = Number(rules?.holidayWorkMultiplier) || 1.5;

  const normalOvertimeHours = Number((rawNormalOvertimeHours * normalOvertimeMultiplier).toFixed(2));
  const calculatedOffWorkHours = Number((rawOffWorkHours * offWorkMultiplier).toFixed(2));
  const calculatedHolidayWorkHours = Number((rawHolidayWorkHours * holidayWorkMultiplier).toFixed(2));

  const registeredHours = Number((regularHours + normalOvertimeHours + calculatedOffWorkHours + calculatedHolidayWorkHours).toFixed(2));
  const progressPercent = requiredHours > 0 ? Math.min(100, Math.round((registeredHours / requiredHours) * 100)) : 100;

  return {
    cycleStart: range.startStr,
    cycleEnd: range.endStr,
    cycleLabel: range.label,
    targetHours,
    requiredHours,
    holidayCountInCycle,
    regularHours,
    normalOvertimeHours,
    offWorkHours: calculatedOffWorkHours,
    holidayWorkHours: calculatedHolidayWorkHours,
    rawNormalOvertimeHours,
    rawOffWorkHours,
    rawHolidayWorkHours,
    normalOvertimeMultiplier,
    offWorkMultiplier,
    holidayWorkMultiplier,
    registeredHours,
    progressPercent,
    totalWorkDays,
    totalLeaves,
    totalExtraDays,
    totalOffWorkDays,
    totalHolidayWorkDays,
    daysList,
    isMultiplied: true
  };
}

/**
 * حساب إجماليات الشهر التقويمي (1 → آخر يوم بالشهر) - دالة قديمة
 * (Legacy) لم تعد مستخدمة في تصدير تقرير الـ PDF (بقى بيستخدم
 * calculateCycle بدل منها عشان يطابق دورة 21 → 20 المعروضة في الكارت
 * الحي). أُبقي عليها هنا فقط لعدم كسر أي كود خارجي قديم قد ينادي
 * window.calculateAttendanceMonth مباشرة.
 */
export function calculateMonth(userId, yearMonth = null, options = {}) {
  const profile = options.profile || {
    userId, shiftColor: localStorage.getItem("shift") || "جرين",
    shiftStartDate: "2026-01-01", shiftStart: "08:00", shiftEnd: "20:00"
  };
  const rules = options.rules || getCachedPayrollRules();
  const patternTeams = options.patternTeams || getCachedAttendancePattern().teams;
  const holidays = options.holidays || getCachedOfficialHolidays();

  const currentYM = yearMonth || getTodayDateString().substring(0, 7);
  const [yStr, mStr] = currentYM.split("-");
  const y = Number(yStr), m = Number(mStr);
  const daysInMonth = new Date(y, m, 0).getDate();

  let poolHours = 0;          // ساعات تُقارن بسقف الساعات المطلوبة (حضور عادي + إجازة رصيد)
  let dailyNormalOtHours = 0; // ساعات إضافية في أيام العمل العادية
  let offWorkHours = 0;       // عمل في يوم OFF مُجدوَل (× offWorkMultiplier)
  let holidayWorkHours = 0;   // عمل في يوم عمل مُجدوَل صادف إجازة رسمية (× holidayWorkMultiplier)
  let holidayDeductionDays = 0; // عدد أيام العمل المُجدوَلة المصادفة لإجازة رسمية (لخصم الساعات المطلوبة)
  let totalWorkDays = 0, totalLeaves = 0, totalExtraDays = 0, totalHolidayWorkDays = 0, totalOffWorkDays = 0;

  const daysList = [];

  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    const info = classifyDay(userId, dateStr, profile, patternTeams, holidays);

    if (info.dayInfo.isWorkDay && info.isHoliday) holidayDeductionDays++;

    if (info.bucket === "leave") {
      poolHours += info.hoursWorked;
      totalLeaves++;
    } else if (info.bucket === "off") {
      offWorkHours += info.hoursWorked;
      totalOffWorkDays++;
      if (info.record?.isExtraDay) totalExtraDays++;
    } else if (info.bucket === "holiday") {
      holidayWorkHours += info.hoursWorked;
      totalHolidayWorkDays++;
    } else if (info.bucket === "work") {
      poolHours += info.normalHours;
      dailyNormalOtHours += info.overtimeHours;
      totalWorkDays++;
    }

    daysList.push(info);
  }

  const targetHours = Number(rules.monthlyTargetHours) || DEFAULT_PAYROLL_RULES.monthlyTargetHours;
  const holidayDeductionPerDay = Number(rules.holidayHoursDeduction) || DEFAULT_PAYROLL_RULES.holidayHoursDeduction;
  const requiredHours = Math.max(0, targetHours - holidayDeductionPerDay * holidayDeductionDays);

  const regularHours = Number(Math.min(poolHours, requiredHours).toFixed(2));
  const poolExcessOt = Math.max(0, poolHours - requiredHours);
  const normalOvertimeHours = Number((dailyNormalOtHours + poolExcessOt).toFixed(2));
  offWorkHours = Number(offWorkHours.toFixed(2));
  holidayWorkHours = Number(holidayWorkHours.toFixed(2));

  const totalHours = Number((regularHours + normalOvertimeHours + offWorkHours + holidayWorkHours).toFixed(2));
  const progressPercent = requiredHours > 0 ? Math.min(100, Math.round((totalHours / requiredHours) * 100)) : 100;

  return {
    yearMonth: currentYM,
    daysInMonth,
    targetHours,
    requiredHours,
    holidayDeductionDays,
    regularHours,
    normalOvertimeHours,
    offWorkHours,
    holidayWorkHours,
    totalHours,
    progressPercent,
    totalWorkDays,
    totalLeaves,
    totalExtraDays,
    totalOffWorkDays,
    totalHolidayWorkDays,
    daysList
  };
}

/**
 * حساب المرتب والضرائب والتأمينات حسب معادلة TAX EG المعمول بها من 01-2026
 * 
 * المنطق:
 * 1. الأجر التأميني = الأساسي
 *    - لو مفعل 30% بدلات مستبعدة: الأجر التأميني = الأساسي * 0.7
 *    - الحد الأقصى 2026 = 14500
 *    - التأمينات = الأجر التأميني * 0.11
 *    - لو مفعل بدون تأمينات: التأمينات = 0
 * 
 * 2. حساب الضريبة:
 *    سنوي = (الأساسي * 12) - (التأمينات * 12) - 20000 (إعفاء شخصي)
 *    لو سنوي < 0 = 0
 *    الضريبة السنوية شرائح:
 *    - من 0 لـ 40000 = معفي (0%)
 *    - من 40001 لـ 55000 = 10%
 *    - من 55001 لـ 70000 = 15%
 *    - من 70001 لـ 200000 = 20%
 *    - من 200001 لـ 400000 = 22.5%
 *    - فوق 400000 = 25%
 *    الضريبة الشهرية = السنوية / 12
 * 
 * 3. الصافي = الأساسي - التأمينات - الضريبة
 *    صافي بعد الحضور = (الصافي / 30) * أيام الحضور
 *    مراجعة الإضافي العادي ليضرب في 1.5
 */
export function calculateSalary(param1, param2, param3) {
  let basicSalary = 0;
  let attendanceDays = 30;
  let requiredHours = 0;
  let regularHours = 0;
  let normalOvertimeHours = 0;
  let offWorkHours = 0;
  let holidayWorkHours = 0;
  let rawNormalOvertimeHours = null;
  let rawOffWorkHours = null;
  let rawHolidayWorkHours = null;
  let normalOvertimeMultiplier = 1.5;
  let offWorkMultiplier = 2.0;
  let holidayWorkMultiplier = 1.5;

  // نمط 1: calculateSalary(monthData, localConfig, rules)
  if (param1 && typeof param1 === "object" && (param1.daysList || param1.registeredHours !== undefined || param1.regularHours !== undefined || param1.requiredHours !== undefined || param2?.baseSalary !== undefined || param2?.basicSalary !== undefined)) {
    const monthData = param1 || {};
    const localConfig = param2 || {};
    const rules = param3 || getCachedPayrollRules();

    basicSalary = Number(localConfig.basicSalary ?? localConfig.baseSalary ?? monthData.basicSalary ?? monthData.baseSalary) || 0;

    requiredHours = Number(monthData.requiredHours) || 0;
    regularHours = Number(monthData.regularHours) || 0;

    normalOvertimeHours = Number(monthData.normalOvertimeHours) || 0;
    offWorkHours = Number(monthData.offWorkHours) || 0;
    holidayWorkHours = Number(monthData.holidayWorkHours) || 0;

    if (monthData.rawNormalOvertimeHours !== undefined) rawNormalOvertimeHours = Number(monthData.rawNormalOvertimeHours);
    if (monthData.rawOffWorkHours !== undefined) rawOffWorkHours = Number(monthData.rawOffWorkHours);
    if (monthData.rawHolidayWorkHours !== undefined) rawHolidayWorkHours = Number(monthData.rawHolidayWorkHours);

    normalOvertimeMultiplier = 1.5;
    offWorkMultiplier = Number(rules?.offWorkMultiplier) || 2.0;
    holidayWorkMultiplier = Number(rules?.holidayWorkMultiplier) || 1.5;

    if (typeof localConfig.attendanceDays === "number" && localConfig.attendanceDays > 0) {
      attendanceDays = localConfig.attendanceDays;
    } else if (Array.isArray(monthData.daysList) && monthData.daysList.length > 0) {
      const attendedCount = monthData.daysList.filter(d => (d.hoursWorked > 0) || (d.bucket === "leave")).length;
      attendanceDays = attendedCount > 0 ? attendedCount : 30;
    } else {
      const sumDays = (monthData.totalWorkDays || 0) + (monthData.totalLeaves || 0) + (monthData.totalOffWorkDays || 0) + (monthData.totalHolidayWorkDays || 0);
      attendanceDays = sumDays > 0 ? sumDays : 30;
    }
  }
  // نمط 2: calculateSalary({ basicSalary, attendanceDays, ... })
  else if (param1 && typeof param1 === "object") {
    const opts = param1;
    basicSalary = Number(opts.basicSalary ?? opts.baseSalary) || 0;
    attendanceDays = opts.attendanceDays !== undefined && opts.attendanceDays !== null ? Number(opts.attendanceDays) : 30;
    requiredHours = Number(opts.requiredHours) || 0;
    regularHours = Number(opts.regularHours) || 0;
    normalOvertimeHours = Number(opts.normalOvertimeHours) || 0;
    offWorkHours = Number(opts.offWorkHours) || 0;
    holidayWorkHours = Number(opts.holidayWorkHours) || 0;
    if (opts.rawNormalOvertimeHours !== undefined) rawNormalOvertimeHours = Number(opts.rawNormalOvertimeHours);
    if (opts.rawOffWorkHours !== undefined) rawOffWorkHours = Number(opts.rawOffWorkHours);
    if (opts.rawHolidayWorkHours !== undefined) rawHolidayWorkHours = Number(opts.rawHolidayWorkHours);
    normalOvertimeMultiplier = 1.5;
    offWorkMultiplier = Number(opts.offWorkMultiplier) || 2.0;
    holidayWorkMultiplier = Number(opts.holidayWorkMultiplier) || 1.5;
  }
  // نمط 3: calculateSalary(basicSalary, attendanceDays, options)
  else {
    basicSalary = Number(param1) || 0;
    attendanceDays = param2 !== undefined && param2 !== null ? Number(param2) : 30;
    const opts = param3 || {};
    requiredHours = Number(opts.requiredHours) || 0;
    regularHours = Number(opts.regularHours) || 0;
    normalOvertimeHours = Number(opts.normalOvertimeHours) || 0;
    offWorkHours = Number(opts.offWorkHours) || 0;
    holidayWorkHours = Number(opts.holidayWorkHours) || 0;
    if (opts.rawNormalOvertimeHours !== undefined) rawNormalOvertimeHours = Number(opts.rawNormalOvertimeHours);
    if (opts.rawOffWorkHours !== undefined) rawOffWorkHours = Number(opts.rawOffWorkHours);
    if (opts.rawHolidayWorkHours !== undefined) rawHolidayWorkHours = Number(opts.rawHolidayWorkHours);
    normalOvertimeMultiplier = 1.5;
    offWorkMultiplier = Number(opts.offWorkMultiplier) || 2.0;
    holidayWorkMultiplier = Number(opts.holidayWorkMultiplier) || 1.5;
  }

  // 1. الأجر التأميني = الأساسي (الحد الأقصى 2026 = 14500)
  // إلغاء خيارات بدلات الأجر التأميني وبدون تأمينات
  const MAX_INSURABLE_SALARY_2026 = 14500;
  let insurableSalary = Math.min(Math.max(0, basicSalary), MAX_INSURABLE_SALARY_2026);
  insurableSalary = Number(insurableSalary.toFixed(2));
  const insuranceAmount = Number((insurableSalary * 0.11).toFixed(2));

  // 2. حساب الضريبة:
  //    سنوي = (الأساسي * 12) - (التأمينات * 12) - 20000 (إعفاء شخصي)
  //    لو سنوي < 0 = 0
  const annualGross = basicSalary * 12;
  const annualInsurance = insuranceAmount * 12;
  const personalExemption = 20000;

  let annualTaxable = annualGross - annualInsurance - personalExemption;
  if (annualTaxable < 0) {
    annualTaxable = 0;
  }

  let annualTax = 0;
  if (annualTaxable > 40000) {
    const tier1 = Math.min(annualTaxable - 40000, 15000); // 40001 لـ 55000 (15000 كحد أقصى)
    annualTax += tier1 * 0.10;
  }
  if (annualTaxable > 55000) {
    const tier2 = Math.min(annualTaxable - 55000, 15000); // 55001 لـ 70000 (15000 كحد أقصى)
    annualTax += tier2 * 0.15;
  }
  if (annualTaxable > 70000) {
    const tier3 = Math.min(annualTaxable - 70000, 130000); // 70001 لـ 200000 (130000 كحد أقصى)
    annualTax += tier3 * 0.20;
  }
  if (annualTaxable > 200000) {
    const tier4 = Math.min(annualTaxable - 200000, 200000); // 200001 لـ 400000 (200000 كحد أقصى)
    annualTax += tier4 * 0.225;
  }
  if (annualTaxable > 400000) {
    const tier5 = annualTaxable - 400000; // فوق 400000
    annualTax += tier5 * 0.25;
  }

  annualTax = Number(annualTax.toFixed(2));
  const monthlyTax = Number((annualTax / 12).toFixed(2));

  // 3. الصافي = الأساسي - التأمينات - الضريبة
  const netSalary = Number((basicSalary - insuranceAmount - monthlyTax).toFixed(2));
  let netAfterAttendance = netSalary;
  if (requiredHours > 0) {
    const attendanceRatio = Math.min(1, Math.max(0, regularHours / requiredHours));
    netAfterAttendance = Number((netSalary * attendanceRatio).toFixed(2));
    attendanceDays = attendanceRatio >= 1 ? 30 : Number((attendanceRatio * 30).toFixed(1));
  } else if (attendanceDays !== 30) {
    netAfterAttendance = Number(((netSalary / 30) * attendanceDays).toFixed(2));
  }

  // 4. حساب أجر الساعة (Hourly Rate):
  // يُحسب أوتوماتيكياً: الأساسي ÷ 240 بدون إدخال يدوي
  const hourlyRate = basicSalary > 0 ? Number((basicSalary / 240).toFixed(2)) : 0;

  // مستحقات الإضافي
  const normalOvertimeMoney = rawNormalOvertimeHours !== null
    ? Number((rawNormalOvertimeHours * hourlyRate * normalOvertimeMultiplier).toFixed(2))
    : Number((normalOvertimeHours * hourlyRate).toFixed(2));

  const offWorkMoney = rawOffWorkHours !== null
    ? Number((rawOffWorkHours * hourlyRate * offWorkMultiplier).toFixed(2))
    : Number((offWorkHours * hourlyRate).toFixed(2));

  const holidayWorkMoney = rawHolidayWorkHours !== null
    ? Number((rawHolidayWorkHours * hourlyRate * holidayWorkMultiplier).toFixed(2))
    : Number((holidayWorkHours * hourlyRate).toFixed(2));

  const totalOvertimeMoney = Number((normalOvertimeMoney + offWorkMoney + holidayWorkMoney).toFixed(2));

  // 5. بدل انتقال ثابت = 750 ج.م ويضاف إلى صافي المستحق المتوقع
  const transportAllowance = 750;
  const netExpectedSalary = Number((netAfterAttendance + totalOvertimeMoney + transportAllowance).toFixed(2));

  return {
    basicSalary,
    baseSalary: basicSalary,
    insurableSalary,
    insuranceAmount,
    insurancePercent: insurableSalary > 0 ? 11 : 0,
    annualTaxable: Number(annualTaxable.toFixed(2)),
    annualTax,
    monthlyTax,
    taxAmount: monthlyTax,
    netSalary,
    requiredHours,
    regularHours,
    attendanceDays,
    netAfterAttendance,
    otHourRate: hourlyRate,
    hourlyRate,
    normalOvertimeHours,
    normalOvertimeMultiplier,
    normalOvertimeMoney,
    offWorkHours,
    offWorkMultiplier,
    offWorkMoney,
    holidayWorkHours,
    holidayWorkMultiplier,
    holidayWorkMoney,
    totalOvertimeMoney,
    transportAllowance,
    netExpectedSalary
  };
}

export function computeFinancials(monthData, localConfig, rules = getCachedPayrollRules()) {
  return calculateSalary(monthData, localConfig, rules);
}

// ============================================================
// 6. تصدير PDF لتقرير دورة الحضور والمرتبات (21 → 20) - يغطي كل
// أيام الدورة الحالية (وليس الشهر التقويمي) + الملخص المالي.
// يتطلب فتح PIN أولاً (نفس قاعدة إخفاء البيانات المالية).
//
// ⚠️ مُوحَّد الآن مع نفس آلية exportToPdf() المستخدمة والمُجرَّبة في
// باقي تقارير النظام (الأعطال/التذاكر/الصيانة) بدل الاعتماد على
// html2pdf.bundle بشكل منفصل - وده اللي كان بيسبب ظهور صفحة بيضاء
// (غياب تحديد windowWidth لالتقاط html2canvas بعرض التقرير الحقيقي
// 794px بدل عرض شاشة الجهاز الفعلي، وغياب فترة الانتظار القصيرة قبل
// الالتقاط اللي بتضمن اكتمال تحميل الخط وتشكيل النص العربي).
// كل تقارير PDF في النظام دلوقتي بتمر من نفس المسار الموحّد.
// ============================================================

function codeLabel(code) {
  if (code === "M") return "☀️ صباحي";
  if (code === "N") return "🌙 ليلي";
  if (code === "OFF") return "🏖️ راحة";
  return "—";
}

export async function exportPDF(customUserId = null, customReferenceDate = null, options = {}) {
  const profile = await getTechnicianProfile(customUserId);

  if (!options.skipPinCheck && !isPayrollUnlocked()) {
    const unlocked = await requestPayrollUnlock();
    if (!unlocked) return false;
  }

  const referenceDate = customReferenceDate
    ? new Date(`${customReferenceDate}T00:00:00`)
    : new Date();

  await loadAttendanceSettingsCaches();

  const rules = getCachedPayrollRules();
  // الدالة نفسها المستخدمة فعلاً في عرض الكارت الحي (21 → 20) - التقرير
  // بقى بيطابق تمامًا نفس دورة الحضور والمرتبات المعروضة للفني، بدل
  // الشهر التقويمي القديم.
  const cycleData = calculateCycle(profile.userId, { profile, rules, referenceDate });
  const localConfig = getPayrollLocalConfig(profile.userId);
  const financials = computeFinancials(cycleData, localConfig, rules);

  const title = `📄 تقرير حاسبة الحضور والمرتبات — دورة ${cycleData.cycleLabel}`;
  const filename = `MSCANCO_Payroll_${profile.name.replace(/\s+/g, "_")}_${cycleData.cycleStart}_${cycleData.cycleEnd}.pdf`;

  const infoRows = [
    { label: "اسم الموظف", value: profile.name },
    { label: "الوظيفة", value: profile.job },
    { label: "الفريق", value: getColorBadge(profile.shiftColor).label },
    { label: "دورة الحضور والمرتبات", value: cycleData.cycleLabel },
    { label: "الساعات المستهدفة الأصلية", value: `${cycleData.targetHours} س` },
    { label: "خصم إجازات رسمية", value: `${cycleData.holidayCountInCycle} إجازة × 8س` },
    { label: "الساعات المطلوبة الفعلية", value: `${cycleData.requiredHours} س` }
  ];

  const normalMultiplier = cycleData.normalOvertimeMultiplier || rules?.normalOvertimeMultiplier || 1.5;
  const offMultiplier = cycleData.offWorkMultiplier || rules?.offWorkMultiplier || 2.0;
  const holidayMultiplier = cycleData.holidayWorkMultiplier || rules?.holidayWorkMultiplier || 1.5;

  const statsCardsHtml = buildPdfStatsCardsHtml([
    { label: "عادي", value: `${cycleData.regularHours} س`, color: "#1e3a8a", bg: "#eff6ff" },
    { label: `إضافي عادي ×${normalMultiplier}`, value: `${cycleData.normalOvertimeHours} س`, color: "#b45309", bg: "#fffbeb" },
    { label: `عمل OFF ×${offMultiplier}`, value: `${cycleData.offWorkHours} س`, color: "#9d174d", bg: "#fdf2f8" },
    { label: `عمل إجازة رسمية ×${holidayMultiplier}`, value: `${cycleData.holidayWorkHours} س`, color: "#047857", bg: "#f0fdf4" }
  ]);

  let tableRowsHtml = "";
  cycleData.daysList.forEach((row, idx) => {
    const rowBg = idx % 2 === 0 ? "#ffffff" : "#f8fafc";
    const statusBadge = row.bucket === "holiday"
      ? '<span style="color:#b45309;font-weight:bold;">🎉 عمل بإجازة رسمية</span>'
      : row.bucket === "off"
      ? '<span style="color:#b45309;font-weight:bold;">عمل في يوم OFF</span>'
      : row.bucket === "leave"
      ? '<span style="color:#047857;font-weight:bold;">إجازة رصيد</span>'
      : row.bucket === "work"
      ? '<span style="color:#1e3a8a;font-weight:bold;">حضور عادي</span>'
      : (row.isHoliday ? '<span style="color:#9d174d;">إجازة رسمية (راحة أصلاً)</span>' : '<span style="color:#94a3b8;">—</span>');

    tableRowsHtml += `
      <tr style="background:${rowBg}; border-bottom: 1px solid #e2e8f0; font-size: 10px;">
        <td style="padding: 5px 6px; text-align: center; font-weight: bold;">${idx + 1}</td>
        <td style="padding: 5px 6px; text-align: center; direction: ltr;">${row.date}</td>
        <td style="padding: 5px 6px; text-align: center;">${codeLabel(row.dayInfo.code)}</td>
        <td style="padding: 5px 6px; text-align: center;">${statusBadge}</td>
        <td style="padding: 5px 6px; text-align: center; direction: ltr;">${row.record?.checkIn || "—"}</td>
        <td style="padding: 5px 6px; text-align: center; direction: ltr;">${row.record?.checkOut || "—"}</td>
        <td style="padding: 5px 6px; text-align: center; font-weight: bold;">${row.hoursWorked || 0} س</td>
      </tr>
    `;
  });

  const tableHtml = `
    <table style="width: 100%; border-collapse: collapse; margin-bottom: 16px; border: 1px solid #cbd5e1;">
      <thead>
        <tr style="background: #1e3a8a; color: #ffffff; font-size: 10px;">
          <th style="padding: 6px; border: 1px solid #3b82f6;">م</th>
          <th style="padding: 6px; border: 1px solid #3b82f6;">التاريخ</th>
          <th style="padding: 6px; border: 1px solid #3b82f6;">Pattern</th>
          <th style="padding: 6px; border: 1px solid #3b82f6;">الحالة</th>
          <th style="padding: 6px; border: 1px solid #3b82f6;">دخول</th>
          <th style="padding: 6px; border: 1px solid #3b82f6;">خروج</th>
          <th style="padding: 6px; border: 1px solid #3b82f6;">ساعات اليوم</th>
        </tr>
      </thead>
      <tbody>${tableRowsHtml}</tbody>
    </table>
  `;

  const financialHtml = `
    <div style="background: #0f172a; color: #fff; border-radius: 10px; padding: 14px; margin-bottom: 10px;">
      <div style="font-size: 12px; font-weight: 900; color: #d4af37; margin-bottom: 8px;">💰 ملخص الحساب المالي (معادلة TAX EG 2026)</div>
      <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 6px; font-size: 11px;">
        <div>المرتب الأساسي: <strong>${financials.basicSalary.toLocaleString()} ج.م</strong></div>
        <div>الأجر التأميني: <strong>${financials.insurableSalary.toLocaleString()} ج.م</strong></div>
        <div>التأمينات الاجتماعية: <strong style="color:#f87171;">-${financials.insuranceAmount.toLocaleString()} ج.م</strong></div>
        <div>ضريبة كسب العمل الشهرية: <strong style="color:#f87171;">-${financials.monthlyTax.toLocaleString()} ج.م</strong></div>
        <div>الصافي الشهري (30 يوم): <strong>${financials.netSalary.toLocaleString()} ج.م</strong></div>
        <div>صافي بعد الحضور (${financials.attendanceDays} يوم): <strong>${financials.netAfterAttendance.toLocaleString()} ج.م</strong></div>
        <div>سعر ساعة الإضافي (الأساسي ÷ 240): <strong>${financials.otHourRate.toLocaleString()} ج.م</strong></div>
        <div>بدل انتقال (ثابت): <strong style="color:#34d399;">+${(financials.transportAllowance || 750).toLocaleString()} ج.م</strong></div>
        <div>قيمة الإضافي العادي (×1.5): <strong>${financials.normalOvertimeMoney.toLocaleString()} ج.م</strong></div>
        <div>قيمة عمل OFF (×2): <strong>${financials.offWorkMoney.toLocaleString()} ج.م</strong></div>
        <div>قيمة عمل الإجازة الرسمية: <strong>${financials.holidayWorkMoney.toLocaleString()} ج.م</strong></div>
        <div>إجمالي الإضافي: <strong>${financials.totalOvertimeMoney.toLocaleString()} ج.م</strong></div>
        <div style="font-size: 13px; color:#d4af37; font-weight:900; grid-column: span 2; margin-top: 4px; padding-top: 4px; border-top: 1px solid rgba(212,175,55,0.4);">صافي المستحق المتوقع: ${financials.netExpectedSalary.toLocaleString()} ج.م</div>
      </div>
    </div>
  `;

  const htmlContent = `${statsCardsHtml}${tableHtml}${financialHtml}`;

  await exportToPdf(title, infoRows, htmlContent, filename, {
    first: "توقيع الفني",
    second: "اعتماد مهندس الوردية",
    third: "اعتماد مدير المصنع"
  });
}

function getJsPdfClass() {
  if (typeof window !== "undefined") {
    if (window.jspdf && window.jspdf.jsPDF) return window.jspdf.jsPDF;
    if (typeof window.jsPDF === "function") return window.jsPDF;
  }
  return null;
}

/**
 * إنشاء وتحميل ملف PDF يحتوي على بيانات الحضور والمرتب
 * موحّد تماماً مع محرك exportToPdf المعتمد والمستخدم في زر تصدير التقرير
 * لتفادي مشاكل ترميز اللغة العربية (Mojibake) ومشاكل مفاتيح التخزين القديمة.
 */
export async function exportMonthlySalaryPDF(options = {}) {
  try {
    const now = new Date();
    const currentMonth = String(now.getMonth() + 1);
    const currentYear = String(now.getFullYear());

    // تصدير التقرير الفعلي المعتمد بنفس التنسيق والجداول والتصميم العربي المعتمد
    const res = await exportPDF(null, null, options);
    if (res !== false) {
      localStorage.setItem("last_pdf_export", `${currentMonth}-${currentYear}`);
    }
    return res;
  } catch (err) {
    console.error("[AttendanceCard] خطأ في إنشاء وتحميل PDF المرتب:", err);
    return null;
  }
}

/**
 * فحص ما إذا كان الشهر الحالي مختلفاً عن last_pdf_export
 * وتوليد ملف الـ PDF تلقائياً في حال الاختلاف وعند تسجيل الدخول فقط
 */
export function checkAndAutoExportMonthlyPDF() {
  try {
    if (typeof localStorage === "undefined") return;
    const isLoggedIn = localStorage.getItem("phone") || localStorage.getItem("userId");
    if (!isLoggedIn) return;

    const now = new Date();
    const currentMonth = String(now.getMonth() + 1);
    const currentYear = String(now.getFullYear());
    const lastExport = localStorage.getItem("last_pdf_export");

    if (lastExport !== currentMonth && lastExport !== `${currentMonth}-${currentYear}`) {
      exportMonthlySalaryPDF({ skipPinCheck: true, isAuto: true });
    }
  } catch (e) {
    console.error("[AttendanceCard] فشل فحص التصدير التلقائي لـ PDF:", e);
  }
}

export const generateSalaryPDF = exportMonthlySalaryPDF;

// ============================================================
// 7. تحميل كاش الإعدادات (Pattern + قواعد الإضافي + الإجازات)
// ============================================================

export async function loadAttendanceSettingsCaches() {
  await Promise.all([
    getOfficialHolidays(),
    fetchAttendancePatternApi(),
    fetchPayrollRulesApi()
  ]);
}

// ============================================================
// 8. قفل الـ PIN وإدارة بيانات المرتب (Modal تفاعلي)
// ============================================================

function closeAnyPayrollModal() {
  const existing = document.getElementById("payrollModalOverlay");
  if (existing) existing.remove();
}

/**
 * يطلب من المستخدم فتح القفل (PIN) - لو مفيش PIN متظبط أصلاً بيطلب
 * تعيين واحد جديد أولاً. بيرجع Promise<boolean> (true لو اتفتح)
 */
export function requestPayrollUnlock() {
  return new Promise(resolve => {
    const userId = localStorage.getItem("userId") || "local_user";
    closeAnyPayrollModal();

    const pinIsSet = hasPayrollPin(userId);

    const overlay = document.createElement("div");
    overlay.id = "payrollModalOverlay";
    overlay.dir = "rtl";
    overlay.className = "fixed inset-0 z-[9999] bg-black/70 flex items-center justify-center p-4";
    overlay.innerHTML = `
      <div class="w-full max-w-xs bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-[#D4AF37]/40 rounded-2xl p-5 shadow-2xl">
        <div class="text-center mb-3">
          <div class="text-2xl mb-1">🔒</div>
          <div class="text-white font-black text-sm">${pinIsSet ? "أدخل PIN المرتب" : "تعيين PIN جديد للمرتب"}</div>
          <div class="text-[10px] text-slate-400 mt-1">${pinIsSet ? "4 أرقام لعرض بيانات مرتبك" : "PIN من 4 أرقام لحماية بيانات مرتبك محلياً على جهازك فقط"}</div>
        </div>
        <input id="payrollPinInput" type="password" inputmode="numeric" maxlength="4" placeholder="••••"
          class="w-full text-center tracking-[10px] text-xl p-3 rounded-xl bg-slate-950 border border-slate-700 text-white mb-2" />
        ${!pinIsSet ? `<input id="payrollPinConfirm" type="password" inputmode="numeric" maxlength="4" placeholder="تأكيد PIN" class="w-full text-center tracking-[10px] text-xl p-3 rounded-xl bg-slate-950 border border-slate-700 text-white mb-2" />` : ""}
        <div id="payrollPinError" class="text-[11px] text-rose-400 text-center mb-2 hidden"></div>
        <div class="grid grid-cols-2 gap-2 mt-2">
          <button id="payrollPinCancel" class="py-2.5 rounded-xl bg-slate-700/60 text-slate-200 text-xs font-bold">إلغاء</button>
          <button id="payrollPinSubmit" class="py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-amber-500 text-slate-900 text-xs font-black">${pinIsSet ? "دخول" : "تعيين"}</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    const input = overlay.querySelector("#payrollPinInput");
    input.focus();

    overlay.querySelector("#payrollPinCancel").onclick = () => { overlay.remove(); resolve(false); };

    overlay.querySelector("#payrollPinSubmit").onclick = async () => {
      const errBox = overlay.querySelector("#payrollPinError");
      const val = overlay.querySelector("#payrollPinInput").value.trim();
      if (!/^\d{4}$/.test(val)) {
        errBox.textContent = "يرجى إدخال 4 أرقام بالضبط";
        errBox.classList.remove("hidden");
        return;
      }
      if (pinIsSet) {
        const ok = await verifyPayrollPin(userId, val);
        if (!ok) {
          errBox.textContent = "❌ PIN غير صحيح";
          errBox.classList.remove("hidden");
          return;
        }
        setPayrollUnlocked(true);
        overlay.remove();
        refreshAttendanceCard();
        resolve(true);
      } else {
        const confirmVal = overlay.querySelector("#payrollPinConfirm").value.trim();
        if (val !== confirmVal) {
          errBox.textContent = "❌ الـ PIN وتأكيده غير متطابقين";
          errBox.classList.remove("hidden");
          return;
        }
        await setPayrollPin(userId, val);
        setPayrollUnlocked(true);
        overlay.remove();
        refreshAttendanceCard();
        resolve(true);
      }
    };
  });
}

window.requestPayrollUnlock = requestPayrollUnlock;

/**
 * إخفاء المرتب مرة أخرى (بدون حذف الـ PIN المخزّن - مجرد قفل
 * العرض للجلسة الحالية)
 */
export function hidePayrollAmounts() {
  setPayrollUnlocked(false);
  refreshAttendanceCard();
}
window.hidePayrollAmounts = hidePayrollAmounts;

window.showPayrollAmounts = async function () {
  if (isPayrollUnlocked()) return;
  await requestPayrollUnlock();
};

/**
 * Modal بيانات المرتب (المرتب الأساسي / نسبة التأمينات / سعر ساعة
 * الإضافي) - يتطلب فتح PIN أولاً (لو مش متظبط، بيتظبط هنا)، ثم
 * بيسمح بتعديل الأرقام وحفظها محلياً فقط
 */
window.openPayrollSettingsModal = async function () {
  const userId = localStorage.getItem("userId") || "local_user";

  if (!isPayrollUnlocked()) {
    const unlocked = await requestPayrollUnlock();
    if (!unlocked) return;
  }

  closeAnyPayrollModal();
  const config = getPayrollLocalConfig(userId);
  const currentBasicSalary = config.basicSalary || config.baseSalary || 0;

  const overlay = document.createElement("div");
  overlay.id = "payrollModalOverlay";
  overlay.dir = "rtl";
  overlay.className = "fixed inset-0 z-[9999] bg-black/70 flex items-center justify-center p-4";
  overlay.innerHTML = `
    <div class="w-full max-w-sm bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-[#D4AF37]/40 rounded-2xl p-5 shadow-2xl max-h-[90vh] overflow-y-auto">
      <div class="text-white font-black text-sm mb-3 flex items-center gap-2"><span>⚙️</span><span>بيانات المرتب (معادلة TAX EG 2026)</span></div>
      <p class="text-[10px] text-slate-400 mb-3">أدخل الأساسي فقط ويتم حساب التأمينات والضريبة وأجر الإضافي (الأساسي ÷ 240) وبدل الانتقال تلقائياً - البيانات محفوظة محلياً على جهازك فقط.</p>

      <label class="block text-[11px] text-slate-300 mb-1">المرتب الأساسي (ج.م) - basicSalary</label>
      <input id="cfgBaseSalary" type="number" min="0" step="0.01" value="${currentBasicSalary || ""}" placeholder="أدخل الأساسي فقط..." class="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-700 text-white text-sm mb-3 focus:border-[#D4AF37] outline-none" />

      <div id="cfgLiveSummary" class="bg-slate-950/80 border border-[#D4AF37]/30 rounded-xl p-2.5 mb-3 text-[10px] space-y-1">
        <div class="text-[10px] font-bold text-[#D4AF37] mb-1">📊 الحساب التلقائي (TAX EG 2026):</div>
        <div class="flex justify-between text-slate-400"><span>الأجر التأميني (أقصى 14,500):</span><span id="cfgLiveInsurable" class="font-bold text-white">0 ج.م</span></div>
        <div class="flex justify-between text-slate-400"><span>التأمينات (11%):</span><span id="cfgLiveInsurance" class="font-bold text-rose-300">0 ج.م</span></div>
        <div class="flex justify-between text-slate-400"><span>ضريبة الدخل الشهرية:</span><span id="cfgLiveTax" class="font-bold text-rose-300">0 ج.م</span></div>
        <div class="flex justify-between text-slate-400"><span>سعر ساعة الإضافي (الأساسي ÷ 240):</span><span id="cfgLiveOtRate" class="font-bold text-cyan-300">0 ج.م</span></div>
        <div class="flex justify-between text-slate-400"><span>بدل انتقال (ثابت):</span><span class="font-bold text-emerald-400">750 ج.م</span></div>
        <div class="flex justify-between text-slate-300 border-t border-white/10 pt-1"><span>صافي المرتب الشهري (30 يوم):</span><span id="cfgLiveNet" class="font-black text-[#D4AF37]">0 ج.م</span></div>
      </div>

      <div class="grid grid-cols-2 gap-2 mb-2">
        <button id="payrollCfgCancel" class="py-2.5 rounded-xl bg-slate-700/60 text-slate-200 text-xs font-bold">إلغاء</button>
        <button id="payrollCfgSave" class="py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-amber-500 text-slate-900 text-xs font-black">💾 حفظ</button>
      </div>
      <button id="payrollCfgChangePin" class="w-full py-2 rounded-lg bg-slate-800/60 border border-slate-700 text-slate-300 text-[11px] font-bold mb-1">🔑 تغيير PIN المرتب</button>
      <button id="payrollCfgRemovePin" class="w-full py-2 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-[11px] font-bold">🗑️ إلغاء PIN (بدون حماية)</button>
    </div>
  `;
  document.body.appendChild(overlay);

  const updateLiveSummary = () => {
    const sal = Number(overlay.querySelector("#cfgBaseSalary").value) || 0;
    const calc = calculateSalary(sal, 30);
    overlay.querySelector("#cfgLiveInsurable").textContent = `${calc.insurableSalary.toLocaleString()} ج.م`;
    overlay.querySelector("#cfgLiveInsurance").textContent = calc.insuranceAmount > 0 ? `-${calc.insuranceAmount.toLocaleString()} ج.م` : "0 ج.م";
    overlay.querySelector("#cfgLiveTax").textContent = calc.monthlyTax > 0 ? `-${calc.monthlyTax.toLocaleString()} ج.م` : "0 ج.م";
    overlay.querySelector("#cfgLiveOtRate").textContent = `${calc.otHourRate.toLocaleString()} ج.م`;
    overlay.querySelector("#cfgLiveNet").textContent = `${calc.netSalary.toLocaleString()} ج.م`;
  };

  overlay.querySelector("#cfgBaseSalary").addEventListener("input", updateLiveSummary);
  updateLiveSummary();

  overlay.querySelector("#payrollCfgCancel").onclick = () => overlay.remove();

  overlay.querySelector("#payrollCfgSave").onclick = () => {
    const basicSalary = Number(overlay.querySelector("#cfgBaseSalary").value) || 0;
    savePayrollLocalConfig(userId, {
      basicSalary,
      baseSalary: basicSalary,
      transportAllowance: 750
    });
    overlay.remove();
    refreshAttendanceCard();
  };

  overlay.querySelector("#payrollCfgChangePin").onclick = async () => {
    setPayrollUnlocked(false);
    overlay.remove();
    await requestPayrollUnlock();
    window.openPayrollSettingsModal();
  };

  overlay.querySelector("#payrollCfgRemovePin").onclick = () => {
    if (!confirm("هل تريد إلغاء حماية PIN؟ ستظهر بيانات مرتبك بدون قفل بعد ذلك.")) return;
    removePayrollPin(userId);
    overlay.remove();
    refreshAttendanceCard();
  };
};

// ============================================================
// 9. دالة العرض الرئيسية: renderAttendanceCard
// ============================================================

function maskMoney(value, unlocked) {
  return unlocked ? `${Number(value || 0).toLocaleString()} ج.م` : "🔒 ••••••";
}

export function renderAttendanceCard(customProfile = null) {
  // فحص ما إذا كان هناك حاجة للتصدير التلقائي لـ PDF عند تحميل كارت الحضور
  checkAndAutoExportMonthlyPDF();

  const userId = customProfile?.userId || localStorage.getItem("userId") || "local_user";
  const name = customProfile?.name || localStorage.getItem("name") || "أحمد محمد";
  const job = customProfile?.job || localStorage.getItem("job") || "فني صيانة";
  const shiftColor = customProfile?.shiftColor || localStorage.getItem("shift") || "جرين";
  const shiftStartDate = customProfile?.shiftStartDate || "2026-01-01";
  const shiftStart = customProfile?.shiftStart || "08:00";
  const shiftEnd = customProfile?.shiftEnd || "20:00";

  const profile = { userId, name, job, shiftColor, shiftStartDate, shiftStart, shiftEnd };

  const contextDate = getCardContextDate(userId);
  const dayInfo = getShiftInfoForDate(profile, contextDate);
  const isHolidayToday = isOfficialHolidayDate(contextDate, getCachedOfficialHolidays());

  const todayRecord = getDailyAttendanceRecord(userId, contextDate) || {
    checkIn: null, checkOut: null, hoursWorked: 0, status: "idle"
  };

  const isCheckedIn = !!todayRecord.checkIn && !todayRecord.checkOut;
  const isCheckedOut = !!todayRecord.checkIn && !!todayRecord.checkOut;
  const isExtraDay = !!todayRecord.isExtraDay;
  const isLeave = !!todayRecord.isLeave;

  // الكارت الحي (المطلوب/Progress Bar) وتصدير تقرير الـ PDF بيستخدموا
  // دلوقتي نفس الدالة (calculateCycle) ونفس دورة 21 → 20 - راجع تعليق
  // الدالة أعلاه وتعليق exportPDF بالأسفل.
  const rules = getCachedPayrollRules();
  const cycleData = calculateCycle(userId, { profile, referenceDate: new Date(`${contextDate}T00:00:00`) });

  const localConfig = getPayrollLocalConfig(userId);
  const unlocked = isPayrollUnlocked();
  const financials = computeFinancials(cycleData, localConfig, rules);

  const dateOptions = { weekday: "long", year: "numeric", month: "short", day: "numeric" };
  const formattedToday = new Date(`${contextDate}T00:00:00`).toLocaleDateString((window.currentLang === "en" ? "en-US" : "ar-EG"), dateOptions);

  // هل اليوم إجازة رسمية حسب Google Calendar تحديدًا (القائمة
  // المتزامَنة محليًا) - لتلوين كارت اليوم بالأزرق الفاتح
  const isGoogleHolidayToday = getLocalEgyptianHolidays().some(h => h.date === contextDate);
  const todayRowClasses = isGoogleHolidayToday
    ? "bg-sky-400/10 p-2 rounded-lg border border-sky-300/40"
    : "bg-slate-950/40 p-2 rounded-lg border border-white/10";

  let actionButtonHtml = "";
  if (isExtraDay) {
    actionButtonHtml = `
      <button type="button" onclick="window.openAttendanceOptionsModal()" title="خيارات اليوم (تعديل / إلغاء)"
        class="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/50 text-amber-300 font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer transition active:scale-95">
        <span>⭐</span><span>إضافي مسجل</span><span class="text-[9px] text-amber-400/80">⚙️</span>
      </button>`;
  } else if (isLeave) {
    actionButtonHtml = `
      <button type="button" onclick="window.openAttendanceOptionsModal()" title="خيارات اليوم (تعديل / إلغاء)"
        class="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/50 text-emerald-300 font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer transition active:scale-95">
        <span>🏖️</span><span>إجازة رصيد</span><span class="text-[9px] text-emerald-400/80">⚙️</span>
      </button>`;
  } else if (isCheckedIn) {
    // زر واحد واضح "تسجيل حضور" - نفس المُعالِج (handleAttendanceButton)
    // بيحدد تلقائيًا إنها ضغطة تسجيل خروج طالما فيه دخول بدون خروج
    actionButtonHtml = `
      <button type="button" id="btnAttendanceAction" onclick="window.handleAttendanceButton()"
        class="group relative px-3 py-1 rounded-lg font-black text-[11px] text-white bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 border border-red-400/50 shadow-sm active:scale-95 transition-all flex items-center justify-center gap-1 cursor-pointer">
        <span class="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span><span>تسجيل حضور</span><span class="rtl:rotate-180 text-xs">🚪</span>
      </button>`;
  } else if (isCheckedOut) {
    actionButtonHtml = `
      <div class="flex items-center gap-1">
        <button type="button" id="btnAttendanceAction" onclick="window.handleAttendanceButton()"
          title="خيارات الوردية (خروج مبكر / ساعات إضافية / إلغاء)"
          class="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/50 text-emerald-300 font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer transition active:scale-95">
          <span>✅</span><span>تمت الوردية</span><span class="text-[9px] text-emerald-400/80">⚙️</span>
        </button>
      </div>`;
  } else {
    actionButtonHtml = `
      <button type="button" id="btnAttendanceAction" onclick="window.handleAttendanceButton()"
        class="group relative px-3 py-1 rounded-lg font-black text-[11px] text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 border border-emerald-400/50 shadow-sm active:scale-95 transition-all flex items-center justify-center gap-1 cursor-pointer">
        <span class="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse"></span><span>تسجيل حضور</span><span class="rtl:rotate-180 text-xs">📲</span>
      </button>`;
  }

  const dayStatusText = !dayInfo.isWorkDay
    ? (isHolidayToday ? "🏖️ راحة مُجدوَلة (تصادف إجازة رسمية)" : "🏖️ يوم راحة")
    : (isHolidayToday ? "🎉 يوم عمل يصادف إجازة رسمية" : "✅ يوم عمل");

  return `
  <!-- حاسبة الحضور والمرتبات - MSCANCO EGYPT -->
  <div id="attendanceShiftCard" class="w-full bg-gradient-to-br from-[#1E3A8A] via-[#172554] to-[#0F172A] border border-[#D4AF37]/60 shadow-md shadow-blue-950/30 rounded-xl p-2.5 sm:p-3 text-white relative overflow-hidden transition-all duration-300">

    <div class="absolute -left-10 -bottom-10 w-28 h-28 bg-[#D4AF37]/10 rounded-full blur-xl pointer-events-none"></div>
    <div class="absolute -right-10 -top-10 w-28 h-28 bg-blue-500/10 rounded-full blur-xl pointer-events-none"></div>

    <div class="relative z-10 space-y-2">

      <div id="attendanceRow1" class="flex items-center justify-between gap-1.5 pb-1.5 border-b border-white/10">
        <div class="flex items-center gap-2 min-w-0">
          <div class="w-7 h-7 rounded-lg bg-gradient-to-br from-[#D4AF37]/30 to-amber-500/10 border border-[#D4AF37]/50 flex items-center justify-center text-[#D4AF37] font-black text-xs shrink-0 shadow-inner">🧮</div>
          <div class="min-w-0">
            <div class="flex items-center gap-1">
              <span class="font-black text-xs text-white truncate max-w-[120px] sm:max-w-[180px]">حاسبة الحضور</span>
              <span class="text-[8.5px] text-[#D4AF37] font-bold px-1 py-0.2 bg-[#D4AF37]/15 rounded border border-[#D4AF37]/30">MSCANCO</span>
            </div>
            <div class="text-[9.5px] text-slate-300 font-medium truncate max-w-[130px] sm:max-w-[200px]">${escapeHtml(name)} · ${escapeHtml(job)}</div>
          </div>
        </div>

        <div class="flex items-center gap-1 shrink-0">
          <span class="px-1.5 py-0.5 rounded-md text-[9px] font-bold flex items-center gap-1 border ${dayInfo.colorBadge.bg} ${dayInfo.colorBadge.border} ${escapeHtml(dayInfo.colorBadge.text)}">
            <span class="w-1 h-1 rounded-full ${dayInfo.colorBadge.dot}"></span><span>${escapeHtml(dayInfo.colorBadge.label)}</span>
          </span>
          <span class="px-1.5 py-0.5 rounded-md text-[9px] font-bold border ${dayInfo.badgeColorClass}">
            ${dayInfo.shiftType === "ليلي" ? "🌙 ليلي" : (dayInfo.shiftType === "نهاري" ? "☀️ نهاري" : "🏖️ راحة")}
          </span>
          <button type="button" id="attendanceToggleBtn" onclick="window.toggleAttendanceCard()" aria-expanded="${attendanceCardExpanded ? "true" : "false"}" aria-controls="attendanceExpandableContent"
            title="${attendanceCardExpanded ? "طي التفاصيل" : "عرض كل التفاصيل"}"
            class="w-6 h-6 rounded-md bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center transition-colors cursor-pointer shrink-0">
            <svg id="attendanceToggleChevron" xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5 text-white transition-transform duration-300 ${attendanceCardExpanded ? "rotate-180" : ""}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
            </svg>
          </button>
        </div>
      </div>

      <div id="attendanceRow3" class="flex items-center justify-between gap-2 ${todayRowClasses}">
        <div class="flex items-center gap-2.5 text-xs">
          <div><span class="text-[9px] text-slate-400 block font-medium leading-tight">الدخول:</span><span class="font-black text-emerald-400 text-xs dir-ltr">${todayRecord.checkIn || "--:--"}</span></div>
          <div class="h-4 w-px bg-white/10"></div>
          <div><span class="text-[9px] text-slate-400 block font-medium leading-tight">الخروج:</span><span class="font-black text-amber-400 text-xs dir-ltr">${todayRecord.checkOut || "--:--"}</span></div>
        </div>
        <div>${actionButtonHtml}</div>
      </div>

      <div id="attendanceExpandableContent" class="overflow-hidden transition-all duration-300 ease-in-out space-y-2"
        style="max-height: ${attendanceCardExpanded ? "2400px" : "0px"}; opacity: ${attendanceCardExpanded ? "1" : "0"};"
        aria-hidden="${attendanceCardExpanded ? "false" : "true"}">

      <div id="attendanceRow2" class="grid grid-cols-3 gap-1.5 bg-slate-900/60 p-2 rounded-lg border border-white/5 text-center items-center">
        <div><div class="text-[8.5px] text-slate-400 font-medium">الدورة الحالية</div><div class="text-[11px] font-black text-[#D4AF37] mt-0.5">${escapeHtml(dayInfo.dayInCycleText)}</div></div>
        <div class="border-x border-white/10 px-0.5"><div class="text-[8.5px] text-slate-400 font-medium">تاريخ اليوم</div><div class="text-[10px] font-bold text-white mt-0.5 truncate" title="${formattedToday}">${formattedToday}</div></div>
        <div><div class="text-[8.5px] text-slate-400 font-medium">ميعاد الوردية</div><div class="text-[10px] font-black text-cyan-300 mt-0.5 dir-ltr">${dayInfo.shiftTime}</div></div>
      </div>

      <div id="attendanceDayStatus" class="flex items-center gap-1.5 bg-slate-900/60 border border-white/10 rounded-lg px-2.5 py-1.5 text-[10px] text-slate-200 font-bold">
        <span>${escapeHtml(dayStatusText)}</span>
        ${dayInfo.source === "cycle" ? '<span class="text-[8.5px] text-slate-500 font-normal">(محسوبة تلقائياً)</span>' : ""}
      </div>

      ${isHolidayToday ? `
        <div id="attendanceHolidayBadge" class="flex items-center gap-1.5 bg-amber-500/10 border border-amber-400/30 rounded-lg px-2.5 py-1.5 text-[10px] text-amber-200 font-bold">
          <span>🎉</span>
          <span>${!dayInfo.isWorkDay ? "اليوم إجازة رسمية (راحة دورية)" : "اليوم إجازة رسمية ويوم عمل مُجدوَل"}</span>
        </div>` : ""}

      <div id="attendanceRow4" class="flex items-center justify-between bg-blue-950/50 px-2.5 py-1.5 rounded-lg border border-blue-400/20 text-[11px]">
        <div class="flex items-center gap-1.5"><span class="text-blue-300 font-bold">📊 ساعات اليوم:</span><span class="text-white font-black">${todayRecord.hoursWorked || 0} س</span></div>
        <div class="flex items-center gap-1">
          <button type="button" onclick="window.openEarlyDepartureModal()" title="تسجيل خروج مبكر وخصم ساعات" class="px-2 py-0.5 rounded-md bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-300 font-bold text-[10px] active:scale-95 transition cursor-pointer">
            🚪 خروج مبكر
          </button>
          <button type="button" onclick="window.openDailyOvertimeModal()" title="إضافة ساعات عمل إضافية بعد ساعات الوردية" class="px-2 py-0.5 rounded-md bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-300 font-bold text-[10px] active:scale-95 transition cursor-pointer">
            ⏱️ + إضافي
          </button>
        </div>
      </div>

      <div id="attendanceRow5" class="space-y-1 bg-slate-900/80 p-2 rounded-lg border border-white/10">
        <div class="text-[8.5px] text-slate-500 font-medium text-center">دورة الحضور: ${cycleData.cycleStart} → ${cycleData.cycleEnd}</div>
        <div class="grid grid-cols-2 gap-1 text-[10px] font-bold text-slate-200">
          <div class="bg-slate-950/50 rounded-md p-1 text-center"><div class="text-slate-400 text-[8.5px]">عادي</div><div class="text-emerald-400 text-xs font-black">${cycleData.regularHours}س</div></div>
          <div class="bg-slate-950/50 rounded-md p-1 text-center"><div class="text-slate-400 text-[8.5px]">إضافي عادي</div><div class="text-amber-400 text-xs font-black">${cycleData.normalOvertimeHours}س</div></div>
          <div class="bg-slate-950/50 rounded-md p-1 text-center"><div class="text-slate-400 text-[8.5px]">عمل OFF</div><div class="text-rose-400 text-xs font-black">${cycleData.offWorkHours}س</div></div>
          <div class="bg-slate-950/50 rounded-md p-1 text-center"><div class="text-slate-400 text-[8.5px]">عمل إجازة رسمية</div><div class="text-cyan-300 text-xs font-black">${cycleData.holidayWorkHours}س</div></div>
        </div>

        <div class="grid grid-cols-2 gap-1 pt-0.5">
          <div>
            <label class="text-[8.5px] text-slate-400 font-medium block mb-0.5">الساعات المطلوبة</label>
            <input type="text" readonly value="${cycleData.requiredHours} س"
              class="w-full text-center text-[10px] font-black text-white bg-slate-950/70 border border-white/10 rounded-md py-1 cursor-not-allowed" />
          </div>
          <div>
            <label class="text-[8.5px] text-slate-400 font-medium block mb-0.5">الساعات المسجّلة</label>
            <input type="text" readonly value="${cycleData.registeredHours} س"
              class="w-full text-center text-[10px] font-black text-cyan-300 bg-slate-950/70 border border-white/10 rounded-md py-1 cursor-not-allowed" />
          </div>
        </div>

        <div class="space-y-0.5 pt-0.5">
          <div class="flex justify-between text-[9px] text-slate-400 font-medium">
            <span>المطلوب: ${cycleData.requiredHours} س</span>
            <span class="text-cyan-300 font-bold">${cycleData.progressPercent}%</span>
          </div>
          <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden border border-white/5">
            <div class="h-full bg-gradient-to-r from-blue-500 via-cyan-400 to-[#D4AF37] rounded-full transition-all duration-500" style="width: ${cycleData.progressPercent}%"></div>
          </div>
        </div>
      </div>

      <!-- الملخص المالي - مخفي دايماً خلف PIN -->
      <div id="attendancePayrollBox" class="space-y-1 bg-gradient-to-br from-slate-900 to-slate-950 p-2 rounded-lg border border-[#D4AF37]/30">
        <div class="flex items-center justify-between">
          <span class="text-[10px] font-black text-[#D4AF37] flex items-center gap-1"><span>💰</span><span>الملخص المالي</span></span>
          <div class="flex items-center gap-1">
            <button type="button" onclick="window.openPayrollSettingsModal()" class="text-[9px] px-1.5 py-0.5 rounded-md bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300">⚙️ بيانات</button>
            ${unlocked
              ? `<button type="button" onclick="window.hidePayrollAmounts()" class="text-[9px] px-1.5 py-0.5 rounded-md bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300">🙈 إخفاء</button>`
              : `<button type="button" onclick="window.showPayrollAmounts()" class="text-[9px] px-1.5 py-0.5 rounded-md bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 border border-[#D4AF37]/40 text-[#D4AF37] font-bold">🔓 إظهار</button>`}
          </div>
        </div>
        <div class="grid grid-cols-2 gap-1 text-[10px]">
          <div class="flex justify-between bg-slate-950/60 rounded-md px-1.5 py-1"><span class="text-slate-400">الأساسي</span><span class="font-bold text-white">${maskMoney(financials.basicSalary, unlocked)}</span></div>
          <div class="flex justify-between bg-slate-950/60 rounded-md px-1.5 py-1"><span class="text-slate-400">بدل انتقال</span><span class="font-bold text-emerald-400">${unlocked ? "750 ج.م" : "🔒 ••••••"}</span></div>
          <div class="flex justify-between bg-slate-950/60 rounded-md px-1.5 py-1"><span class="text-slate-400">سعر س الإضافي</span><span class="font-bold text-cyan-300">${unlocked ? `${financials.otHourRate} ج.م` : "🔒 ••••••"}</span></div>
          <div class="flex justify-between bg-slate-950/60 rounded-md px-1.5 py-1"><span class="text-slate-400">إجمالي الإضافي</span><span class="font-bold text-amber-300">${maskMoney(financials.totalOvertimeMoney, unlocked)}</span></div>
          <div class="flex justify-between bg-slate-950/60 rounded-md px-1.5 py-1"><span class="text-slate-400">التأمينات</span><span class="font-bold text-rose-300">${unlocked ? "-" : ""}${maskMoney(financials.insuranceAmount, unlocked)}</span></div>
          <div class="flex justify-between bg-slate-950/60 rounded-md px-1.5 py-1"><span class="text-slate-400">الضريبة</span><span class="font-bold text-rose-300">${unlocked ? "-" : ""}${maskMoney(financials.monthlyTax, unlocked)}</span></div>
          <div class="flex justify-between bg-slate-950/60 rounded-md px-1.5 py-1"><span class="text-slate-400">الصافي (30 يوم)</span><span class="font-bold text-slate-200">${maskMoney(financials.netSalary, unlocked)}</span></div>
          <div class="flex justify-between bg-slate-950/60 rounded-md px-1.5 py-1 col-span-2 border border-[#D4AF37]/30 bg-amber-500/10"><span class="text-amber-200 font-bold">صافي المستحق المتوقع</span><span class="font-black text-[#D4AF37]">${maskMoney(financials.netExpectedSalary, unlocked)}</span></div>
        </div>
      </div>

      <div id="attendanceRow6" class="grid grid-cols-2 gap-1.5 pt-0.5">
        <button type="button" id="btnAddExtraDay" onclick="window.addExtraDayShift()" class="px-2 py-1.5 rounded-lg text-[10px] font-bold text-amber-200 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 active:scale-95 transition flex items-center justify-center gap-1 shadow-sm cursor-pointer"><span>➕</span><span>يوم إضافي</span></button>
        <button type="button" id="btnAddPastAttendance" onclick="window.openPastAttendanceModal()" class="px-2 py-1.5 rounded-lg text-[10px] font-bold text-sky-200 bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 active:scale-95 transition flex items-center justify-center gap-1 shadow-sm cursor-pointer"><span>🗓️</span><span>حضور سابق</span></button>
        <button type="button" id="btnTakeLeave" onclick="window.takeLeaveShift()" class="px-2 py-1.5 rounded-lg text-[10px] font-bold text-emerald-200 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 active:scale-95 transition flex items-center justify-center gap-1 shadow-sm cursor-pointer"><span>🏖️</span><span>إجازة رصيد</span></button>
        <button type="button" id="btnExportPdf" onclick="window.exportAttendancePDF()" class="px-2 py-1.5 rounded-lg text-[10px] font-bold text-cyan-200 bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 active:scale-95 transition flex items-center justify-center gap-1 shadow-sm cursor-pointer"><span>📄</span><span>تصدير PDF</span></button>
        <button type="button" id="btnExportPdfNow" onclick="window.exportMonthlySalaryPDF()" class="col-span-2 px-2 py-1.5 rounded-lg text-[10px] font-bold text-cyan-200 bg-gradient-to-r from-blue-600/30 to-cyan-600/30 hover:from-blue-600/50 hover:to-cyan-600/50 border border-cyan-400/40 active:scale-95 transition flex items-center justify-center gap-1 shadow-sm cursor-pointer"><span>📥</span><span>تصدير PDF الآن</span></button>
      </div>

      </div>
      <!-- نهاية حاوية الطي -->

    </div>
  </div>
  `;
}

// ============================================================
// 10. تسجيل الدوال العامة في window + التحديث والطي
// ============================================================

export function toggleAttendanceCard() {
  attendanceCardExpanded = !attendanceCardExpanded;

  const content = document.getElementById("attendanceExpandableContent");
  const chevron = document.getElementById("attendanceToggleChevron");
  const toggleBtn = document.getElementById("attendanceToggleBtn");

  if (content) {
    content.style.maxHeight = attendanceCardExpanded ? `${content.scrollHeight}px` : "0px";
    content.style.opacity = attendanceCardExpanded ? "1" : "0";
    content.setAttribute("aria-hidden", attendanceCardExpanded ? "false" : "true");
  }
  if (chevron) chevron.classList.toggle("rotate-180", attendanceCardExpanded);
  if (toggleBtn) {
    toggleBtn.setAttribute("aria-expanded", attendanceCardExpanded ? "true" : "false");
    toggleBtn.title = attendanceCardExpanded ? "طي التفاصيل" : "عرض كل التفاصيل";
  }
}

export async function refreshAttendanceCard() {
  const container = document.getElementById("attendanceCardContainer");
  if (container) {
    const profile = await getTechnicianProfile();
    await loadAttendanceSettingsCaches();
    container.innerHTML = renderAttendanceCard(profile);
  }
}

if (typeof window !== "undefined") {
  window.openEarlyDepartureModal = openEarlyDepartureModal;
  window.openDailyOvertimeModal = openDailyOvertimeModal;
  window.openAttendanceOptionsModal = openAttendanceOptionsModal;
  window.calculateSalary = calculateSalary;
  window.computeFinancials = computeFinancials;
  window.checkInShift = checkIn;
  window.checkOutShift = checkOut;
  window.addExtraDayShift = addExtraDay;
  window.takeLeaveShift = takeLeave;
  window.exportAttendancePDF = exportPDF;
  window.refreshAttendanceCard = refreshAttendanceCard;
  window.toggleAttendanceCard = toggleAttendanceCard;
  window.getMyShiftInfo = getMyShiftInfo;
  window.calculateAttendanceMonth = calculateMonth;
  window.calculateAttendanceCycle = calculateCycle;
  window.renderAttendanceCard = renderAttendanceCard;
  window.exportMonthlySalaryPDF = exportMonthlySalaryPDF;
  window.generateSalaryPDF = exportMonthlySalaryPDF;
  window.checkAndAutoExportMonthlyPDF = checkAndAutoExportMonthlyPDF;

  // فحص التصدير التلقائي لـ PDF عند تحميل الصفحة / السكريبت
  try {
    if (typeof document !== "undefined" && document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => {
        checkAndAutoExportMonthlyPDF();
      });
    } else {
      checkAndAutoExportMonthlyPDF();
    }
  } catch (e) {
    checkAndAutoExportMonthlyPDF();
  }

  // تحميل مبدئي غير معطِّل للإعدادات (Pattern/قواعد الإضافي) عشان
  // أول رسم للكارت (متزامن) يستخدم أحدث كاش متاح بمجرد اكتماله -
  // فقط لو فيه مستخدم مسجّل دخوله بالفعل (تجنّباً لأي محاولة قراءة
  // Firestore غير ضرورية في صفحة تسجيل الدخول قبل المصادقة)
  try {
    const isLoggedIn = localStorage.getItem("phone") || localStorage.getItem("userId");
    if (isLoggedIn) {
      loadAttendanceSettingsCaches().then(() => {
        const container = document.getElementById("attendanceCardContainer");
        if (container) refreshAttendanceCard();
      }).catch(() => {});
    }
  } catch (e) { /* localStorage غير متاح - تجاهل بأمان */ }
}
