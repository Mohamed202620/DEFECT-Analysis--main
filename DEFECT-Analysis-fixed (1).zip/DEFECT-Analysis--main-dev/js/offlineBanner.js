// ============================================================
// offlineBanner.js
// بانر أعلى الشاشة يوضّح حالة الاتصال بالإنترنت:
//  - أحمر ثابت عند الانقطاع
//  - أخضر لمدة 3 ثوانٍ عند عودة الاتصال، بعد ما يخلّص مزامنة أي
//    بلاغات محفوظة محلياً (راجع syncOfflineTicketsApi في ticketsApi.js)
// ============================================================

import { syncOfflineTicketsApi, syncOfflineTicketActionsApi } from './services/api.js';
import { translations } from './config.js';

const BANNER_ID = "offlineBanner";

// إصلاح (ترجمة شاملة): نصوص البانر كانت ثابتة بالعربي بغض النظر عن
// اللغة المختارة - دلوقتي بتقرأ من translations.offline حسب
// window.currentLang الحالي وقت كل ظهور للبانر
function t() {
  const currentLang = window.currentLang || "ar";
  return (translations[currentLang] || translations.ar).offline;
}

function ensureBannerEl() {

  let el = document.getElementById(BANNER_ID);

  if (!el) {
    el = document.createElement("div");
    el.id = BANNER_ID;
    document.body.appendChild(el);
  }

  return el;

}

function setBanner(visible, message, colorClass) {

  const el = ensureBannerEl();

  el.textContent = message || "";
  el.className =
    "fixed top-0 inset-x-0 z-[200] text-center text-xs font-bold py-2 " +
    "transition-transform duration-300 " +
    (visible ? "translate-y-0 " : "-translate-y-full ") +
    (colorClass || "");

  // إصلاح (بند مؤكد - Test 13، هواتف بها Notch/Dynamic Island): هذا
  // البانر مثبت أعلى الشاشة تماماً (fixed top-0) بنفس أسلوب الهيدر
  // الرئيسي في branding.js، لكن كان ناقصه معالجة safe-area-inset -
  // فكان بيظهر جزئياً أو كلياً خلف نتوء الكاميرا/شريط الحالة على
  // الهواتف ذات الشاشة المقطوعة (لأن viewport-fit=cover مفعّلة في
  // index.html). نفس الحل المستخدم بالفعل للهيدر الرئيسي بالحرف.
  el.style.paddingTop = "env(safe-area-inset-top, 0px)";

}

function hideBanner() {
  setBanner(false, "", "");
}

window.addEventListener("offline", () => {
  setBanner(true, t().offlineMsg, "bg-red-600 text-white");
});

let _syncRunning = false;

async function getPendingCount() {
  try {
    const { getQueuedTickets, getQueuedActions } = await import('./services/offlineQueue.js');
    const [tickets, actions] = await Promise.all([getQueuedTickets(), getQueuedActions()]);
    return tickets.length + actions.length;
  } catch (_) {
    return 0;
  }
}

// مؤشر العناصر المعلقة (بند M10): كان مفيش أي طريقة يعرف بيها المستخدم إن
// فيه بلاغات/إجراءات لسه ماوصلتش للسيرفر
async function refreshPendingIndicator() {
  if (_syncRunning) return;
  const pending = await getPendingCount();
  const isEn = (window.currentLang || "ar") === "en";
  if (pending > 0) {
    const online = typeof navigator === "undefined" || navigator.onLine;
    setBanner(
      true,
      online
        ? (isEn ? `⏳ ${pending} item(s) waiting to sync` : `⏳ ${pending} عنصر بانتظار المزامنة`)
        : (t().offlineMsg + (isEn ? ` - ${pending} saved locally` : ` - ${pending} محفوظ محلياً`)),
      online ? "bg-amber-600 text-white" : "bg-red-600 text-white"
    );
  } else if (typeof navigator !== "undefined" && navigator.onLine) {
    const el = document.getElementById(BANNER_ID);
    // مانخفيش بانر الأوفلاين/الأخطاء الأحمر والبرتقالي الخاص بنتيجة مزامنة
    if (el && el.textContent && el.textContent.includes("⏳")) hideBanner();
  }
}

// نقطة مزامنة واحدة: عند عودة الاتصال، بعد تسجيل الدخول، وبشكل دوري
async function runOfflineSync() {
  if (_syncRunning) return;
  _syncRunning = true;
  try {
  setBanner(true, t().syncing, "bg-green-600 text-white");

  try {

    // إضافة (تحسين Workflow - دعم Offline لتحديث الحالة): مزامنة
    // البلاغات الجديدة المحفوظة محلياً + إجراءات دورة حياة التذاكر
    // (بدء تنفيذ/تم الإصلاح/تأكيد الإغلاق) مع بعض عند عودة الاتصال
    const [ticketsResult, actionsResult] = await Promise.all([
      syncOfflineTicketsApi(),
      syncOfflineTicketActionsApi()
    ]);
    const synced = (ticketsResult?.synced || 0) + (actionsResult?.synced || 0);
    // إصلاح (Workflow): إجراءات الأوفلاين اللي فشلت نهائياً وقت المزامنة كانت
    // بتتمسح بصمت - دلوقتي المستخدم بيتنبه (التفاصيل في localStorage: failedOfflineActions)
    const failed = actionsResult?.failed || 0;

    if (failed > 0) {
      const isEn = (window.currentLang || "ar") === "en";
      setBanner(
        true,
        isEn
          ? `⚠️ ${failed} offline action(s) could not be applied (ticket state changed). Please review the tickets.`
          : `⚠️ تعذر تنفيذ ${failed} إجراء محفوظ أوفلاين (حالة التذكرة تغيّرت). برجاء مراجعة التذاكر.`,
        "bg-amber-600 text-white"
      );
      setTimeout(hideBanner, 10000);
      return;
    }

    setBanner(
      true,
      synced > 0 ? t().syncedWithCount.replace("{n}", synced) : t().restored,
      "bg-green-600 text-white"
    );

  } catch (error) {
    console.error("[OfflineSync] فشلت المزامنة التلقائية:", error);
    setBanner(true, t().restored, "bg-green-600 text-white");
  }

  setTimeout(hideBanner, 3000);
  } finally {
    _syncRunning = false;
  }
  setTimeout(refreshPendingIndicator, 3500);
}

// بعد تسجيل الدخول: بنزامن فقط لو فيه عناصر معلقة فعلاً (من غير وميض بانر "تمت الاستعادة")
window.triggerOfflineSync = async function () {
  if (await getPendingCount() > 0) runOfflineSync();
};

window.addEventListener("online", runOfflineSync);

// إعادة محاولة دورية (كل دقيقة) طالما فيه عناصر معلقة والاتصال شغّال - كان
// المحاولة الوحيدة وقت حدث "online" فقط، فأي فشل مؤقت كان يسيب البلاغ عالق
// لحد ما المستخدم يفصل ويرجّع النت
setInterval(async () => {
  if (typeof navigator !== "undefined" && !navigator.onLine) return;
  if (!localStorage.getItem("userId")) return;
  if (await getPendingCount() > 0) {
    runOfflineSync();
  } else {
    refreshPendingIndicator();
  }
}, 60000);

window.addEventListener("offline", () => { setTimeout(refreshPendingIndicator, 100); });

// لو التطبيق اتفتح والنت مقطوع من الأساس، يظهر البانر فوراً
if (typeof navigator !== "undefined") {
  if (!navigator.onLine) {
    setBanner(true, t().offlineMsg, "bg-red-600 text-white");
  } else {
    // لو التطبيق اتفتح والنت شغال، نتأكد إن مفيش حاجات عالقة في الطابور من جلسة سابقة
    setTimeout(async () => {
      try {
        const { getQueuedTickets, getQueuedActions } = await import('./services/offlineQueue.js');
        const [tickets, actions] = await Promise.all([getQueuedTickets(), getQueuedActions()]);
        if (tickets.length > 0 || actions.length > 0) {
          console.log("[OfflineSync] Found queued items on startup, triggering sync...");
          window.dispatchEvent(new Event("online"));
        }
      } catch (e) {
        console.error("Error checking queue on startup:", e);
      }
    }, 2000); // تأخير بسيط لضمان تهيئة التطبيق
  }
}
