import React from 'react';
import { X, CheckCircle2, AlertTriangle, Sparkles, Snowflake, Flame, Keyboard } from 'lucide-react';

interface InstructionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'ar' | 'en';
}

export const InstructionsModal: React.FC<InstructionsModalProps> = ({ isOpen, onClose, lang }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-700 rounded-2xl max-w-lg w-full p-6 text-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 left-4 p-1.5 rounded-lg bg-neutral-800 text-neutral-400 hover:text-white"
          aria-label="Close Help"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-xl sm:text-2xl font-black text-yellow-400 font-['Cairo'] text-center mb-4">
          {lang === 'ar' ? 'دليل المصنع: طريقة اللعب 🥫' : 'Factory Manual: How To Play 🥫'}
        </h3>

        <div className="space-y-4 text-sm text-neutral-300">
          {/* Rule 1: Bad Cans */}
          <div className="flex items-start gap-3 bg-red-950/40 border border-red-500/40 p-3 rounded-xl">
            <AlertTriangle className="w-6 h-6 text-red-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-red-300 text-base">
                {lang === 'ar' ? 'الكانز البايظة / التالفة (أولوية الفعص!)' : 'Defective Cans (Crush Priority!)'}
              </div>
              <p className="text-xs text-neutral-300 mt-0.5">
                {lang === 'ar'
                  ? 'أي كانز معووجة، مشروخة، أو عليها خطوط صفراء وسوداء! اضغط عليها فوراً لفعصها قبل أن تعبر الخط. تفويتها يلوث الإنتاج ويخسرك قلب!'
                  : 'Dented, cracked, smoking, or with yellow hazard tape. Tap immediately to crush! Letting them leak loses a life!'}
              </p>
            </div>
          </div>

          {/* Rule 2: Good Cans */}
          <div className="flex items-start gap-3 bg-emerald-950/40 border border-emerald-500/40 p-3 rounded-xl">
            <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-emerald-300 text-base">
                {lang === 'ar' ? 'الكانز السليمة (ممنوع لمسها!)' : 'Pristine Cans (DO NOT TOUCH!)'}
              </div>
              <p className="text-xs text-neutral-300 mt-0.5">
                {lang === 'ar'
                  ? 'المشروبات اللامعة النظيفة (ZIP, ZING, POP, FIZZY). سيبها تعدي بسلام لمخرج الإنتاج لتحصل على نقاط أمان +10. فعصها بالغلط هيخسرك قلب!'
                  : 'Shiny, perfect soda cans. Let them pass down safely into the packing chute for +10 safe points. Crushing them costs a life!'}
              </p>
            </div>
          </div>

          {/* Powerups */}
          <div className="bg-neutral-950 p-3.5 rounded-xl border border-neutral-800 space-y-2">
            <div className="font-bold text-yellow-300 text-sm flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-yellow-400" />
              <span>{lang === 'ar' ? 'كانز الطاقة والجوائز الخاصة:' : 'Special Powerup Cans:'}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <div className="p-2 rounded bg-amber-950/40 border border-amber-500/30 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-300 shrink-0" />
                <span>{lang === 'ar' ? 'الدهبية: +500 نقطة' : 'Gold: +500 Pts'}</span>
              </div>
              <div className="p-2 rounded bg-cyan-950/40 border border-cyan-500/30 flex items-center gap-1.5">
                <Snowflake className="w-4 h-4 text-cyan-300 shrink-0" />
                <span>{lang === 'ar' ? 'التجميد: تبطيء السير 4ث' : 'Freeze: Slows 4s'}</span>
              </div>
              <div className="p-2 rounded bg-rose-950/40 border border-rose-500/30 flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-orange-400 shrink-0" />
                <span>{lang === 'ar' ? 'النيترو: انفجار الفعص' : 'Nitro: Crush Wave'}</span>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2 text-xs text-neutral-400 bg-neutral-800/60 p-2.5 rounded-lg">
            <Keyboard className="w-4 h-4 text-neutral-300" />
            <span>
              {lang === 'ar'
                ? 'التحكم: اضغط بالماوس أو اللمس على الكانز، أو اضغط مسطرة (Space) للضغط على مكبس الفعص بالأسفل.'
                : 'Controls: Click or tap cans directly, or press Spacebar to slam the Crush Zone press!'}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-5 w-full py-3 bg-yellow-400 hover:bg-yellow-300 text-black font-black rounded-xl text-base transition-colors"
        >
          {lang === 'ar' ? 'فهمت.. يلا للخط! 🚀' : 'Got it! Start Crushing! 🚀'}
        </button>
      </div>
    </div>
  );
};
