import React, { useState } from 'react';
import { Cog, Zap } from 'lucide-react';
import { sounds, triggerHaptic } from '../sound';

interface CrushZoneProps {
  onSlamPress: () => void;
  lang: 'ar' | 'en';
}

export const CrushZone: React.FC<CrushZoneProps> = ({ onSlamPress, lang }) => {
  const [isPressing, setIsPressing] = useState(false);

  const handlePress = () => {
    setIsPressing(true);
    sounds.playHydraulicPress();
    triggerHaptic('heavy');
    onSlamPress();
    setTimeout(() => setIsPressing(false), 160);
  };

  return (
    <div className="relative w-full select-none z-30">
      {/* Hydraulic Piston Visual Bars */}
      <div className="flex justify-between px-8 sm:px-16 pointer-events-none -mb-1">
        <div
          className="w-5 sm:w-7 bg-gradient-to-r from-neutral-600 via-neutral-300 to-neutral-700 h-4 border-x border-t border-neutral-900 shadow-md transition-all duration-100"
          style={{ transform: isPressing ? 'translateY(8px)' : 'translateY(0)' }}
        />
        <div
          className="w-5 sm:w-7 bg-gradient-to-r from-neutral-600 via-neutral-300 to-neutral-700 h-4 border-x border-t border-neutral-900 shadow-md transition-all duration-100"
          style={{ transform: isPressing ? 'translateY(8px)' : 'translateY(0)' }}
        />
      </div>

      {/* Main Crush Zone Bar */}
      <button
        type="button"
        onClick={handlePress}
        className={`w-full h-16 sm:h-20 relative overflow-hidden transition-all duration-100 flex items-center justify-between px-4 sm:px-8 border-y-4 border-yellow-400 cursor-pointer shadow-[0_-8px_25px_rgba(0,0,0,0.8)] active:brightness-125 focus:outline-none ${
          isPressing
            ? 'scale-[0.985] bg-gradient-to-r from-red-600 via-yellow-500 to-red-600'
            : 'bg-[repeating-linear-gradient(45deg,#eab308,#eab308_24px,#18181b_24px,#18181b_48px)]'
        }`}
        aria-label="Crush Zone Hydraulic Press"
      >
        {/* Glow Overlay */}
        <div className="absolute inset-0 bg-black/45 pointer-events-none" />

        {/* Center Banner Text Plate */}
        <div className="relative z-10 w-full flex items-center justify-center gap-2 sm:gap-4 bg-neutral-950/90 py-2 px-4 rounded-xl border border-yellow-400/80 shadow-2xl backdrop-blur-sm">
          <Cog className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-400 animate-spin" style={{ animationDuration: '6s' }} />

          <div className="flex flex-col items-center">
            <span className="text-sm sm:text-lg md:text-xl font-black tracking-wider text-yellow-400 uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] font-['Cairo']">
              {lang === 'ar' ? '⚙️ دوس على البايظ بس! ⚙️' : '⚙️ CRUSH DEFECTS ONLY! ⚙️'}
            </span>
            <span className="text-[10px] sm:text-xs text-neutral-300 font-semibold flex items-center gap-1">
              <Zap className="w-3 h-3 text-cyan-400" />
              {lang === 'ar'
                ? 'اضغط هنا أو على الكانز التالفة لفعصها فوراً'
                : 'Tap cans directly or hit this press to crush danger zone'}
            </span>
          </div>

          <Cog className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-400 animate-spin" style={{ animationDuration: '6s', animationDirection: 'reverse' }} />
        </div>
      </button>

      {/* Pristine Cans Safe Collection Chute Indication */}
      <div className="w-full bg-neutral-900 border-b border-neutral-800 py-1.5 px-4 flex items-center justify-between text-[11px] sm:text-xs text-neutral-400">
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
          <span className="text-emerald-400 font-bold">
            {lang === 'ar' ? 'مخرج الكانز السليمة' : 'Pristine Safe Chute'}
          </span>
          <span className="hidden sm:inline text-neutral-500">
            {lang === 'ar' ? '(السليم يعدي بأمان +10 نقاط)' : '(Clean cans pass safely for +10 pts)'}
          </span>
        </span>
        <span className="text-amber-400/90 font-mono">
          {lang === 'ar' ? 'تحذير: لا تفعص السليم!' : 'Warning: Never crush pristine!'}
        </span>
      </div>
    </div>
  );
};
