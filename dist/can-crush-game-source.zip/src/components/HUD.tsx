import React from 'react';
import { Volume2, VolumeX, Pause, Play, HelpCircle, Flame, Heart, RotateCcw, Globe, Sparkles, Smartphone } from 'lucide-react';
import { GameMode, VisualStyle } from '../types';

interface HUDProps {
  score: number;
  highScore: number;
  level: number;
  lives: number;
  maxLives: number;
  combo: number;
  mode: GameMode;
  visualStyle: VisualStyle;
  timeLeft?: number; // for frenzy mode
  isPaused: boolean;
  soundEnabled: boolean;
  lang: 'ar' | 'en';
  onToggleSound: () => void;
  onTogglePause: () => void;
  onRestart: () => void;
  onOpenHelp: () => void;
  onToggleLang: () => void;
  onToggleVisualStyle: () => void;
  onOpenInstall: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  score,
  highScore,
  level,
  lives,
  maxLives,
  combo,
  mode,
  visualStyle,
  timeLeft = 60,
  isPaused,
  soundEnabled,
  lang,
  onToggleSound,
  onTogglePause,
  onRestart,
  onOpenHelp,
  onToggleLang,
  onToggleVisualStyle,
  onOpenInstall,
}) => {
  return (
    <header className="relative w-full bg-neutral-950/95 border-b border-neutral-800 text-white select-none z-40 backdrop-blur px-3 sm:px-6 py-2.5 shadow-lg">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
        {/* LEFT / RIGHT ZONE (Brand & Status) */}
        <div className="flex items-center gap-3 sm:gap-5">
          <div className="flex items-center gap-1.5">
            <span className="text-xl sm:text-2xl font-black tracking-tight text-yellow-400 font-['Chakra_Petch']">
              CAN CRUSH
            </span>
            <span className="text-xs font-black bg-yellow-400 text-black px-1.5 py-0.5 rounded uppercase tracking-wider">
              PRO
            </span>
          </div>

          {/* Mode Badge */}
          <div className="hidden md:flex items-center gap-1 text-xs text-neutral-400">
            <span>·</span>
            <span className="font-semibold text-neutral-300">
              {mode === 'arcade'
                ? lang === 'ar' ? 'كلاسيك 3 محاولات' : 'Arcade 3 Lives'
                : mode === 'frenzy'
                ? lang === 'ar' ? 'تحدي الدقيقة' : '60s Frenzy'
                : lang === 'ar' ? 'استرخاء بلا نهاية' : 'Zen Endless'}
            </span>
          </div>
        </div>

        {/* CENTER STATS (Exact matching to user's: سكورك, التوب, سرعة + Combo & Lives) */}
        <div className="flex items-center gap-3 sm:gap-6 bg-neutral-900/90 border border-neutral-800 rounded-lg px-3 py-1">
          {/* Score */}
          <div className="flex items-baseline gap-1.5">
            <span className="text-xs text-neutral-400 font-medium">
              {lang === 'ar' ? 'سكورك:' : 'Score:'}
            </span>
            <span className="text-base sm:text-xl font-black text-emerald-400 font-mono tabular-nums">
              {score}
            </span>
          </div>

          {/* High Score / Best */}
          <div className="flex items-baseline gap-1.5">
            <span className="text-xs text-neutral-400 font-medium">
              {lang === 'ar' ? 'التوب:' : 'Best:'}
            </span>
            <span className="text-sm sm:text-lg font-bold text-amber-300 font-mono tabular-nums">
              {highScore}
            </span>
          </div>

          {/* Speed / Level */}
          <div className="flex items-baseline gap-1.5">
            <span className="text-xs text-neutral-400 font-medium">
              {lang === 'ar' ? 'سرعة:' : 'Speed:'}
            </span>
            <span className="text-sm sm:text-lg font-bold text-cyan-400 font-mono tabular-nums">
              Lv.{level}
            </span>
          </div>

          {/* Mode Specific: Lives OR Timer */}
          {mode === 'arcade' && (
            <div className="hidden sm:flex items-center gap-1 pl-2 border-l border-neutral-800">
              {Array.from({ length: maxLives }).map((_, i) => (
                <Heart
                  key={i}
                  className={`w-4 h-4 transition-all ${
                    i < lives
                      ? 'text-rose-500 fill-rose-500 scale-100'
                      : 'text-neutral-700 fill-neutral-800 scale-90'
                  }`}
                />
              ))}
            </div>
          )}

          {mode === 'frenzy' && (
            <div className="flex items-baseline gap-1 pl-2 border-l border-neutral-800 font-mono font-bold text-rose-400">
              <span className="text-xs text-neutral-400">⏱️</span>
              <span className="text-base sm:text-lg">{timeLeft}s</span>
            </div>
          )}

          {/* Combo Indicator */}
          {combo > 1 && (
            <div className="flex items-center gap-1 text-xs font-black text-amber-400 animate-bounce pl-1">
              <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>x{combo}</span>
            </div>
          )}
        </div>

        {/* RIGHT ACTION CONTROLS */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Sound Toggle */}
          <button
            type="button"
            onClick={onToggleSound}
            className="p-1.5 sm:p-2 rounded-md hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors"
            title={soundEnabled ? 'Mute Audio' : 'Enable Audio'}
            aria-label="Toggle Sound"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400" /> : <VolumeX className="w-4 h-4 sm:w-5 sm:h-5 text-neutral-500" />}
          </button>

          {/* Pause Toggle */}
          <button
            type="button"
            onClick={onTogglePause}
            className="p-1.5 sm:p-2 rounded-md hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors"
            title={isPaused ? 'Resume Game' : 'Pause Game'}
            aria-label="Pause/Resume"
          >
            {isPaused ? <Play className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400" /> : <Pause className="w-4 h-4 sm:w-5 sm:h-5" />}
          </button>

          {/* Realism Style Toggle */}
          <button
            type="button"
            onClick={onToggleVisualStyle}
            className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1 rounded-md text-xs font-bold transition-all border ${
              visualStyle === 'photostudio'
                ? 'bg-amber-400/20 border-amber-400 text-amber-300 shadow-[0_0_12px_rgba(251,191,36,0.35)]'
                : 'bg-neutral-900 border-neutral-700 text-neutral-300 hover:text-white hover:border-neutral-500'
            }`}
            title={lang === 'ar' ? 'تبديل شكل الكانز: واقعي استوديو / مجسم ألومنيوم' : 'Toggle Realism Style'}
          >
            <Sparkles className="w-3.5 h-3.5 text-yellow-400 animate-pulse" />
            <span className="hidden sm:inline">
              {visualStyle === 'photostudio'
                ? lang === 'ar' ? 'صور استوديو 3D' : 'Studio Photos'
                : lang === 'ar' ? 'مجسم ألومنيوم 3D' : 'Ultra 3D'}
            </span>
          </button>

          {/* Mobile Install PWA Button */}
          <button
            type="button"
            onClick={onOpenInstall}
            className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1 rounded-md text-xs font-bold transition-all bg-yellow-400/15 hover:bg-yellow-400/25 border border-yellow-400/60 text-yellow-300"
            title={lang === 'ar' ? 'تنزيل اللعبة على الموبايل' : 'Install on Mobile'}
          >
            <Smartphone className="w-3.5 h-3.5 text-yellow-400" />
            <span className="hidden sm:inline">{lang === 'ar' ? 'تنزيل' : 'Install'}</span>
          </button>

          {/* Quick Restart */}
          <button
            type="button"
            onClick={onRestart}
            className="p-1.5 sm:p-2 rounded-md hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors"
            title="Restart Run"
            aria-label="Restart Game"
          >
            <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Language Switch */}
          <button
            type="button"
            onClick={onToggleLang}
            className="flex items-center gap-1 px-2 py-1 rounded-md bg-neutral-900 border border-neutral-700 hover:border-yellow-400 text-xs font-semibold text-neutral-200 transition-colors"
            title="Change Language"
          >
            <Globe className="w-3.5 h-3.5 text-yellow-400" />
            <span>{lang === 'ar' ? 'EN' : 'عربي'}</span>
          </button>

          {/* Instructions Modal Trigger */}
          <button
            type="button"
            onClick={onOpenHelp}
            className="p-1.5 sm:p-2 rounded-md hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
            title="Rules & Help"
            aria-label="Help"
          >
            <HelpCircle className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
