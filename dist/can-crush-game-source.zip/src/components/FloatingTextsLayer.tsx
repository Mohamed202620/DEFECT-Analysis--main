import React from 'react';
import { FloatingText } from '../types';

interface FloatingTextsLayerProps {
  texts: FloatingText[];
}

export const FloatingTextsLayer: React.FC<FloatingTextsLayerProps> = ({ texts }) => {
  return (
    <div className="absolute inset-0 pointer-events-none z-35 overflow-hidden">
      {texts.map((item) => (
        <div
          key={item.id}
          className="absolute -translate-x-1/2 -translate-y-1/2 font-black select-none pointer-events-none drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)] animate-float-fade"
          style={{
            left: `${item.x}px`,
            top: `${item.y}px`,
            color: item.color,
            fontSize: item.isCombo ? '24px' : '18px',
            fontFamily: "'Chakra Petch', 'Cairo', sans-serif",
          }}
        >
          {item.text}
        </div>
      ))}
    </div>
  );
};
