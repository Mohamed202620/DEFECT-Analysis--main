import React from 'react';
import { Trophy, RotateCcw, Award, CheckCircle, AlertOctagon, Flame } from 'lucide-react';
import { GameMode } from '../types';

interface GameOverModalProps {
  score: number;
  highScore: number;
  isNewHigh: boolean;
  crushedCount: number;
  savedCount: number;
  maxCombo: number;
  mode: GameMode;
  lang: 'ar' | 'en';
  onRestart: () => void;
  onChangeMode: (mode: GameMode) => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  highScore,
  isNewHigh,
  crushedCount,
  savedCount,
  maxCombo,
  mode,
  lang,
  onRestart,
  onChangeMode,
}) => {
  // Determine title / rank based on score
  const getRank = () => {
    if (score >= 4000) return { title: lang === 'ar' ? 'أسطورة الفعص 👑' : 'Crush Titan 👑', color: 'text-amber-400' };
    if (score >= 2500) return { title: lang === 'ar' ? 'مشرف جودة عبقري 🎖️' : 'Quality Master 🎖️', color: 'text-purple-400' };
    if (score >= 1200) return { title: lang === 'ar' ? 'فرّيز كانز محترف ⚡' : 'Senior Sorter ⚡', color: 'text-cyan-400' };
    if (score >= 500) return { title: lang === 'ar' ? 'عامل خط متمرس 🏭' : 'Factory Specialist 🏭', color: 'text-emerald-400' };
    return { title: lang === 'ar' ? 'متدرب على السير 🧤' : 'Conveyor Apprentice 🧤', color: 'text-neutral-400' };
  };

  const rank = getRank();

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-700/80 rounded-2xl max-w-md w-full p-6 text-center shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header Icon */}
        <div className="mx-auto w-16 h-16 rounded-2xl bg-neutral-800/80 border border-yellow-400/50 flex items-center justify-center mb-4 shadow-[0_0_20px_rgba(250,204,21,0.2)]">
          {isNewHigh ? (
            <Trophy className="w-9 h-9 text-yellow-400 animate-bounce" />
          ) : (
            <Award className="w-9 h-9 text-neutral-300" />
          )}
        </div>

        {/* Title */}
        <h2 className="text-2xl sm:text-3xl font-black text-white font-['Cairo'] mb-1">
          {isNewHigh
            ? lang === 'ar' ? '🎉 رقم قياسي جديد! 🎉' : '🎉 New High Score! 🎉'
            : lang === 'ar' ? 'انتهت الوردية!' : 'Shift Ended!'}
        </h2>

        {/* Quality Rank Badge */}
        <div className="inline-block px-3 py-1 bg-neutral-800 rounded-full border border-neutral-700 text-sm font-bold mb-5">
          <span className={rank.color}>{rank.title}</span>
        </div>

        {/* Score Displays */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          <div className="bg-neutral-950/80 border border-neutral-800 rounded-xl p-3">
            <span className="text-xs text-neutral-400 block mb-1">
              {lang === 'ar' ? 'سكورك النهائي' : 'Final Score'}
            </span>
            <span className="text-2xl font-black text-emerald-400 font-mono tabular-nums">
              {score}
            </span>
          </div>

          <div className="bg-neutral-950/80 border border-neutral-800 rounded-xl p-3">
            <span className="text-xs text-neutral-400 block mb-1">
              {lang === 'ar' ? 'أعلى سكور' : 'All-time Best'}
            </span>
            <span className="text-2xl font-black text-amber-400 font-mono tabular-nums">
              {highScore}
            </span>
          </div>
        </div>

        {/* Detailed Stats Breakdown */}
        <div className="bg-neutral-950/60 border border-neutral-800/80 rounded-xl p-3 space-y-2 mb-6 text-sm text-neutral-300 text-right">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <AlertOctagon className="w-4 h-4 text-rose-400" />
              <span>{lang === 'ar' ? 'كانز بايظة تم فعصها:' : 'Defects Crushed:'}</span>
            </span>
            <span className="font-bold text-white font-mono">{crushedCount}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'ar' ? 'كانز سليمة عبرت بأمان:' : 'Pristine Cans Saved:'}</span>
            </span>
            <span className="font-bold text-white font-mono">{savedCount}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-amber-400" />
              <span>{lang === 'ar' ? 'أطول سلسلة كومبو:' : 'Max Combo Streak:'}</span>
            </span>
            <span className="font-bold text-amber-400 font-mono">x{maxCombo}</span>
          </div>
        </div>

        {/* Mode Selector for next run */}
        <div className="flex items-center justify-center gap-1 p-1 bg-neutral-950 rounded-lg mb-5 border border-neutral-800 text-xs font-semibold">
          <button
            type="button"
            onClick={() => onChangeMode('arcade')}
            className={`flex-1 py-1.5 rounded-md transition-colors ${
              mode === 'arcade' ? 'bg-yellow-400 text-black shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            {lang === 'ar' ? 'كلاسيك (3 قلوب)' : 'Arcade'}
          </button>
          <button
            type="button"
            onClick={() => onChangeMode('frenzy')}
            className={`flex-1 py-1.5 rounded-md transition-colors ${
              mode === 'frenzy' ? 'bg-yellow-400 text-black shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            {lang === 'ar' ? 'دقيقة جنونية' : '60s Frenzy'}
          </button>
          <button
            type="button"
            onClick={() => onChangeMode('zen')}
            className={`flex-1 py-1.5 rounded-md transition-colors ${
              mode === 'zen' ? 'bg-yellow-400 text-black shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            {lang === 'ar' ? 'استرخاء' : 'Zen'}
          </button>
        </div>

        {/* Primary Action Button */}
        <button
          type="button"
          onClick={onRestart}
          className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-yellow-400 to-amber-500 hover:from-yellow-300 hover:to-amber-400 text-black font-black text-base sm:text-lg flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(250,204,21,0.35)] transition-all active:scale-98 cursor-pointer"
        >
          <RotateCcw className="w-5 h-5 stroke-[2.5]" />
          <span>{lang === 'ar' ? 'العب تاني دلوقتي!' : 'Play Again Now!'}</span>
        </button>
      </div>
    </div>
  );
};
