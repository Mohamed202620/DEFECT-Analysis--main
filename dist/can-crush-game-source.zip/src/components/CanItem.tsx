import React from 'react';
import { CanData, VisualStyle } from '../types';
import { AlertTriangle, Sparkles, Snowflake, Flame } from 'lucide-react';
import pristineImg from '../assets/images/can_pristine_citrus_1790193863694.jpg';
import defectImg from '../assets/images/can_dented_defect_1790193874943.jpg';
import goldImg from '../assets/images/can_gold_edition_1790193884872.jpg';

interface CanItemProps {
  can: CanData;
  onCrush: (can: CanData, e: React.MouseEvent | React.TouchEvent) => void;
  lang: 'ar' | 'en';
  visualStyle?: VisualStyle;
}

export const CanItem: React.FC<CanItemProps> = ({
  can,
  onCrush,
  lang,
  visualStyle = 'ultra3d',
}) => {
  const isCrushed = can.isCrushed;

  // Determine flavor theme, colors, and gradients
  const getCanTheme = () => {
    switch (can.type) {
      case 'golden':
        return {
          baseColor: '#eab308',
          glow: 'rgba(234, 179, 8, 0.85)',
          rimColor: '#fef08a',
          badge: '24K GOLD',
          badgeColor: 'bg-yellow-300 text-yellow-950 font-black',
        };
      case 'freeze':
        return {
          baseColor: '#0284c7',
          glow: 'rgba(56, 189, 248, 0.85)',
          rimColor: '#e0f2fe',
          badge: 'CRYOFROST',
          badgeColor: 'bg-cyan-300 text-cyan-950 font-black',
        };
      case 'nitro':
        return {
          baseColor: '#dc2626',
          glow: 'rgba(239, 68, 68, 0.85)',
          rimColor: '#fed7aa',
          badge: 'NITRO BURST',
          badgeColor: 'bg-orange-300 text-red-950 font-black',
        };
      case 'bad':
        return {
          baseColor: '#b91c1c',
          glow: 'rgba(239, 68, 68, 0.95)',
          rimColor: '#cbd5e1',
          badge: lang === 'ar' ? 'تالف / بايظ ⚠️' : 'DEFECT ⚠️',
          badgeColor: 'bg-yellow-400 text-black font-black animate-pulse',
        };
      case 'good':
      default:
        return {
          baseColor: can.baseColor || '#0284c7',
          glow: can.glowColor || 'rgba(14, 165, 233, 0.7)',
          rimColor: '#e2e8f0',
          badge: can.flavor,
          badgeColor: 'bg-black/60 text-white/95 border border-white/20',
        };
    }
  };

  const theme = getCanTheme();

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={`${can.type} can ${can.name}`}
      onClick={(e) => onCrush(can, e)}
      onTouchStart={(e) => onCrush(can, e)}
      className="absolute cursor-pointer select-none will-change-transform group transition-transform active:scale-95"
      style={{
        left: `${can.x}%`,
        top: `${can.y}px`,
        transform: `translateX(-50%) rotate(${can.rotation}deg) scale(${
          isCrushed ? '1.25, 0.22' : '1, 1'
        })`,
        opacity: isCrushed ? 0.4 : 1,
        transition: isCrushed
          ? 'transform 0.16s cubic-bezier(0.1, 0.9, 0.2, 1), opacity 0.2s'
          : 'none',
        zIndex: isCrushed ? 5 : 20,
      }}
    >
      {/* 3D REALISTIC CAN CONTAINER */}
      <div
        className="relative w-[78px] sm:w-[88px] h-[126px] sm:h-[142px]"
        style={{
          filter: `drop-shadow(0 12px 18px rgba(0,0,0,0.85)) drop-shadow(0 0 10px ${theme.glow})`,
        }}
      >
        {/* ============================================================== */}
        {/* MODE 1: PHOTOSTUDIO 3D RENDER SPRITE                          */}
        {/* ============================================================== */}
        {visualStyle === 'photostudio' ? (
          <div className="relative w-full h-full rounded-2xl overflow-hidden flex items-center justify-center bg-black/40 border border-neutral-700/60 shadow-inner">
            {can.type === 'good' && (
              <img
                src={pristineImg}
                alt="Pristine Cold Soda Can"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter contrast-110 drop-shadow-md"
              />
            )}
            {can.type === 'bad' && (
              <img
                src={defectImg}
                alt="Defective Smashed Soda Can"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter contrast-115 drop-shadow-md"
              />
            )}
            {can.type === 'golden' && (
              <img
                src={goldImg}
                alt="24K Golden Soda Can"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter contrast-120 drop-shadow-md"
              />
            )}
            {can.type === 'freeze' && (
              <img
                src={pristineImg}
                alt="Frozen Soda Can"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter hue-rotate-180 brightness-110 drop-shadow-md"
              />
            )}
            {can.type === 'nitro' && (
              <img
                src={pristineImg}
                alt="Nitro Soda Can"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter hue-rotate-60 saturate-200 drop-shadow-md"
              />
            )}

            {/* Crushed Stamp Overlay */}
            {isCrushed && (
              <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                <span className="text-amber-400 font-black text-xs tracking-wider uppercase border border-amber-400 px-1 rounded bg-black/70 rotate-6">
                  💥 CRUSHED!
                </span>
              </div>
            )}
          </div>
        ) : (
          /* ============================================================== */
          /* MODE 2: ULTRA 3D PROCEDURAL ALUMINUM VECTOR ENGINE (DEFAULT)   */
          /* ============================================================== */
          <svg
            viewBox="0 0 100 160"
            className="w-full h-full overflow-visible"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              {/* Cylindrical Aluminum Body Gradient (Specular Highlight & Ambient Occlusion) */}
              <linearGradient id={`cylGrad-${can.id}`} x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#050505" stopOpacity="0.85" />
                <stop offset="9%" stopColor="#ffffff" stopOpacity="0.22" />
                <stop offset="22%" stopColor={theme.baseColor} stopOpacity="0.88" />
                <stop offset="37%" stopColor="#ffffff" stopOpacity="0.96" />
                <stop offset="47%" stopColor={theme.baseColor} stopOpacity="0.9" />
                <stop offset="78%" stopColor={theme.baseColor} stopOpacity="1" />
                <stop offset="92%" stopColor="#ffffff" stopOpacity="0.14" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0.9" />
              </linearGradient>

              {/* Aluminum Metal Chime & Lid Gradient */}
              <linearGradient id={`metalRim-${can.id}`} x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#64748b" />
                <stop offset="22%" stopColor="#cbd5e1" />
                <stop offset="38%" stopColor="#ffffff" />
                <stop offset="58%" stopColor="#cbd5e1" />
                <stop offset="82%" stopColor="#475569" />
                <stop offset="100%" stopColor="#1e293b" />
              </linearGradient>

              {/* Top Countersunk Lid Oval Radial Gradient */}
              <radialGradient id={`lidSurface-${can.id}`} cx="44%" cy="38%" r="58%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="40%" stopColor="#cbd5e1" />
                <stop offset="75%" stopColor="#94a3b8" />
                <stop offset="100%" stopColor="#334155" />
              </radialGradient>

              {/* Pull Tab Metallic Gradient */}
              <linearGradient id={`pullTabGrad-${can.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="40%" stopColor="#cbd5e1" />
                <stop offset="75%" stopColor="#94a3b8" />
                <stop offset="100%" stopColor="#475569" />
              </linearGradient>

              {/* Hazard Stripe Pattern for Defects */}
              <pattern
                id={`hazardPattern-${can.id}`}
                width="14"
                height="14"
                patternUnits="userSpaceOnUse"
                patternTransform="rotate(45)"
              >
                <rect width="7" height="14" fill="#facc15" />
                <rect x="7" width="7" height="14" fill="#18181b" />
              </pattern>

              {/* Metal Crease Filter for Photorealistic Dents */}
              <filter id={`dentedFilter-${can.id}`} x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="-1" dy="1.5" stdDeviation="1.2" floodColor="#000000" floodOpacity="0.85" />
              </filter>
            </defs>

            {/* ============================================================== */}
            {/* CAN BODY (Standard Pristine vs Dented Buckled Path)           */}
            {/* ============================================================== */}
            {can.type === 'bad' ? (
              /* DENTED, BUCKLED, CRUMPLED DEFECTIVE CAN PATH */
              <g filter={`url(#dentedFilter-${can.id})`}>
                {/* Buckled Aluminum Body Silhouette with severe dents */}
                <path
                  d="M 17,25 
                     C 19,25 21,38 14,54 
                     C 8,72 26,82 17,105 
                     C 13,122 18,142 19,148
                     C 28,153 72,153 81,148
                     C 83,142 86,115 76,96
                     C 66,77 88,58 83,40
                     C 81,28 83,25 83,25
                     Z"
                  fill={`url(#cylGrad-${can.id})`}
                  stroke="#18181b"
                  strokeWidth="1.2"
                />

                {/* Creased Buckle Shadow Folds */}
                <path
                  d="M 14,54 Q 38,72 52,65 Q 68,58 76,96"
                  fill="none"
                  stroke="#09090b"
                  strokeWidth="2.8"
                  strokeLinecap="round"
                  opacity="0.9"
                />
                <path
                  d="M 15,55 Q 38,73 52,66 Q 68,59 75,95"
                  fill="none"
                  stroke="#fca5a5"
                  strokeWidth="1.2"
                  strokeLinecap="round"
                  opacity="0.8"
                />

                {/* Lower dent puncture crease */}
                <path
                  d="M 26,102 Q 45,116 64,106"
                  fill="none"
                  stroke="#000000"
                  strokeWidth="2.2"
                  opacity="0.9"
                />
                <path
                  d="M 27,103 Q 45,117 64,107"
                  fill="none"
                  stroke="#ffffff"
                  strokeWidth="0.9"
                  opacity="0.65"
                />

                {/* Hazard Tape Band across damaged midsection */}
                <g transform="rotate(-8 50 82)">
                  <rect
                    x="6"
                    y="74"
                    width="88"
                    height="16"
                    fill={`url(#hazardPattern-${can.id})`}
                    opacity="0.95"
                    stroke="#000000"
                    strokeWidth="0.8"
                    rx="1"
                  />
                  <rect x="20" y="77" width="60" height="10" fill="#000000" rx="2" opacity="0.85" />
                  <text
                    x="50"
                    y="85"
                    fill="#facc15"
                    fontSize="7.5"
                    fontWeight="900"
                    fontFamily="'Chakra Petch', sans-serif"
                    textAnchor="middle"
                    letterSpacing="0.8"
                  >
                    REJECTED QC
                  </text>
                </g>

                {/* Leaking Carbonated Fizz Droplets */}
                <circle cx="20" cy="62" r="2.2" fill="#ef4444" opacity="0.95" />
                <circle cx="19" cy="75" r="1.8" fill="#f87171" opacity="0.85" />
                <circle cx="21" cy="90" r="1.4" fill="#ffffff" opacity="0.95" />
              </g>
            ) : (
              /* PRISTINE, SMOOTH 330ML CYLINDER BODY */
              <g>
                {/* Tapered Shoulder (Neck-in choke narrowing from body to lid) */}
                <path
                  d="M 18,25 
                     C 18,21 21,18 24,16 
                     L 76,16 
                     C 79,18 82,21 82,25 
                     L 82,28 
                     L 18,28 
                     Z"
                  fill={`url(#metalRim-${can.id})`}
                />

                {/* Main Can Cylinder Body */}
                <path
                  d="M 15,26 
                     L 85,26 
                     L 85,145 
                     C 85,150 78,154 50,154 
                     C 22,154 15,150 15,145 
                     Z"
                  fill={`url(#cylGrad-${can.id})`}
                  stroke="#334155"
                  strokeWidth="0.6"
                />

                {/* Bottom Rim Chime & Concave Base */}
                <ellipse cx="50" cy="144" rx="35" ry="5.5" fill="none" stroke="#475569" strokeWidth="1" />
                <path
                  d="M 18,144 C 20,151 80,151 82,144 L 81,149 C 78,154 22,154 19,149 Z"
                  fill={`url(#metalRim-${can.id})`}
                />

                {/* Specular Razor Gloss Light Reflection Bar */}
                <rect
                  x="33"
                  y="26"
                  width="8"
                  height="120"
                  fill="url(#metalRim)"
                  fillOpacity="0.35"
                  style={{ mixBlendMode: 'overlay' }}
                />
                <rect x="36" y="26" width="3" height="120" fill="#ffffff" fillOpacity="0.48" />

                {/* Real Ice Condensation Droplets (Water Beads on Aluminum) */}
                <g opacity="0.88">
                  <ellipse cx="28" cy="45" rx="1.8" ry="2.4" fill="#ffffff" opacity="0.9" />
                  <circle cx="29" cy="46" r="1.6" fill="#000000" opacity="0.25" />

                  <ellipse cx="64" cy="52" rx="2" ry="2.8" fill="#ffffff" opacity="0.8" />
                  <circle cx="65" cy="53" r="1.8" fill="#000000" opacity="0.25" />

                  <ellipse cx="74" cy="85" rx="1.6" ry="2" fill="#ffffff" opacity="0.85" />
                  <ellipse cx="38" cy="98" rx="2.2" ry="3" fill="#ffffff" opacity="0.9" />
                  <circle cx="39" cy="99" r="2" fill="#000000" opacity="0.2" />

                  <ellipse cx="68" cy="118" rx="1.8" ry="2.2" fill="#ffffff" opacity="0.75" />
                  <ellipse cx="25" cy="128" rx="1.5" ry="2" fill="#ffffff" opacity="0.8" />
                </g>

                {/* Authentic Packaging Markings: Barcode & Recycling Code */}
                <g opacity="0.75" transform="translate(71, 95) scale(0.65)">
                  {/* Barcode lines */}
                  <rect x="0" y="0" width="1.5" height="18" fill="#ffffff" />
                  <rect x="2.5" y="0" width="1" height="18" fill="#ffffff" />
                  <rect x="4.5" y="0" width="2" height="18" fill="#ffffff" />
                  <rect x="7.5" y="0" width="1" height="18" fill="#ffffff" />
                  <rect x="9.5" y="0" width="1.5" height="18" fill="#ffffff" />
                  <rect x="12" y="0" width="1" height="18" fill="#ffffff" />
                </g>

                {/* 330ml / ALU 41 Recycling Badge */}
                <text
                  x="24"
                  y="140"
                  fill="#ffffff"
                  fontSize="4"
                  fontWeight="700"
                  opacity="0.68"
                  fontFamily="sans-serif"
                >
                  330 mL e ♺ ALU 41
                </text>
              </g>
            )}

            {/* ============================================================== */}
            {/* CAN TOP COUNTERSUNK LID & PULL TAB                            */}
            {/* ============================================================== */}
            <g transform={can.type === 'bad' ? 'rotate(-6 50 16)' : undefined}>
              {/* Outer Rolled Seam Rim */}
              <ellipse
                cx="50"
                cy="16"
                rx="28"
                ry="7"
                fill={`url(#metalRim-${can.id})`}
                stroke="#475569"
                strokeWidth="0.8"
              />

              {/* Countersunk Chime Groove */}
              <ellipse
                cx="50"
                cy="16.5"
                rx="25"
                ry="5.8"
                fill={`url(#lidSurface-${can.id})`}
                stroke="#64748b"
                strokeWidth="0.6"
              />

              {/* Score Line (the pre-cut aperture opening) */}
              <path
                d="M 45,15 C 45,13.5 55,13.5 55,15 C 55,17 45,17 45,15 Z"
                fill="#334155"
                stroke="#94a3b8"
                strokeWidth="0.5"
                opacity="0.8"
              />

              {/* Die-Cast Stay-on Pull Tab */}
              <g transform="translate(50, 16.5)">
                {/* Tab Metal Blade */}
                <path
                  d="M -3,-1.5 L 9,-2.5 C 11,-2.5 12,-1 11.5,1 C 11,2.5 9,3 -3,1.8 Z"
                  fill={`url(#pullTabGrad-${can.id})`}
                  stroke="#475569"
                  strokeWidth="0.5"
                />
                {/* Tab Finger Hole Aperture */}
                <ellipse cx="6" cy="-0.2" rx="3" ry="1.2" fill="#334155" />
                {/* Rivet Button */}
                <circle cx="-1.5" cy="0" r="1.3" fill="#e2e8f0" stroke="#334155" strokeWidth="0.4" />
              </g>
            </g>

            {/* ============================================================== */}
            {/* BRAND LOGO EMBLEM ON CAN FACE                                 */}
            {/* ============================================================== */}
            <g transform="translate(50, 68)">
              <g className="filter drop-shadow-[0_2px_5px_rgba(0,0,0,0.85)]">
                {can.type === 'golden' && (
                  <text
                    x="0"
                    y="-14"
                    fill="#fef08a"
                    fontSize="8.5"
                    fontWeight="900"
                    textAnchor="middle"
                    fontFamily="'Chakra Petch', sans-serif"
                  >
                    ★ 24K ULTRA ★
                  </text>
                )}

                {/* Bold Diagonal Brand Font */}
                <text
                  x="0"
                  y="0"
                  fill="#ffffff"
                  fontSize="15"
                  fontWeight="900"
                  fontFamily="'Chakra Petch', 'Cairo', sans-serif"
                  textAnchor="middle"
                  letterSpacing="1.2"
                  style={{
                    filter: 'drop-shadow(0 2px 5px rgba(0,0,0,0.9))',
                  }}
                >
                  {can.name}
                </text>

                {/* Sub-flavor Banner */}
                <rect
                  x="-26"
                  y="5"
                  width="52"
                  height="10"
                  rx="2"
                  fill="#000000"
                  fillOpacity="0.45"
                  stroke="#ffffff"
                  strokeWidth="0.4"
                  strokeOpacity="0.6"
                />
                <text
                  x="0"
                  y="12"
                  fill="#ffffff"
                  fontSize="5"
                  fontWeight="800"
                  fontFamily="'Cairo', sans-serif"
                  textAnchor="middle"
                  letterSpacing="0.5"
                >
                  {can.flavor.toUpperCase()}
                </text>
              </g>
            </g>

            {/* SQUISHED CRUSH OVERLAY (WHEN CRUSHED BY PRESS) */}
            {isCrushed && (
              <g>
                <rect
                  x="10"
                  y="20"
                  width="80"
                  height="130"
                  fill="#000000"
                  opacity="0.65"
                  rx="6"
                />
                {/* Accordion crumpled metal folds */}
                <path
                  d="M 12,35 L 88,40 L 14,75 L 86,85 L 12,120 L 88,125"
                  stroke="#facc15"
                  strokeWidth="5"
                  fill="none"
                  opacity="0.9"
                />
                <text
                  x="50"
                  y="85"
                  fill="#facc15"
                  fontSize="16"
                  fontWeight="900"
                  textAnchor="middle"
                  fontFamily="'Chakra Petch', sans-serif"
                  style={{ filter: 'drop-shadow(0 2px 4px #000)' }}
                >
                  💥 CRUSHED!
                </text>
              </g>
            )}
          </svg>
        )}

        {/* FLOATING STATUS PILL */}
        <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 whitespace-nowrap z-20 pointer-events-none">
          <span
            className={`text-[9px] sm:text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full shadow-md border border-black/40 flex items-center gap-1 ${theme.badgeColor}`}
          >
            {can.type === 'bad' && <AlertTriangle className="w-3 h-3 text-red-600 inline" />}
            {can.type === 'golden' && <Sparkles className="w-3 h-3 text-yellow-800 inline" />}
            {can.type === 'freeze' && <Snowflake className="w-3 h-3 text-cyan-800 inline" />}
            {can.type === 'nitro' && <Flame className="w-3 h-3 text-red-800 inline" />}
            <span>{theme.badge}</span>
          </span>
        </div>
      </div>
    </div>
  );
};
