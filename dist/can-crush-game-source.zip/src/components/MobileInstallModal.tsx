import React, { useState, useEffect } from 'react';
import { Smartphone, Download, Share, PlusSquare, CheckCircle2, X, Sparkles } from 'lucide-react';

interface MobileInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'ar' | 'en';
}

export const MobileInstallModal: React.FC<MobileInstallModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const [platform, setPlatform] = useState<'android' | 'ios' | 'desktop'>('android');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);

  useEffect(() => {
    // Detect mobile OS
    const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera || '';
    if (/iPad|iPhone|iPod/.test(userAgent) && !(window as any).MSStream) {
      setPlatform('ios');
    } else if (/android/i.test(userAgent)) {
      setPlatform('android');
    } else {
      setPlatform('desktop');
    }

    // Capture beforeinstallprompt for Android Chrome / Edge
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Check if running standalone
    if (window.matchMedia('(display-mode: standalone)').matches || (navigator as any).standalone) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
        setIsInstalled(true);
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-700 rounded-2xl max-w-lg w-full p-6 text-white shadow-2xl relative">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 left-4 p-2 rounded-lg bg-neutral-800 text-neutral-400 hover:text-white"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center shadow-lg shadow-yellow-500/20 mb-3 border border-yellow-300/40">
            <Smartphone className="w-7 h-7 text-black" />
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white font-['Cairo']">
            {lang === 'ar' ? 'تنزيل اللعبة على الموبايل 📱' : 'Install on Mobile 📱'}
          </h3>
          <p className="text-xs sm:text-sm text-neutral-400 mt-1">
            {lang === 'ar'
              ? 'اللعبة مجهزة كتطبيق ويب متقدم (PWA) يعمل بدون تحميل من متجر، بكامل الشاشة وسرعة 60fps واهتزاز haptic!'
              : 'PWA Ready: Runs fullscreen like a native mobile app with tactile vibration and 60fps reflexes!'}
          </p>
        </div>

        {/* Platform Tabs */}
        <div className="flex bg-neutral-950 p-1 rounded-xl border border-neutral-800 mb-5 text-xs font-bold">
          <button
            type="button"
            onClick={() => setPlatform('android')}
            className={`flex-1 py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              platform === 'android' ? 'bg-yellow-400 text-black font-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <span>🤖</span>
            <span>{lang === 'ar' ? 'أندرويد (Chrome / Galaxy)' : 'Android'}</span>
          </button>
          <button
            type="button"
            onClick={() => setPlatform('ios')}
            className={`flex-1 py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              platform === 'ios' ? 'bg-yellow-400 text-black font-black' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <span>🍏</span>
            <span>{lang === 'ar' ? 'آيفون (Safari / iOS)' : 'iPhone (iOS)'}</span>
          </button>
        </div>

        {/* Direct Install Button for Android Chrome if prompt is active */}
        {deferredPrompt && (
          <button
            type="button"
            onClick={handleInstallClick}
            className="w-full mb-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black rounded-xl text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/30 animate-bounce"
          >
            <Download className="w-5 h-5" />
            <span>{lang === 'ar' ? 'اضغط هنا للتثبيت الفوري الآن!' : 'Install App Directly Now!'}</span>
          </button>
        )}

        {/* Step-by-Step Instructions by OS */}
        <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 space-y-3.5 text-xs sm:text-sm text-neutral-300">
          {platform === 'android' ? (
            <>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  <div className="font-bold text-white">
                    {lang === 'ar' ? 'افتح اللعبة في متصفح Google Chrome' : 'Open in Google Chrome'}
                  </div>
                  <p className="text-neutral-400 text-[11px] sm:text-xs">
                    {lang === 'ar' ? 'انسخ رابط اللعبة وافتحه في كروم على هاتفك.' : 'Open this page on your Android phone.'}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  <div className="font-bold text-white">
                    {lang === 'ar' ? 'اضغط على زر القائمة (الثلاث نقاط ⋮) في أعلى الشاشة' : 'Tap the 3 dots (⋮) menu'}
                  </div>
                  <p className="text-neutral-400 text-[11px] sm:text-xs">
                    {lang === 'ar' ? 'ستجد خيارات المتصفح وإعدادات الصفحة.' : 'Open browser options at top-right.'}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  3
                </div>
                <div>
                  <div className="font-bold text-white text-yellow-400">
                    {lang === 'ar' ? 'اختر "تثبيت التطبيق" أو "الإضافة إلى الشاشة الرئيسية"' : 'Select "Install app" or "Add to Home Screen"'}
                  </div>
                  <p className="text-neutral-400 text-[11px] sm:text-xs">
                    {lang === 'ar'
                      ? 'ستظهر أيقونة اللعبة باسم "كسارة الكانز" مباشرة مع باقي ألعابك وتطبيقاتك وتفتح بوضع ملء الشاشة!'
                      : 'The game icon will be placed directly on your phone home screen.'}
                  </p>
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  <div className="font-bold text-white">
                    {lang === 'ar' ? 'افتح الرابط في متصفح Safari على الآيفون' : 'Open in Safari on your iPhone'}
                  </div>
                  <p className="text-neutral-400 text-[11px] sm:text-xs">
                    {lang === 'ar' ? 'نظام iOS يدعم تثبيت التطبيقات عبر متصفح سفاري.' : 'Apple iOS requires Safari for home screen install.'}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  2
                </div>
                <div className="flex-1">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <span>{lang === 'ar' ? 'اضغط زر المشاركة' : 'Tap Share button'}</span>
                    <Share className="w-4 h-4 text-cyan-400 inline" />
                    <span>{lang === 'ar' ? '(مربع به سهم للأعلى بالأسفل)' : '(box with upward arrow)'}</span>
                  </div>
                  <p className="text-neutral-400 text-[11px] sm:text-xs">
                    {lang === 'ar' ? 'موجود في شريط الأدوات السفلي لمتصفح سفاري.' : 'Located at the bottom navigation bar.'}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  3
                </div>
                <div className="flex-1">
                  <div className="font-bold text-white text-yellow-400 flex items-center gap-1.5">
                    <PlusSquare className="w-4 h-4 inline text-yellow-400" />
                    <span>{lang === 'ar' ? 'اختر "إضافة إلى الشاشة الرئيسية" (Add to Home Screen)' : 'Select "Add to Home Screen"'}</span>
                  </div>
                  <p className="text-neutral-400 text-[11px] sm:text-xs">
                    {lang === 'ar' ? 'اضغط "إضافة (Add)" وستصبح اللعبة جاهزة كالـ App تماماً وبدون أي شريط عنوان!' : 'Tap Add. The game is ready full-screen!'}
                  </p>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Benefits badge */}
        <div className="mt-4 flex items-center justify-center gap-2 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-800/60 py-2 px-3 rounded-lg">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            {lang === 'ar'
              ? 'تثبيت سريع وخفيف جداً، لا يشغل مساحة، ويدعم اللمس فائق السرعة والاهتزاز!'
              : 'Ultra lightweight, zero storage bulk, instant 60fps touch response!'}
          </span>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-4 w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-bold rounded-xl text-xs sm:text-sm transition-colors"
        >
          {lang === 'ar' ? 'فهمت، إغلاق' : 'Got it, Close'}
        </button>
      </div>
    </div>
  );
};
