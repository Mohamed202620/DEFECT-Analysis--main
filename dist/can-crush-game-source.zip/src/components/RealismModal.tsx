import React, { useState } from 'react';
import { X, CheckCircle, AlertTriangle, Sparkles, Droplets, ShieldCheck, ZoomIn } from 'lucide-react';
import pristineImg from '../assets/images/can_pristine_citrus_1790193863694.jpg';
import defectImg from '../assets/images/can_dented_defect_1790193874943.jpg';
import goldImg from '../assets/images/can_gold_edition_1790193884872.jpg';
import { VisualStyle } from '../types';

interface RealismModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'ar' | 'en';
  visualStyle: VisualStyle;
  onSelectStyle: (style: VisualStyle) => void;
}

export const RealismModal: React.FC<RealismModalProps> = ({
  isOpen,
  onClose,
  lang,
  visualStyle,
  onSelectStyle,
}) => {
  const [activeTab, setActiveTab] = useState<'pristine' | 'defect' | 'gold'>('pristine');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-700 rounded-2xl max-w-2xl w-full p-6 text-white shadow-2xl relative max-h-[92vh] overflow-y-auto">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 left-4 p-2 rounded-lg bg-neutral-800 text-neutral-400 hover:text-white"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="text-center mb-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-400/20 border border-yellow-400/50 text-yellow-300 text-xs font-black uppercase mb-2">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>{lang === 'ar' ? 'فحص جودة وتفاصيل الكانز الواقعية' : '3D Realistic Can Anatomy'}</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-black text-white font-['Cairo']">
            {lang === 'ar' ? 'معمل فحص الكانز الواقعي 🥫' : 'Can Realism Quality Lab 🥫'}
          </h3>
          <p className="text-neutral-400 text-xs sm:text-sm mt-1">
            {lang === 'ar'
              ? 'تصميم أسطواني دقيق بمقاييس 330 مل الحقيقية، انعكاسات ضوئية حقيقية، قطرات تكثف ثلجية، وفتّاحة ألومنيوم أصلية.'
              : 'True-to-life 330ml cylinder geometry, physical specular highlights, cold condensation beads, and die-cast stay-on tab.'}
          </p>
        </div>

        {/* Style Selector Tabs */}
        <div className="flex items-center justify-center gap-2 p-1.5 bg-neutral-950 rounded-xl border border-neutral-800 mb-6">
          <button
            type="button"
            onClick={() => onSelectStyle('ultra3d')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-1.5 ${
              visualStyle === 'ultra3d'
                ? 'bg-gradient-to-r from-yellow-400 to-amber-500 text-black shadow-lg font-black'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <span>🥫</span>
            <span>{lang === 'ar' ? 'محرك الألومنيوم ثلاثي الأبعاد (Ultra 3D)' : 'Ultra 3D Vector Engine'}</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectStyle('photostudio')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-1.5 ${
              visualStyle === 'photostudio'
                ? 'bg-gradient-to-r from-yellow-400 to-amber-500 text-black shadow-lg font-black'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <span>📸</span>
            <span>{lang === 'ar' ? 'صور استوديو واقعية حقيقية (Studio Photos)' : 'Studio 3D Photo Renders'}</span>
          </button>
        </div>

        {/* Can Showcase Viewer Tabs */}
        <div className="flex border-b border-neutral-800 mb-4 text-xs sm:text-sm font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('pristine')}
            className={`pb-2.5 px-4 transition-colors flex items-center gap-2 border-b-2 ${
              activeTab === 'pristine'
                ? 'border-cyan-400 text-cyan-300 font-bold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'ar' ? 'الكانز السليمة المثلجة' : 'Pristine Cold Can'}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('defect')}
            className={`pb-2.5 px-4 transition-colors flex items-center gap-2 border-b-2 ${
              activeTab === 'defect'
                ? 'border-red-500 text-red-400 font-bold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <span>{lang === 'ar' ? 'الكانز التالفة المنبعجة' : 'Dented Defective Can'}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('gold')}
            className={`pb-2.5 px-4 transition-colors flex items-center gap-2 border-b-2 ${
              activeTab === 'gold'
                ? 'border-amber-400 text-amber-300 font-bold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{lang === 'ar' ? 'كانز الذهب 24K' : '24K Golden Can'}</span>
          </button>
        </div>

        {/* Tab Content Display */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 items-center bg-neutral-950 p-4 rounded-xl border border-neutral-800/80">
          {/* Image Display */}
          <div className="relative aspect-square max-w-[240px] mx-auto w-full bg-neutral-900 rounded-xl overflow-hidden border border-neutral-800 flex items-center justify-center shadow-inner group">
            {activeTab === 'pristine' && (
              <img
                src={pristineImg}
                alt="Pristine Cold 3D Soda Can"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter contrast-110 group-hover:scale-105 transition-transform duration-300"
              />
            )}
            {activeTab === 'defect' && (
              <img
                src={defectImg}
                alt="Dented Crumpled 3D Defective Can"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter contrast-110 group-hover:scale-105 transition-transform duration-300"
              />
            )}
            {activeTab === 'gold' && (
              <img
                src={goldImg}
                alt="24K Luxury Gold 3D Soda Can"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain filter contrast-110 group-hover:scale-105 transition-transform duration-300"
              />
            )}

            <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/70 text-[10px] text-neutral-300 flex items-center gap-1 font-mono">
              <ZoomIn className="w-3 h-3 text-yellow-400" />
              <span>3D RENDER</span>
            </div>
          </div>

          {/* Realistic Features Inspection List */}
          <div className="space-y-2.5 text-xs text-neutral-300 text-right">
            {activeTab === 'pristine' && (
              <>
                <div className="flex items-start gap-2 bg-neutral-900/90 p-2.5 rounded-lg border border-neutral-800">
                  <Droplets className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">
                      {lang === 'ar' ? 'قطرات التكثف المثلجة (Condensation)' : 'Ice Cold Condensation Beads'}
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-0.5">
                      {lang === 'ar'
                        ? 'قطرات ماء دقيقة تلمع على هيكل الألومنيوم لإعطاء إحساس بالبرودة والانتعاش.'
                        : 'Micro water beads refract ambient light across the cold brushed metal surface.'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2 bg-neutral-900/90 p-2.5 rounded-lg border border-neutral-800">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">
                      {lang === 'ar' ? 'عنق التضييق وشريط الفتّاحة (Neck & Tab)' : 'Tapered Neck & Stay-on Tab'}
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-0.5">
                      {lang === 'ar'
                        ? 'انحناء العنق من قطر 66 إلى 54 مم مع حافة الغطاء المعدني المزدوج ومسمار التثبيت.'
                        : 'Chime neck taper, double seam lid, and aluminum stamped pull tab with rivet.'}
                    </p>
                  </div>
                </div>
              </>
            )}

            {activeTab === 'defect' && (
              <>
                <div className="flex items-start gap-2 bg-neutral-900/90 p-2.5 rounded-lg border border-neutral-800">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">
                      {lang === 'ar' ? 'انبعاجات وثنيات الألومنيوم (Buckled Creases)' : 'Realistic Metal Buckle Folds'}
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-0.5">
                      {lang === 'ar'
                        ? 'تشوهات هيكلية حقيقية مع ظلال داخلية وانعكاسات الحواف الحادة التالفة.'
                        : 'Severe irregular creases, distorted cylinder silhouette, and sharp highlights.'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2 bg-neutral-900/90 p-2.5 rounded-lg border border-neutral-800">
                  <div className="w-4 h-4 rounded-full bg-yellow-400 text-black flex items-center justify-center font-black text-[9px] shrink-0 mt-0.5">
                    !
                  </div>
                  <div>
                    <div className="font-bold text-white">
                      {lang === 'ar' ? 'شريط تحذير الفحص (QC Hazard Ribbon)' : 'Industrial Hazard Tape'}
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-0.5">
                      {lang === 'ar'
                        ? 'شريط أصفر وأسود مائل مع ختم الفحص لتسهيل تمييزها وسرعة فعصها.'
                        : 'Safety diagonal hazard stripes and rejection stamp for fast recognition.'}
                    </p>
                  </div>
                </div>
              </>
            )}

            {activeTab === 'gold' && (
              <>
                <div className="flex items-start gap-2 bg-neutral-900/90 p-2.5 rounded-lg border border-neutral-800">
                  <Sparkles className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">
                      {lang === 'ar' ? 'طلاء الذهب عيار 24 (24K Gold Mirror)' : 'Mirror Polish 24K Gold'}
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-0.5">
                      {lang === 'ar'
                        ? 'انعكاسات ضوئية فائقة اللمعان وبريق متحرك تمنح +500 نقطة عند فعصها.'
                        : 'Lustrous specular reflections granting +500 points when crushed.'}
                    </p>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Close / Apply button */}
        <button
          type="button"
          onClick={onClose}
          className="mt-5 w-full py-3 bg-yellow-400 hover:bg-yellow-300 text-black font-black rounded-xl text-base transition-colors"
        >
          {lang === 'ar' ? 'جاهز.. ارجع للعبة! 🎮' : 'Back to Game! 🎮'}
        </button>
      </div>
    </div>
  );
};
