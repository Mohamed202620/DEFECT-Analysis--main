import React, { useState, useEffect, useRef, useCallback } from 'react';
import { HUD } from './components/HUD';
import { CrushZone } from './components/CrushZone';
import { CanItem } from './components/CanItem';
import { ParticleLayer } from './components/ParticleLayer';
import { FloatingTextsLayer } from './components/FloatingTextsLayer';
import { GameOverModal } from './components/GameOverModal';
import { InstructionsModal } from './components/InstructionsModal';
import { RealismModal } from './components/RealismModal';
import { MobileInstallModal } from './components/MobileInstallModal';
import { CanData, CanType, GameMode, Particle, FloatingText, VisualStyle } from './types';
import { sounds, triggerHaptic } from './sound';
import { Sparkles, Eye } from 'lucide-react';

const GOOD_BRANDS = [
  { name: 'ZIP!', flavor: 'Electric Citrus', baseColor: '#0284c7', color: 'from-cyan-400 via-sky-500 to-blue-600', glow: '#00e5ff' },
  { name: 'ZING', flavor: 'Lime Spark', baseColor: '#16a34a', color: 'from-emerald-400 via-green-500 to-teal-700', glow: '#10b981' },
  { name: 'POP', flavor: 'Classic Cola', baseColor: '#b91c1c', color: 'from-red-500 via-rose-600 to-red-950', glow: '#ef4444' },
  { name: 'FIZZY', flavor: 'Wild Berry', baseColor: '#9333ea', color: 'from-fuchsia-400 via-purple-500 to-indigo-700', glow: '#c084fc' },
  { name: 'BUBBLY', flavor: 'Blood Orange', baseColor: '#ea580c', color: 'from-amber-400 via-orange-500 to-rose-600', glow: '#f97316' },
  { name: 'BURST', flavor: 'Mango Blast', baseColor: '#d97706', color: 'from-yellow-400 via-amber-500 to-yellow-600', glow: '#fbbf24' },
  { name: 'NEON', flavor: 'Atomic Grape', baseColor: '#7c3aed', color: 'from-violet-400 via-purple-600 to-slate-900', glow: '#a855f7' },
];

export default function App() {
  // Game States
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [mode, setMode] = useState<GameMode>('arcade');
  const [visualStyle, setVisualStyle] = useState<VisualStyle>('ultra3d');
  const [realismOpen, setRealismOpen] = useState<boolean>(false);
  const [installOpen, setInstallOpen] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(0);
  const [level, setLevel] = useState<number>(1);
  const [lives, setLives] = useState<number>(3);
  const [combo, setCombo] = useState<number>(1);
  const [maxCombo, setMaxCombo] = useState<number>(1);
  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [isNewHigh, setIsNewHigh] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [helpOpen, setHelpOpen] = useState<boolean>(false);
  const [screenShake, setScreenShake] = useState<boolean>(false);
  const [redFlash, setRedFlash] = useState<boolean>(false);
  const [freezeActive, setFreezeActive] = useState<boolean>(false);

  // Stats Counters
  const [crushedCount, setCrushedCount] = useState<number>(0);
  const [savedCount, setSavedCount] = useState<number>(0);

  // Entities
  const [cans, setCans] = useState<CanData[]>([]);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);

  // Refs
  const gameAreaRef = useRef<HTMLDivElement | null>(null);
  const cansRef = useRef<CanData[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const isGameOverRef = useRef<boolean>(false);
  const isPausedRef = useRef<boolean>(false);
  const scoreRef = useRef<number>(0);
  const lastSpawnTime = useRef<number>(0);
  const animationFrameId = useRef<number | null>(null);
  const freezeTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Sync refs with state
  cansRef.current = cans;
  particlesRef.current = particles;
  isGameOverRef.current = isGameOver;
  isPausedRef.current = isPaused;
  scoreRef.current = score;

  // Load High Score from localStorage (using `canBest2` to match user snippet)
  useEffect(() => {
    try {
      const savedBest = localStorage.getItem('canBest2');
      if (savedBest) {
        setHighScore(parseInt(savedBest, 10) || 0);
      }
    } catch {
      // LocalStorage access fallback
    }
  }, []);

  // Update HTML lang and dir attribute
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // Particle Spawner Helper
  const spawnExplosionParticles = useCallback(
    (x: number, y: number, color: string, isDefect: boolean) => {
      const count = isDefect ? 22 : 14;
      const newParticles: Particle[] = [];

      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 2 + Math.random() * 7;
        const typeRoll = Math.random();
        const type: 'shard' | 'spark' | 'drop' =
          typeRoll > 0.6 ? 'shard' : typeRoll > 0.3 ? 'drop' : 'spark';

        newParticles.push({
          id: Math.random().toString(36).substring(2, 9),
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 1.5,
          size: type === 'shard' ? 4 + Math.random() * 6 : 2.5 + Math.random() * 4,
          color: type === 'shard' ? (Math.random() > 0.5 ? '#e2e8f0' : '#cbd5e1') : color,
          alpha: 1,
          rotation: Math.random() * Math.PI * 2,
          rotSpeed: (Math.random() - 0.5) * 0.3,
          type,
        });
      }

      setParticles((prev) => [...prev, ...newParticles]);
    },
    []
  );

  // Trigger Screenshake
  const triggerShake = useCallback(() => {
    setScreenShake(true);
    setTimeout(() => setScreenShake(false), 180);
  }, []);

  // Trigger Red Flash
  const triggerRedFlash = useCallback(() => {
    setRedFlash(true);
    setTimeout(() => setRedFlash(false), 240);
  }, []);

  // Add Floating Text
  const addFloatingText = useCallback(
    (x: number, y: number, text: string, color: string, isCombo: boolean = false) => {
      const id = Math.random().toString(36).substring(2, 9);
      setFloatingTexts((prev) => [...prev, { id, x, y, text, color, isCombo }]);
      setTimeout(() => {
        setFloatingTexts((prev) => prev.filter((t) => t.id !== id));
      }, 850);
    },
    []
  );

  // End Game Handler
  const endGame = useCallback(() => {
    setIsGameOver(true);
    sounds.playMistake();
    triggerHaptic('warning');

    if (scoreRef.current > highScore) {
      setHighScore(scoreRef.current);
      setIsNewHigh(true);
      try {
        localStorage.setItem('canBest2', scoreRef.current.toString());
      } catch {
        // storage fallback
      }
    } else {
      setIsNewHigh(false);
    }
  }, [highScore]);

  // Handle Crush of a Can
  const handleCrush = useCallback(
    (can: CanData, e?: React.MouseEvent | React.TouchEvent) => {
      if (can.isCrushed || isGameOverRef.current || isPausedRef.current) return;

      // Calculate approximate position in pixels
      const gameRect = gameAreaRef.current?.getBoundingClientRect();
      const pxX = gameRect ? (can.x / 100) * gameRect.width : 160;
      const pxY = can.y + 40;

      // Mark can as crushed immediately
      setCans((prev) =>
        prev.map((c) => (c.id === can.id ? { ...c, isCrushed: true, crushTime: Date.now() } : c))
      );

      // Handle based on can type
      if (can.type === 'bad') {
        // SUCCESS: Crushed a defective can!
        const multiplier = combo;
        const points = 100 * multiplier;
        const newScore = scoreRef.current + points;
        setScore(newScore);
        scoreRef.current = newScore;
        setCrushedCount((prev) => prev + 1);

        const newCombo = combo + 1;
        setCombo(newCombo);
        setMaxCombo((prev) => Math.max(prev, newCombo));

        sounds.playCrush(multiplier);
        triggerHaptic('heavy');
        triggerShake();

        spawnExplosionParticles(pxX, pxY, '#ef4444', true);
        addFloatingText(
          pxX,
          pxY,
          multiplier > 1 ? `+${points} 🔥 X${multiplier}` : `+${points}`,
          '#facc15',
          multiplier > 2
        );

        // Escalating Speed Level based on crushed count
        if ((crushedCount + 1) % 8 === 0) {
          setLevel((prev) => Math.min(prev + 1, 10));
          sounds.playCombo(newCombo);
        }
      } else if (can.type === 'good') {
        // MISTAKE: Crushed a pristine can!
        sounds.playMistake();
        triggerHaptic('warning');
        triggerRedFlash();
        triggerShake();
        setCombo(1);

        spawnExplosionParticles(pxX, pxY, can.glowColor, false);
        addFloatingText(pxX, pxY, lang === 'ar' ? 'غلط! كانز سليمة ❌' : 'MISTAKE! ❌', '#ef4444', true);

        if (mode === 'arcade') {
          setLives((prev) => {
            const next = prev - 1;
            if (next <= 0) {
              endGame();
            }
            return Math.max(0, next);
          });
        } else if (mode === 'frenzy') {
          setScore((prev) => Math.max(0, prev - 150));
        }
      } else if (can.type === 'golden') {
        // SPECIAL: 24K Golden Can!
        const bonus = 500;
        setScore((prev) => prev + bonus);
        sounds.playSpecial('golden');
        triggerHaptic('heavy');
        spawnExplosionParticles(pxX, pxY, '#fbbf24', false);
        addFloatingText(pxX, pxY, '+500 🌟 24K GOLD!', '#facc15', true);
      } else if (can.type === 'freeze') {
        // SPECIAL: Freeze Conveyor for 4 seconds!
        setFreezeActive(true);
        sounds.playSpecial('freeze');
        triggerHaptic('light');
        spawnExplosionParticles(pxX, pxY, '#38bdf8', false);
        addFloatingText(pxX, pxY, lang === 'ar' ? '❄️ تجميد السير!' : '❄️ CONVEYOR FROZEN!', '#38bdf8', true);

        if (freezeTimerRef.current) clearTimeout(freezeTimerRef.current);
        freezeTimerRef.current = setTimeout(() => {
          setFreezeActive(false);
        }, 4000);
      } else if (can.type === 'nitro') {
        // SPECIAL: Nitro Blast - crushes all other bad cans currently on screen!
        sounds.playSpecial('bomb');
        triggerHaptic('heavy');
        triggerShake();
        spawnExplosionParticles(pxX, pxY, '#f97316', true);
        addFloatingText(pxX, pxY, '💥 NITRO DETONATION!', '#fb923c', true);

        setCans((prev) =>
          prev.map((c) => {
            if (c.type === 'bad' && !c.isCrushed) {
              return { ...c, isCrushed: true, crushTime: Date.now() };
            }
            return c;
          })
        );
        setScore((prev) => prev + 300);
      }

      // Stop propagation if event provided
      if (e) {
        e.stopPropagation();
      }
    },
    [
      combo,
      crushedCount,
      endGame,
      lang,
      mode,
      spawnExplosionParticles,
      triggerRedFlash,
      triggerShake,
      addFloatingText,
    ]
  );

  // Slam Hydraulic Press (Crush Zone)
  const handleSlamPress = useCallback(() => {
    if (isGameOverRef.current || isPausedRef.current) return;

    const gameEl = gameAreaRef.current;
    if (!gameEl) return;
    const height = gameEl.clientHeight;
    const dangerZoneTop = height * 0.65; // Bottom 35% of the conveyor

    triggerShake();

    // Check which cans are in the danger zone
    let crushedAny = false;
    cansRef.current.forEach((can) => {
      if (!can.isCrushed && can.y >= dangerZoneTop) {
        handleCrush(can);
        crushedAny = true;
      }
    });

    if (!crushedAny) {
      sounds.playHydraulicPress();
    }
  }, [handleCrush, triggerShake]);

  // Spacebar shortcut for Hydraulic Press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        handleSlamPress();
      } else if (e.code === 'KeyP' || e.code === 'Escape') {
        setIsPaused((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleSlamPress]);

  // Timer for 60s Frenzy Mode
  useEffect(() => {
    if (mode !== 'frenzy' || isGameOver || isPaused) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [mode, isGameOver, isPaused, endGame]);

  // Reset / Restart Run
  const restartGame = useCallback(() => {
    setCans([]);
    setParticles([]);
    setFloatingTexts([]);
    setScore(0);
    scoreRef.current = 0;
    setLevel(1);
    setLives(3);
    setCombo(1);
    setTimeLeft(60);
    setCrushedCount(0);
    setSavedCount(0);
    setIsGameOver(false);
    setIsPaused(false);
    setIsNewHigh(false);
    setFreezeActive(false);
    lastSpawnTime.current = Date.now();
  }, []);

  // Main 60FPS Game Loop
  useEffect(() => {
    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      const dt = (currentTime - lastTime) / 1000;
      lastTime = currentTime;

      if (!isGameOverRef.current && !isPausedRef.current) {
        const gameEl = gameAreaRef.current;
        const gameHeight = gameEl ? gameEl.clientHeight : 600;

        // 1. SPAWN LOGIC
        const now = Date.now();
        const baseInterval = Math.max(550, 1150 - level * 65);
        if (now - lastSpawnTime.current > baseInterval) {
          lastSpawnTime.current = now;

          // Decide can type
          const roll = Math.random();
          let type: CanType = 'good';
          if (roll < 0.48) {
            type = 'bad';
          } else if (roll > 0.94) {
            type = 'golden';
          } else if (roll > 0.90) {
            type = 'freeze';
          } else if (roll > 0.86) {
            type = 'nitro';
          } else {
            type = 'good';
          }

          const brand = GOOD_BRANDS[Math.floor(Math.random() * GOOD_BRANDS.length)];
          const speedMultiplier = freezeActive ? 0.35 : 1;
          const baseFallSpeed = (2.2 + Math.random() * 1.5 + level * 0.45) * speedMultiplier;

          // Randomize horizontal lane with padding
          const newX = 14 + Math.random() * 72; // 14% to 86%

          const newCan: CanData = {
            id: Math.random().toString(36).substring(2, 9),
            type,
            name: brand.name,
            flavor: brand.flavor,
            baseColor: brand.baseColor,
            accentColor: brand.color,
            glowColor: brand.glow,
            x: newX,
            y: -120,
            speed: baseFallSpeed,
            rotation: type === 'bad' ? (Math.random() - 0.5) * 16 : (Math.random() - 0.5) * 4,
            wobbleSpeed: 2 + Math.random() * 3,
            wobbleOffset: Math.random() * Math.PI,
            isCrushed: false,
          };

          setCans((prev) => [...prev, newCan]);
        }

        // 2. UPDATE CANS POSITION & BOUNDARY CHECK
        setCans((prevCans) => {
          const survivingCans: CanData[] = [];

          for (let i = 0; i < prevCans.length; i++) {
            const can = prevCans[i];

            // If crushed, allow it to display squished for 200ms then remove
            if (can.isCrushed) {
              if (can.crushTime && Date.now() - can.crushTime < 240) {
                survivingCans.push(can);
              }
              continue;
            }

            // Move downward
            const effectiveSpeed = freezeActive ? can.speed * 0.35 : can.speed;
            const nextY = can.y + effectiveSpeed * (dt * 60);

            // Reached bottom collection zone / chute!
            if (nextY >= gameHeight - 25) {
              if (can.type === 'good') {
                // Pristine can safely reached the packaging chute!
                sounds.playSafePass();
                setSavedCount((c) => c + 1);
                setScore((s) => s + 10);
              } else if (can.type === 'bad') {
                // CONTAMINATION! Bad can leaked through uncrushed!
                sounds.playMistake();
                triggerHaptic('warning');
                triggerRedFlash();
                setCombo(1);

                if (mode === 'arcade') {
                  setLives((l) => {
                    const next = l - 1;
                    if (next <= 0) {
                      endGame();
                    }
                    return Math.max(0, next);
                  });
                } else if (mode === 'frenzy') {
                  setScore((s) => Math.max(0, s - 100));
                }
              }
              // Can exits the conveyor belt
              continue;
            }

            survivingCans.push({
              ...can,
              y: nextY,
            });
          }

          return survivingCans;
        });

        // 3. UPDATE PARTICLES PHYSICS
        setParticles((prevParticles) => {
          if (prevParticles.length === 0) return prevParticles;

          const updated: Particle[] = [];
          for (let i = 0; i < prevParticles.length; i++) {
            const p = prevParticles[i];
            const nextAlpha = p.alpha - dt * 2.2;
            if (nextAlpha > 0.05) {
              updated.push({
                ...p,
                x: p.x + p.vx * (dt * 60),
                y: p.y + p.vy * (dt * 60),
                vy: p.vy + 0.35 * (dt * 60), // gravity
                rotation: p.rotation + p.rotSpeed,
                alpha: nextAlpha,
              });
            }
          }
          return updated;
        });
      }

      animationFrameId.current = requestAnimationFrame(loop);
    };

    animationFrameId.current = requestAnimationFrame(loop);

    return () => {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [level, freezeActive, mode, endGame, triggerRedFlash]);

  return (
    <div
      className={`relative w-full h-screen bg-neutral-950 flex flex-col justify-between overflow-hidden select-none touch-none ${
        screenShake ? 'screen-shake' : ''
      }`}
    >
      {/* Red Screen Flash on Error / Strike */}
      {redFlash && (
        <div className="absolute inset-0 bg-red-600/30 z-40 pointer-events-none transition-opacity duration-150" />
      )}

      {/* Freeze Frost Overlay */}
      {freezeActive && (
        <div className="absolute inset-0 bg-cyan-500/15 pointer-events-none z-30 border-8 border-cyan-400/30 backdrop-blur-[0.5px]" />
      )}

      {/* TOP HUD BAR */}
      <HUD
        score={score}
        highScore={highScore}
        level={level}
        lives={lives}
        maxLives={3}
        combo={combo}
        mode={mode}
        visualStyle={visualStyle}
        timeLeft={timeLeft}
        isPaused={isPaused}
        soundEnabled={soundEnabled}
        lang={lang}
        onToggleSound={() => {
          const next = !soundEnabled;
          setSoundEnabled(next);
          sounds.setEnabled(next);
        }}
        onTogglePause={() => setIsPaused((prev) => !prev)}
        onRestart={restartGame}
        onOpenHelp={() => setHelpOpen(true)}
        onToggleLang={() => setLang((prev) => (prev === 'ar' ? 'en' : 'ar'))}
        onToggleVisualStyle={() => setVisualStyle((v) => (v === 'ultra3d' ? 'photostudio' : 'ultra3d'))}
        onOpenInstall={() => setInstallOpen(true)}
      />

      {/* MAIN GAME CONVEYOR BELT PLAYFIELD */}
      <main
        ref={gameAreaRef}
        className="relative flex-1 w-full max-w-5xl mx-auto overflow-hidden conveyor-belt-grid border-x-4 border-neutral-800 shadow-[inset_0_0_80px_rgba(0,0,0,0.85)] cursor-crosshair"
      >
        {/* Conveyor Side Guide Rails & Warning Lights */}
        <div className="absolute top-0 bottom-0 left-0 w-3 bg-gradient-to-r from-yellow-500/80 via-neutral-900 to-transparent pointer-events-none z-10" />
        <div className="absolute top-0 bottom-0 right-0 w-3 bg-gradient-to-l from-yellow-500/80 via-neutral-900 to-transparent pointer-events-none z-10" />

        {/* Ambient Factory Smoke / Light Ray */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60 pointer-events-none" />

        {/* Realism Inspector Quick Access Pill */}
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 pointer-events-auto">
          <button
            type="button"
            onClick={() => setRealismOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-neutral-900/85 hover:bg-neutral-800/95 border border-yellow-400/40 text-yellow-300 text-[11px] font-bold shadow-lg backdrop-blur-sm transition-all hover:scale-105"
          >
            <Eye className="w-3.5 h-3.5 text-yellow-400" />
            <span>{lang === 'ar' ? '🔍 معمل فحص الكانز الواقعية 3D' : '🔍 3D Realism Lab'}</span>
          </button>
        </div>

        {/* CANS ENTITIES */}
        {cans.map((can) => (
          <CanItem
            key={can.id}
            can={can}
            onCrush={handleCrush}
            lang={lang}
            visualStyle={visualStyle}
          />
        ))}

        {/* PARTICLE CANVAS LAYER */}
        <ParticleLayer particles={particles} />

        {/* FLOATING TEXT LAYER */}
        <FloatingTextsLayer texts={floatingTexts} />

        {/* DANGER LINE INDICATOR */}
        <div className="absolute bottom-[32%] inset-x-0 h-0.5 border-b border-dashed border-red-500/40 pointer-events-none flex items-center justify-center">
          <span className="bg-neutral-900/90 text-red-400 text-[10px] font-mono px-2 py-0.5 rounded border border-red-500/40 uppercase tracking-widest">
            {lang === 'ar' ? '⚠️ خط الفعص الحرج' : '⚠️ CRUSH THRESHOLD'}
          </span>
        </div>

        {/* PAUSE OVERLAY */}
        {isPaused && (
          <div className="absolute inset-0 z-45 bg-black/75 backdrop-blur-sm flex flex-col items-center justify-center text-white">
            <div className="text-3xl font-black mb-2 text-yellow-400 font-['Cairo']">
              {lang === 'ar' ? 'اللعبة متوقفة مؤقتاً' : 'Game Paused'}
            </div>
            <p className="text-neutral-300 text-sm mb-5">
              {lang === 'ar' ? 'اضغط للمتابعة أو P' : 'Press Play or P to resume'}
            </p>
            <button
              type="button"
              onClick={() => setIsPaused(false)}
              className="py-2.5 px-6 rounded-xl bg-yellow-400 text-black font-black text-base shadow hover:bg-yellow-300 transition-colors"
            >
              {lang === 'ar' ? 'متابعة اللعب' : 'Resume'}
            </button>
          </div>
        )}
      </main>

      {/* BOTTOM HYDRAULIC PRESS / CRUSH ZONE */}
      <footer className="w-full max-w-5xl mx-auto z-30">
        <CrushZone onSlamPress={handleSlamPress} lang={lang} />
      </footer>

      {/* GAME OVER MODAL */}
      {isGameOver && (
        <GameOverModal
          score={score}
          highScore={highScore}
          isNewHigh={isNewHigh}
          crushedCount={crushedCount}
          savedCount={savedCount}
          maxCombo={maxCombo}
          mode={mode}
          lang={lang}
          onRestart={restartGame}
          onChangeMode={(newMode) => {
            setMode(newMode);
            restartGame();
          }}
        />
      )}

      {/* INSTRUCTIONS & RULES MODAL */}
      <InstructionsModal isOpen={helpOpen} onClose={() => setHelpOpen(false)} lang={lang} />

      {/* 3D REALISM INSPECTOR MODAL */}
      <RealismModal
        isOpen={realismOpen}
        onClose={() => setRealismOpen(false)}
        lang={lang}
        visualStyle={visualStyle}
        onSelectStyle={setVisualStyle}
      />

      {/* MOBILE INSTALLATION GUIDE MODAL */}
      <MobileInstallModal
        isOpen={installOpen}
        onClose={() => setInstallOpen(false)}
        lang={lang}
      />
    </div>
  );
}
