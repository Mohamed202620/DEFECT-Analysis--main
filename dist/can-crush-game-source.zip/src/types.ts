export type CanType = 'good' | 'bad' | 'golden' | 'freeze' | 'nitro';

export type GameMode = 'arcade' | 'frenzy' | 'zen';

export type VisualStyle = 'ultra3d' | 'photostudio';

export interface CanData {
  id: string;
  type: CanType;
  name: string;
  flavor: string;
  baseColor: string;
  accentColor: string;
  glowColor: string;
  x: number; // percentage (5% to 85%)
  y: number; // in pixels
  speed: number;
  rotation: number;
  wobbleSpeed: number;
  wobbleOffset: number;
  isCrushed: boolean;
  crushTime?: number;
  defectReason?: string;
}

export interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  rotation: number;
  rotSpeed: number;
  type: 'spark' | 'drop' | 'shard' | 'bubble';
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  isCombo?: boolean;
}

export interface GameStats {
  score: number;
  highScore: number;
  crushedDefects: number;
  savedGoodCans: number;
  leakedDefects: number;
  ruinedGoodCans: number;
  maxCombo: number;
  level: number;
}
