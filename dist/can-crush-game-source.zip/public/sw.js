// Minimal service worker for offline caching and PWA installation support
const CACHE_NAME = 'can-crush-pro-v1';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
  // Let network handle regular dynamic requests with graceful fallback
  if (event.request.method !== 'GET') return;
  
  event.respondWith(
    fetch(event.request).catch(async () => {
      const cache = await caches.open(CACHE_NAME);
      return cache.match(event.request) || caches.match('/');
    })
  );
});
